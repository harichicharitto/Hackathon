#!/usr/bin/env python3
"""
Comprehensive verification script to test the API response structure 
and frontend parsing logic for change requests.
"""

import requests
import json
import re

def test_api_response():
    """Test the actual API response structure."""
    try:
        # Login to get token
        login_response = requests.post('http://localhost:5000/api/auth/login', 
            json={'username': 'admin', 'password': 'admin123'})
        
        if not login_response.ok:
            print(f"❌ Login failed: {login_response.status_code}")
            return False
        
        token = login_response.json()['access_token']
        headers = {'Authorization': f'Bearer {token}'}
        
        # Get changes - we need to test with specific changes that have risk scores
        # Based on database analysis, changes 91-100 have risk scores
        changes_response = requests.get('http://localhost:5000/api/changes/?page=1&per_page=20', headers=headers)
        
        if not changes_response.ok:
            print(f"❌ Failed to get changes: {changes_response.status_code}")
            return False
        
        changes_data = changes_response.json()
        
        if 'changes' not in changes_data or not changes_data['changes']:
            print("❌ No changes found in response")
            return False
        
        # Filter changes that have risk scores
        changes_with_scores = [c for c in changes_data['changes'] if c.get('risk_scores')]
        
        if not changes_with_scores:
            print("⚠️  No changes with risk scores found in API response")
            print("   Testing with all changes (some may not have risk analysis)")
            return changes_data['changes']
        
        print(f"✅ API Response Structure Verified - {len(changes_with_scores)} changes with risk scores")
        return changes_with_scores
        
    except Exception as e:
        print(f"❌ Error testing API: {e}")
        return False

def simulate_frontend_parsing(change):
    """Simulate the frontend parsing logic."""
    
    def getRiskReasoning(change):
        # Check if change has risk_scores array
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            
            # First check if there's a separate risk_reasoning field
            if latestRisk.get('risk_reasoning'):
                # Remove the recommendation part from reasoning
                reasoning = latestRisk['risk_reasoning']
                recommendationMatch = re.search(r'Recommendation:\s*(.+)', reasoning, re.IGNORECASE)
                if recommendationMatch:
                    return re.sub(r'Recommendation:\s*.+', '', reasoning, flags=re.IGNORECASE).strip()
                return reasoning
            
            # If no risk_reasoning, check if there's a recommendation field with full text
            if latestRisk.get('recommendation'):
                fullText = latestRisk['recommendation']
                # Extract everything before "RECOMMENDATION:" as reasoning
                recommendationMatch = re.search(r'(.+?)RECOMMENDATION:', fullText, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
                # If no RECOMMENDATION: marker, return the full text as reasoning
                return fullText
        
        return 'No model analysis available for this change.'

    def getRiskRecommendation(change):
        # Check if change has risk_scores array
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            
            # First check if there's a separate recommendation field
            if latestRisk.get('recommendation'):
                fullText = latestRisk['recommendation']
                # Extract everything after "RECOMMENDATION:" as the recommendation
                recommendationMatch = re.search(r'RECOMMENDATION:\s*(.+)', fullText, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
                # If no RECOMMENDATION: marker, return the full text as recommendation
                return fullText
            
            # If no recommendation field, try to extract from risk_reasoning
            if latestRisk.get('risk_reasoning'):
                reasoning = latestRisk['risk_reasoning']
                recommendationMatch = re.search(r'Recommendation:\s*(.+)', reasoning, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
                
                # Try other common patterns for recommendations
                patterns = [
                    r'Recommendation:\s*(.+)',
                    r'Recommend:\s*(.+)',
                    r'Suggestion:\s*(.+)',
                    r'Advice:\s*(.+)',
                    r'Next steps?:\s*(.+)'
                ]
                
                for pattern in patterns:
                    match = re.search(pattern, reasoning, re.IGNORECASE)
                    if match:
                        return match.group(1).strip()
        
        return 'No recommendation available for this assessment.'

    def getRiskFactors(change):
        # Check if change has risk_scores array
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            if latestRisk.get('risk_factors'):
                try:
                    # Try to parse as JSON if it's a string
                    if isinstance(latestRisk['risk_factors'], str):
                        import json
                        parsed = json.loads(latestRisk['risk_factors'])
                        if isinstance(parsed, list):
                            return parsed
                    elif isinstance(latestRisk['risk_factors'], list):
                        return latestRisk['risk_factors']
                except Exception as e:
                    print(f"⚠️  Failed to parse risk factors: {e}")
        
        return []

    # Apply parsing logic
    reasoning = getRiskReasoning(change)
    recommendation = getRiskRecommendation(change)
    factors = getRiskFactors(change)
    
    return reasoning, recommendation, factors

def verify_parsing():
    """Verify the frontend parsing logic with actual data."""
    
    print("🔍 Testing API Response and Frontend Parsing...")
    print("=" * 60)
    
    # Test API response
    changes = test_api_response()
    if not changes:
        return False
    
    # Test parsing for each change
    for i, change in enumerate(changes[:3]):  # Test first 3 changes
        print(f"\n📋 Change {i+1}: {change.get('title', 'Untitled')}")
        print(f"   Change ID: {change.get('id')}")
        print(f"   Risk Level: {change.get('risk_level', 'Unknown')}")
        
        # Check risk scores
        if change.get('risk_scores'):
            risk_score = change['risk_scores'][0]
            print(f"   Risk Scores: {len(change['risk_scores'])} record(s)")
            print(f"   - Risk Reasoning: {'✅' if risk_score.get('risk_reasoning') else '❌'}")
            print(f"   - Risk Factors: {'✅' if risk_score.get('risk_factors') else '❌'}")
            print(f"   - Recommendation: {'✅' if risk_score.get('recommendation') else '❌'}")
            
            if risk_score.get('recommendation'):
                print(f"   - Recommendation Preview: {repr(risk_score['recommendation'][:100] + '...' if len(risk_score['recommendation']) > 100 else risk_score['recommendation'])}")
        else:
            print(f"   Risk Scores: ❌ No records")
        
        # Test frontend parsing
        reasoning, recommendation, factors = simulate_frontend_parsing(change)
        
        print(f"\n🎯 Frontend Parsing Results:")
        print(f"   Analysis Basis: {'✅' if reasoning and reasoning != 'No model analysis available for this change.' else '❌'}")
        print(f"   Recommendation: {'✅' if recommendation and recommendation != 'No recommendation available for this assessment.' else '❌'}")
        print(f"   Contributing Factors: {'✅' if factors else '❌'}")
        
        if reasoning and reasoning != 'No model analysis available for this change.':
            print(f"   - Reasoning Preview: {repr(reasoning[:80] + '...' if len(reasoning) > 80 else reasoning)}")
        
        if recommendation and recommendation != 'No recommendation available for this assessment.':
            print(f"   - Recommendation Preview: {repr(recommendation[:80] + '...' if len(recommendation) > 80 else recommendation)}")
        
        # Verify separation
        if change.get('risk_scores') and change['risk_scores'][0].get('recommendation'):
            full_text = change['risk_scores'][0]['recommendation']
            has_separation = 'RECOMMENDATION:' in full_text.upper()
            print(f"   Content Separation: {'✅' if has_separation else '⚠️  May be merged'}")
        
        print("-" * 40)
    
    print("\n✅ Verification Complete!")
    return True

if __name__ == '__main__':
    verify_parsing()