#!/usr/bin/env python3
"""
Test script to verify pagination functionality works correctly.
"""

import requests
import json

def test_pagination():
    # Get token
    response = requests.post('http://localhost:5000/api/auth/login', 
                            json={'username': 'admin', 'password': 'admin123'})
    if not response.ok:
        print(f"Login failed: {response.status_code}")
        return
    
    token = response.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    
    print('=== Testing Page 1 ===')
    response = requests.get('http://localhost:5000/api/changes/?page=1&per_page=20', headers=headers)
    if response.ok:
        data = response.json()
        changes = data['changes']
        pagination = data['pagination']
        print(f'Page 1: {len(changes)} changes')
        print(f'First change ID: {changes[0]["change_id"]}')
        print(f'Last change ID: {changes[-1]["change_id"]}')
        print(f'Pagination: page={pagination["page"]}, total={pagination["total"]}, pages={pagination["pages"]}')
    
    print('\n=== Testing Page 2 ===')
    response = requests.get('http://localhost:5000/api/changes/?page=2&per_page=20', headers=headers)
    if response.ok:
        data = response.json()
        changes = data['changes']
        pagination = data['pagination']
        print(f'Page 2: {len(changes)} changes')
        print(f'First change ID: {changes[0]["change_id"]}')
        print(f'Last change ID: {changes[-1]["change_id"]}')
        print(f'Pagination: page={pagination["page"]}, total={pagination["total"]}, pages={pagination["pages"]}')
    
    print('\n=== Testing Page 5 (Last Page) ===')
    response = requests.get('http://localhost:5000/api/changes/?page=5&per_page=20', headers=headers)
    if response.ok:
        data = response.json()
        changes = data['changes']
        pagination = data['pagination']
        print(f'Page 5: {len(changes)} changes')
        print(f'First change ID: {changes[0]["change_id"]}')
        print(f'Last change ID: {changes[-1]["change_id"]}')
        print(f'Pagination: page={pagination["page"]}, total={pagination["total"]}, pages={pagination["pages"]}')
    
    print('\n=== Testing All 100 Records ===')
    response = requests.get('http://localhost:5000/api/changes/?per_page=100', headers=headers)
    if response.ok:
        data = response.json()
        changes = data['changes']
        pagination = data['pagination']
        print(f'All records: {len(changes)} changes')
        print(f'First change ID: {changes[0]["change_id"]}')
        print(f'Last change ID: {changes[-1]["change_id"]}')
        print(f'Pagination: page={pagination["page"]}, total={pagination["total"]}, pages={pagination["pages"]}')

if __name__ == '__main__':
    test_pagination()