// Change Risk Classifier Frontend Application
class ChangeRiskApp {
    constructor() {
        this.token = localStorage.getItem('token');
        this.currentUser = null;
        this.changes = [];
        this.rules = [];
        this.riskChart = null;
        
        this.init();
    }

    async init() {
        this.setupEventListeners();
        
        if (this.token) {
            const isValid = await this.validateToken();
            if (isValid) {
                await this.loadDashboard();
                this.showPage('dashboard-page');
            } else {
                this.showPage('login-page');
            }
        } else {
            this.showPage('login-page');
        }
    }

    setupEventListeners() {
        // Login Form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Navigation
        document.querySelectorAll('.nav-item[data-view]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const view = e.target.getAttribute('data-view');
                this.switchView(view);
            });
        });

        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }

        // Change Form
        const changeForm = document.getElementById('change-form');
        if (changeForm) {
            changeForm.addEventListener('submit', (e) => this.handleCreateChange(e));
        }

        // Preview Risk
        const previewBtn = document.getElementById('preview-risk-btn');
        if (previewBtn) {
            previewBtn.addEventListener('click', () => this.previewRisk());
        }

        // Risk rules editor controls
        const newRiskRuleBtn = document.getElementById('new-risk-rule-btn');
        const riskRuleForm = document.getElementById('risk-rule-form');
        const cancelRiskRuleBtn = document.getElementById('cancel-risk-rule-btn');

        if (newRiskRuleBtn) {
            newRiskRuleBtn.addEventListener('click', () => this.openRiskRuleEditor());
        }

        if (riskRuleForm) {
            riskRuleForm.addEventListener('submit', (e) => this.saveRiskRule(e));
        }

        if (cancelRiskRuleBtn) {
            cancelRiskRuleBtn.addEventListener('click', () => this.closeRiskRuleEditor());
        }

        const addUserBtn = document.getElementById('add-user-btn');
        const cancelUserBtn = document.getElementById('cancel-user-btn');
        const userForm = document.getElementById('user-form');

        if (addUserBtn) {
            addUserBtn.addEventListener('click', () => this.openUserForm());
        }
        if (cancelUserBtn) {
            cancelUserBtn.addEventListener('click', () => this.closeUserForm());
        }
        if (userForm) {
            userForm.addEventListener('submit', (e) => this.handleCreateUser(e));
        }

        // Filters
        const statusFilter = document.getElementById('status-filter');
        const riskFilter = document.getElementById('risk-filter');
        const searchInput = document.getElementById('search-input');
        
        if (statusFilter) statusFilter.addEventListener('change', () => this.filterChanges());
        if (riskFilter) riskFilter.addEventListener('change', () => this.filterChanges());
        if (searchInput) searchInput.addEventListener('input', () => this.filterChanges());

        // Dashboard Filters
        const dashboardStatusFilter = document.getElementById('dashboard-status-filter');
        const dashboardRiskFilter = document.getElementById('dashboard-risk-filter');
        const dashboardSearch = document.getElementById('dashboard-search');
        const clearDashboardFiltersBtn = document.getElementById('clear-dashboard-filters');

        if (dashboardStatusFilter) {
            dashboardStatusFilter.addEventListener('change', () => this.filterDashboard());
        }
        if (dashboardRiskFilter) {
            dashboardRiskFilter.addEventListener('change', () => this.filterDashboard());
        }
        if (dashboardSearch) {
            dashboardSearch.addEventListener('input', () => this.filterDashboard());
        }
        if (clearDashboardFiltersBtn) {
            clearDashboardFiltersBtn.addEventListener('click', () => this.clearDashboardFilters());
        }

        // Export buttons
        const exportChangesBtn = document.getElementById('export-changes-btn');
        
        if (exportChangesBtn) exportChangesBtn.addEventListener('click', () => this.exportChanges());

        // Pagination controls
        const prevPageBtn = document.getElementById('prev-page-btn');
        const nextPageBtn = document.getElementById('next-page-btn');
        const pageSelect = document.getElementById('page-select');

        if (prevPageBtn) {
            prevPageBtn.addEventListener('click', () => this.handlePagination('prev'));
        }
        if (nextPageBtn) {
            nextPageBtn.addEventListener('click', () => this.handlePagination('next'));
        }
        if (pageSelect) {
            pageSelect.addEventListener('change', (e) => this.handlePagination('select', parseInt(e.target.value)));
        }

        // Edit Change Modal
        const editChangeForm = document.getElementById('edit-change-form');
        const previewEditRiskBtn = document.getElementById('preview-edit-risk-btn');
        const editRiskPreview = document.getElementById('edit-risk-preview');
        const editRiskResult = document.getElementById('edit-risk-result');
        const editChangeModal = document.getElementById('edit-change-modal');

        if (editChangeForm) {
            editChangeForm.addEventListener('submit', (e) => this.handleEditChange(e));
        }

        if (previewEditRiskBtn) {
            previewEditRiskBtn.addEventListener('click', () => this.previewEditRisk());
        }

        if (editRiskPreview) {
            editRiskPreview.addEventListener('click', (e) => {
                if (e.target.classList.contains('close-preview')) {
                    editRiskPreview.style.display = 'none';
                }
            });
        }

        // Close edit modal functionality
        if (editChangeModal) {
            const closeBtn = editChangeModal.querySelector('.close');
            if (closeBtn) {
                closeBtn.onclick = () => editChangeModal.style.display = 'none';
            }
            window.onclick = (e) => {
                if (e.target === editChangeModal) {
                    editChangeModal.style.display = 'none';
                }
            };
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('login-error');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.access_token;
                localStorage.setItem('token', this.token);
                this.currentUser = this.normalizeCurrentUser(data.user);
                
                this.updateUserInfo();
                await this.loadDashboard();
                this.showPage('dashboard-page');
            } else {
                errorDiv.style.display = 'block';
                errorDiv.textContent = data.error || 'Login failed';
            }
        } catch (error) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = 'Network error. Please try again.';
        }
    }

    async validateToken() {
        try {
            const response = await fetch('/api/auth/validate-token', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ token: this.token })
            });

            if (response.ok) {
                const data = await response.json();
                this.currentUser = this.normalizeCurrentUser(data.user);
                return true;
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    normalizeCurrentUser(user) {
        if (!user) {
            return null;
        }

        const role = String(user.role || '').toLowerCase();
        return {
            ...user,
            is_admin: typeof user.is_admin === 'boolean' ? user.is_admin : role === 'admin',
            is_change_manager: typeof user.is_change_manager === 'boolean'
                ? user.is_change_manager
                : role === 'change_manager'
        };
    }

    updateUserInfo() {
        const userNameEl = document.getElementById('current-user-name');
        const userRoleEl = document.getElementById('current-user-role');
        
        if (userNameEl && userRoleEl && this.currentUser) {
            userNameEl.textContent = this.currentUser.username;
            userRoleEl.textContent = this.currentUser.role.toUpperCase();
            userRoleEl.className = `role-badge role-${this.currentUser.role}`;
        }
    }

    showPage(pageId) {
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        
        const page = document.getElementById(pageId);
        if (page) {
            page.classList.add('active');
        }
    }

    switchView(viewName) {
        // Update active navigation
        document.querySelectorAll('.nav-item').forEach(link => {
            link.classList.remove('active');
        });
        
        const activeLink = document.querySelector(`.nav-item[data-view="${viewName}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Show/hide views
        document.querySelectorAll('.view').forEach(view => {
            view.classList.remove('active');
        });
        
        const view = document.getElementById(`${viewName}-view`);
        if (view) {
            view.classList.add('active');
        }

        // Load data for specific views
        switch(viewName) {
            case 'changes':
                this.loadChanges();
                break;
            case 'rules':
                this.loadRules();
                break;
            case 'users':
                this.loadUsers();
                break;
        }
    }

    async loadDashboard() {
        try {
            const [changesResponse, statsResponse] = await Promise.all([
                fetch('/api/changes/', {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                }),
                fetch('/api/dashboard/summary', {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                })
            ]);

            if (changesResponse.ok && statsResponse.ok) {
                const changesPayload = await changesResponse.json();
                this.changes = this.extractChanges(changesPayload);
                const stats = await statsResponse.json();
                
                this.updateDashboardStats(stats);
                this.renderRecentChanges(this.changes.slice(0, 5));
                this.renderDashboardCharts(stats);
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    async filterDashboard() {
        const status = document.getElementById('dashboard-status-filter')?.value;
        const risk = document.getElementById('dashboard-risk-filter')?.value;
        const search = document.getElementById('dashboard-search')?.value?.toLowerCase() || '';

        // Build query parameters
        const params = new URLSearchParams();
        if (status) params.set('status', status);
        if (risk) params.set('risk_level', risk);
        if (search) params.set('search', search);

        try {
            // Fetch filtered stats
            const statsResponse = await fetch(`/api/dashboard/summary?${params.toString()}`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (statsResponse.ok) {
                const stats = await statsResponse.json();
                this.updateDashboardStats(stats);
                this.renderDashboardCharts(stats);
            }
        } catch (error) {
            console.error('Error filtering dashboard:', error);
        }
    }

    clearDashboardFilters() {
        const statusFilter = document.getElementById('dashboard-status-filter');
        const riskFilter = document.getElementById('dashboard-risk-filter');
        const searchInput = document.getElementById('dashboard-search');

        if (statusFilter) statusFilter.value = '';
        if (riskFilter) riskFilter.value = '';
        if (searchInput) searchInput.value = '';

        this.loadDashboard();
    }

    updateDashboardStats(stats) {
        const summary = stats.summary || {};
        const riskDistribution = stats.risk_distribution || {};

        document.getElementById('total-changes').textContent = summary.total_changes || 0;
        document.getElementById('high-risk-count').textContent = summary.high_risk_changes || riskDistribution.High || 0;
        document.getElementById('medium-risk-count').textContent = summary.medium_risk_changes || riskDistribution.Medium || 0;
        document.getElementById('low-risk-count').textContent = summary.low_risk_changes || riskDistribution.Low || 0;
    }

    renderRecentChanges(changes) {
        const container = document.getElementById('recent-changes-list');
        container.innerHTML = '';

        changes.forEach(change => {
            const riskLevel = change.risk_level || 'Low';
            const div = document.createElement('div');
            div.className = 'change-item';
            div.innerHTML = `
                <div class="change-item-main">
                    <div class="change-title">${change.title}</div>
                    <div class="change-meta">${change.change_type} • ${change.status} • ${new Date(change.created_at).toLocaleDateString()}</div>
                </div>
                <div class="risk-summary">
                    <span class="change-risk risk-${riskLevel.toLowerCase()}">${riskLevel}</span>
                </div>
            `;
            container.appendChild(div);
        });
    }

    renderDashboardCharts(stats) {
        this.renderRiskChart(stats);
        this.renderWindowChart(stats);
        this.renderOwnerChart(stats);
    }

    renderRiskChart(stats) {
        const chartCanvas = document.getElementById('risk-chart');
        if (!chartCanvas || typeof Chart === 'undefined') {
            return;
        }

        if (this.riskChart) {
            this.riskChart.destroy();
            this.riskChart = null;
        }

        const ctx = chartCanvas.getContext('2d');
        const summary = stats.summary || {};
        const riskDistribution = stats.risk_distribution || {};
        const highRisk = summary.high_risk_changes || riskDistribution.High || 0;
        const mediumRisk = summary.medium_risk_changes || riskDistribution.Medium || 0;
        const lowRisk = summary.low_risk_changes || riskDistribution.Low || 0;
        
        this.riskChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['High Risk', 'Medium Risk', 'Low Risk'],
                datasets: [{
                    data: [
                        highRisk,
                        mediumRisk,
                        lowRisk
                    ],
                    backgroundColor: ['#ff4757', '#ffa502', '#2ed573'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    }

    renderWindowChart(stats) {
        const chartCanvas = document.getElementById('window-chart');
        if (!chartCanvas || typeof Chart === 'undefined') {
            return;
        }

        if (this.windowChart) {
            this.windowChart.destroy();
            this.windowChart = null;
        }

        const ctx = chartCanvas.getContext('2d');
        const windowDistribution = stats.window_distribution || {};
        
        this.windowChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Business Hours', 'Maintenance Window', 'Emergency'],
                datasets: [{
                    label: 'Changes by Window',
                    data: [
                        windowDistribution['business_hours'] || 0,
                        windowDistribution['maintenance_window'] || 0,
                        windowDistribution['emergency'] || 0
                    ],
                    backgroundColor: [
                        '#374151',
                        '#64748b',
                        '#94a3b8'
                    ],
                    borderWidth: 1,
                    borderColor: '#e5e7eb'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#f3f4f6'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    renderOwnerChart(stats) {
        const chartCanvas = document.getElementById('owner-chart');
        if (!chartCanvas || typeof Chart === 'undefined') {
            return;
        }

        if (this.ownerChart) {
            this.ownerChart.destroy();
            this.ownerChart = null;
        }

        const ctx = chartCanvas.getContext('2d');
        const ownerDistribution = stats.owner_distribution || {};
        
        // Sort owners by count and limit to top 10
        const sortedOwners = Object.entries(ownerDistribution)
            .sort(([,a], [,b]) => b - a)
            .slice(0, 10);
        
        const labels = sortedOwners.map(([owner]) => owner);
        const data = sortedOwners.map(([, count]) => count);
        
        this.ownerChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Changes by Owner',
                    data: data,
                    backgroundColor: '#667eea',
                    borderWidth: 1,
                    borderColor: '#e5e7eb'
                }]
            },
            options: {
                indexAxis: 'y', // This makes it a horizontal bar chart
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: {
                            color: '#f3f4f6'
                        }
                    },
                    y: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    async loadChanges(page = 1, per_page = 20) {
        try {
            const response = await fetch(`/api/changes/?page=${page}&per_page=${per_page}`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const changesPayload = await response.json();
                this.changes = this.extractChanges(changesPayload);
                this.renderChangesTable(this.changes);
                this.setupPagination(changesPayload);
            }
        } catch (error) {
            console.error('Error loading changes:', error);
        }
    }

    async loadRules() {
        try {
            const response = await fetch('/api/rules/risk-config', {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (!response.ok) {
                throw new Error('Failed to load risk rules');
            }

            const payload = await response.json();
            this.rules = payload.rules || [];
            this.renderRiskRuleCards(this.rules, Boolean(payload.can_edit));
            this.setRiskRulesStatus('', false);
        } catch (error) {
            this.setRiskRulesStatus('Unable to load risk classification rules.', true);
            console.error('Error loading rules:', error);
        }
    }

    renderRiskRuleCards(rules, canEdit) {
        const grid = document.getElementById('risk-rules-grid');
        const newBtn = document.getElementById('new-risk-rule-btn');
        if (!grid) {
            return;
        }

        if (newBtn) {
            newBtn.style.display = canEdit ? 'inline-block' : 'none';
        }

        if (!rules.length) {
            grid.innerHTML = '<div class="risk-rule-empty">No rules configured.</div>';
            return;
        }

        grid.innerHTML = rules.map((rule) => {
            const badgeClass = rule.risk_level === 'HIGH'
                ? 'risk-badge-high'
                : rule.risk_level === 'MEDIUM'
                    ? 'risk-badge-medium'
                    : 'risk-badge-low';
            const statusBadge = rule.status === 'active' ? 'Active' : 'Inactive';
            const toggleLabel = rule.status === 'active' ? 'Deactivate' : 'Activate';
            const toggleAction = rule.status !== 'active';

            return `
                <div class="risk-rule-card">
                    <div class="risk-rule-card-header">
                        <h4>${this.escapeHtml(rule.title || 'Untitled Rule')}</h4>
                        <span class="risk-level-badge ${badgeClass}">${this.escapeHtml(rule.risk_level || 'MEDIUM')}</span>
                    </div>
                    <div class="risk-rule-details">
                        <div><strong>Condition</strong><span>${this.escapeHtml(String(rule.condition || ''))}</span></div>
                        <div><strong>Base Score</strong><span>${this.escapeHtml(String(rule.base_score ?? 0))}</span></div>
                        <div><strong>Weight</strong><span>${this.escapeHtml(String(rule.weight ?? 1))}</span></div>
                        <div><strong>Thresholds</strong><span>${this.escapeHtml(String(rule.thresholds || ''))}</span></div>
                        <div><strong>Mandatory Fields</strong><span>${this.escapeHtml(String(rule.mandatory_fields || ''))}</span></div>
                        <div><strong>Status</strong><span class="status-pill ${rule.status === 'active' ? 'status-pill-active' : 'status-pill-inactive'}">${statusBadge}</span></div>
                    </div>
                    ${canEdit ? `
                        <div class="risk-rule-actions">
                            <button class="btn btn-secondary" onclick="app.openRiskRuleEditor(${rule.id})">Edit</button>
                            <button class="btn ${rule.status === 'active' ? 'btn-danger' : 'btn-success'}" onclick="app.toggleRiskRuleStatus(${rule.id}, ${toggleAction})">${toggleLabel}</button>
                        </div>
                    ` : ''}
                </div>
            `;
        }).join('');
    }

    openRiskRuleEditor(ruleId = null) {
        const editor = document.getElementById('risk-rule-editor');
        const titleEl = document.getElementById('risk-rule-editor-title');
        const idEl = document.getElementById('risk-rule-id');
        const titleInput = document.getElementById('risk-rule-title');
        const levelInput = document.getElementById('risk-rule-level');
        const conditionInput = document.getElementById('risk-rule-condition');
        const baseScoreInput = document.getElementById('risk-rule-base-score');
        const weightInput = document.getElementById('risk-rule-weight');
        const thresholdsInput = document.getElementById('risk-rule-thresholds');
        const mandatoryInput = document.getElementById('risk-rule-mandatory-fields');

        if (!editor || !idEl || !titleInput || !levelInput || !conditionInput || !baseScoreInput || !weightInput || !thresholdsInput || !mandatoryInput) {
            return;
        }

        const existing = ruleId ? this.rules.find((rule) => rule.id === ruleId) : null;
        if (existing) {
            titleEl.textContent = 'Edit Rule';
            idEl.value = String(existing.id);
            titleInput.value = existing.title || '';
            levelInput.value = existing.risk_level || 'MEDIUM';
            conditionInput.value = existing.condition || '';
            baseScoreInput.value = existing.base_score ?? 0;
            weightInput.value = existing.weight ?? 1;
            thresholdsInput.value = existing.thresholds || '';
            mandatoryInput.value = existing.mandatory_fields || '';
        } else {
            titleEl.textContent = 'New Rule';
            idEl.value = '';
            titleInput.value = '';
            levelInput.value = 'MEDIUM';
            conditionInput.value = '';
            baseScoreInput.value = 0;
            weightInput.value = 1;
            thresholdsInput.value = 'L: 0.0 · M: 30.0 · H: 60.0';
            mandatoryInput.value = '';
        }

        editor.style.display = 'block';
    }

    closeRiskRuleEditor() {
        const editor = document.getElementById('risk-rule-editor');
        if (editor) {
            editor.style.display = 'none';
        }
    }

    async saveRiskRule(e) {
        e.preventDefault();

        const id = document.getElementById('risk-rule-id')?.value;
        const payload = {
            title: document.getElementById('risk-rule-title')?.value?.trim(),
            risk_level: document.getElementById('risk-rule-level')?.value,
            condition: document.getElementById('risk-rule-condition')?.value?.trim(),
            base_score: Number(document.getElementById('risk-rule-base-score')?.value || 0),
            weight: Number(document.getElementById('risk-rule-weight')?.value || 1),
            thresholds: document.getElementById('risk-rule-thresholds')?.value?.trim(),
            mandatory_fields: document.getElementById('risk-rule-mandatory-fields')?.value?.trim(),
            status: 'active'
        };

        if (!payload.title || !payload.condition || !payload.thresholds) {
            this.setRiskRulesStatus('Please complete rule title, condition, and thresholds.', true);
            return;
        }

        try {
            const url = id ? `/api/rules/risk-config/${id}` : '/api/rules/risk-config';
            const method = id ? 'PUT' : 'POST';
            const response = await fetch(url, {
                method,
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.error || 'Unable to save rule');
            }

            this.setRiskRulesStatus('Rule saved successfully.', false);
            this.closeRiskRuleEditor();
            await this.loadRules();
        } catch (error) {
            this.setRiskRulesStatus(error.message || 'Unable to save rule.', true);
            console.error('Error saving risk rule:', error);
        }
    }

    async toggleRiskRuleStatus(ruleId, active) {
        try {
            const response = await fetch(`/api/rules/risk-config/${ruleId}/status`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ active })
            });

            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.error || 'Unable to update status');
            }

            this.setRiskRulesStatus('Rule status updated successfully.', false);
            await this.loadRules();
        } catch (error) {
            this.setRiskRulesStatus(error.message || 'Unable to update status.', true);
            console.error('Error updating risk rule status:', error);
        }
    }

    setRiskRulesStatus(message, isError) {
        const statusEl = document.getElementById('risk-rules-status');
        if (!statusEl) {
            return;
        }

        if (!message) {
            statusEl.style.display = 'none';
            statusEl.textContent = '';
            return;
        }

        statusEl.style.display = 'block';
        statusEl.textContent = message;
        statusEl.className = isError ? 'error-message' : 'success-message';
    }

    escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    renderChangesTable(changes) {
        const tbody = document.getElementById('changes-tbody');
        tbody.innerHTML = '';

        changes.forEach(change => {
            const riskLevel = change.risk_level || 'Low';
            const riskReason = this.getRiskReasoning(change);
            const changeIdentifier = change.change_id || `CHG-${String(change.id).padStart(4, '0')}`;
            const normalizedStatus = String(change.status || '').toLowerCase();
            const userRole = String(this.currentUser.role || '').toUpperCase();
            const canReview = (userRole === 'ADMIN' || userRole === 'CHANGE_MANAGER')
                && ['pending', 'submitted', 'review'].includes(normalizedStatus);
            const canEdit = normalizedStatus === 'pending' && (userRole === 'ADMIN' || userRole === 'CHANGE_MANAGER');
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${changeIdentifier}</td>
                <td>${change.title}</td>
                <td><span class="status-badge status-${change.status}">${change.status}</span></td>
                <td>
                    <div class="risk-cell">
                        <span class="change-risk risk-${riskLevel.toLowerCase()}">${riskLevel}</span>
                        <div class="risk-analysis-text">${riskReason}</div>
                    </div>
                </td>
                <td>${new Date(change.created_at).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-secondary" onclick="app.viewChange(${change.id})">View</button>
                    ${canEdit ? `<button class="btn btn-warning" onclick="app.editChange(${change.id})">Edit</button>` : ''}
                    ${canReview ? `<button class="btn btn-primary" onclick="app.approveChange(${change.id})">Approve</button>` : ''}
                    ${canReview ? `<button class="btn btn-danger" onclick="app.rejectChange(${change.id})">Reject</button>` : ''}
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    async loadUsers() {
        try {
            const response = await fetch('/api/users/', {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            const payload = await response.json();
            if (!response.ok) {
                throw new Error(payload.error || 'Unable to load users');
            }

            this.renderUsers(payload.users || []);
        } catch (error) {
            const usersList = document.getElementById('users-list');
            if (usersList) {
                usersList.innerHTML = `<div class="risk-rule-empty">${this.escapeHtml(error.message || 'Unable to load users')}</div>`;
            }
        }
    }

    renderUsers(users) {
        const usersList = document.getElementById('users-list');
        if (!usersList) {
            return;
        }

        if (!users.length) {
            usersList.innerHTML = '<div class="risk-rule-empty">No users found.</div>';
            return;
        }

        usersList.innerHTML = users.map((user) => `
            <div class="risk-rule-card">
                <div class="risk-rule-card-header">
                    <h4>${this.escapeHtml(user.full_name || user.username)}</h4>
                    <span class="status-pill ${user.is_active ? 'status-pill-active' : 'status-pill-inactive'}">${user.is_active ? 'Active' : 'Inactive'}</span>
                </div>
                <div class="risk-rule-details">
                    <div><strong>Username</strong><span>${this.escapeHtml(user.username || '')}</span></div>
                    <div><strong>Email</strong><span>${this.escapeHtml(user.email || '')}</span></div>
                    <div><strong>Role</strong><span>${this.escapeHtml(user.role || '')}</span></div>
                    <div><strong>Last Login</strong><span>${this.escapeHtml(user.last_login || 'Never')}</span></div>
                </div>
            </div>
        `).join('');
    }

    openUserForm() {
        const panel = document.getElementById('user-form-panel');
        if (panel) {
            panel.style.display = 'block';
        }
        this.setUserFormStatus('', false);
    }

    closeUserForm() {
        const panel = document.getElementById('user-form-panel');
        const form = document.getElementById('user-form');
        if (panel) {
            panel.style.display = 'none';
        }
        if (form) {
            form.reset();
        }
        this.setUserFormStatus('', false);
    }

    async handleCreateUser(e) {
        e.preventDefault();

        const payload = {
            full_name: document.getElementById('new-user-full-name')?.value?.trim(),
            role: document.getElementById('new-user-role')?.value,
            username: document.getElementById('new-user-username')?.value?.trim(),
            email: document.getElementById('new-user-email')?.value?.trim(),
            password: document.getElementById('new-user-password')?.value || ''
        };

        if (!payload.full_name || !payload.username || !payload.email || !payload.password) {
            this.setUserFormStatus('All fields are required to onboard a new user.', true);
            return;
        }

        try {
            const response = await fetch('/api/users/', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            const result = await response.json();
            if (!response.ok) {
                throw new Error(result.error || 'Unable to create user');
            }

            this.setUserFormStatus('User onboarded successfully.', false);
            await this.loadUsers();
            this.closeUserForm();
        } catch (error) {
            this.setUserFormStatus(error.message || 'Unable to create user.', true);
        }
    }

    setUserFormStatus(message, isError) {
        const statusEl = document.getElementById('user-form-status');
        if (!statusEl) {
            return;
        }

        if (!message) {
            statusEl.style.display = 'none';
            statusEl.textContent = '';
            return;
        }

        statusEl.style.display = 'block';
        statusEl.textContent = message;
        statusEl.className = isError ? 'error-message' : 'success-message';
    }

    extractChanges(payload) {
        if (Array.isArray(payload)) {
            return payload;
        }

        if (payload && Array.isArray(payload.changes)) {
            return payload.changes;
        }

        return [];
    }

    filterChanges() {
        const status = document.getElementById('status-filter').value;
        const risk = document.getElementById('risk-filter').value;
        const search = document.getElementById('search-input').value.toLowerCase();

        let filtered = this.changes;

        if (status) {
            filtered = filtered.filter(c => c.status === status);
        }

        if (risk) {
            filtered = filtered.filter(c => c.risk_level === risk);
        }

        if (search) {
            filtered = filtered.filter(c => 
                c.title.toLowerCase().includes(search) ||
                c.description.toLowerCase().includes(search)
            );
        }

        this.renderChangesTable(filtered);
    }

    async previewRisk() {
        const formData = new FormData(document.getElementById('change-form'));
        const data = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/rules/evaluate', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    context: {
                        change_type: data.change_type,
                        change_window: data.change_window,
                        critical_ci: data.critical_ci === 'true',
                        impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
                        rollback_plan: data.rollback_plan === 'true',
                        business_owner: data.business_owner,
                        technical_owner: data.technical_owner
                    }
                })
            });

            const result = await response.json();
            
            const previewDiv = document.getElementById('risk-preview');
            const resultDiv = document.getElementById('risk-result');
            
            previewDiv.style.display = 'block';
            
            if (result.results && result.results.length > 0) {
                const risk = result.results[0];
                resultDiv.innerHTML = `
                    <h4>Risk Assessment Result</h4>
                    <p><strong>Risk Level:</strong> <span class="change-risk risk-${risk.risk_level.toLowerCase()}">${risk.risk_level}</span></p>
                    <p><strong>Risk Score:</strong> ${risk.risk_score}</p>
                    <p><strong>Reason:</strong> ${risk.reason}</p>
                `;
            } else {
                resultDiv.innerHTML = '<p>No risk assessment available. Please check your inputs.</p>';
            }
        } catch (error) {
            console.error('Error previewing risk:', error);
        }
    }

    async handleCreateChange(e) {
        e.preventDefault();
        
        const formData = new FormData(document.getElementById('change-form'));
        const data = Object.fromEntries(formData);

        const changeData = {
            title: data.title,
            description: data.description,
            change_type: data.change_type,
            change_window: data.change_window,
            critical_ci: data.critical_ci === 'true',
            impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
            rollback_plan: data.rollback_plan === 'true',
            business_owner: data.business_owner,
            technical_owner: data.technical_owner
        };

        try {
            const response = await fetch('/api/changes', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(changeData)
            });

            const result = await response.json();

            if (response.ok) {
                alert('Change request created successfully!');
                document.getElementById('change-form').reset();
                document.getElementById('risk-preview').style.display = 'none';
                this.loadDashboard();
                this.switchView('changes');
            } else {
                alert('Error creating change: ' + result.error);
            }
        } catch (error) {
            console.error('Error creating change:', error);
        }
    }

    async viewChange(changeId) {
        try {
            const response = await fetch(`/api/changes/${changeId}`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const change = await response.json();
                this.showChangeModal(change);
            }
        } catch (error) {
            console.error('Error viewing change:', error);
        }
    }

    showChangeModal(change) {
        const modal = document.getElementById('change-modal');
        const content = document.getElementById('change-details-content');
        const riskLevel = change.risk_level || 'Low';
        const riskReason = this.getRiskReasoning(change);
        const riskFactors = this.getRiskFactors(change);
        const riskRecommendation = this.getRiskRecommendation(change);
        const missingInfo = this.getMissingInformation(change);
        const riskFactorsMarkup = riskFactors.length
            ? `<div class="risk-factor-list">${riskFactors.map(factor => `<span class="risk-factor-tag">${factor}</span>`).join('')}</div>`
            : '<div class="risk-analysis-text">No factor list available for this assessment.</div>';
        
        // Build missing info markup
        const missingInfoMarkup = missingInfo.length
            ? `<div class="missing-info-list">${missingInfo.map(info => `<span class="missing-info-tag">${info}</span>`).join('')}</div>`
            : '<div class="risk-analysis-text">All required information provided.</div>';
        
        content.innerHTML = `
            <div class="change-detail-item">
                <strong>Title:</strong> ${change.title}
            </div>
            <div class="change-detail-item">
                <strong>Description:</strong> ${change.description}
            </div>
            <div class="change-detail-item">
                <strong>Type:</strong> ${change.change_type}
            </div>
            <div class="change-detail-item">
                <strong>Window:</strong> ${change.change_window}
            </div>
            <div class="change-detail-item">
                <strong>Critical CI:</strong> ${change.critical_ci ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Impacted Services:</strong> ${Array.isArray(change.impacted_services) ? change.impacted_services.join(', ') : change.impacted_services || 'None'}
            </div>
            <div class="change-detail-item">
                <strong>Rollback Plan:</strong> ${change.rollback_plan ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Business Owner:</strong> ${change.business_owner}
            </div>
            <div class="change-detail-item">
                <strong>Technical Owner:</strong> ${change.technical_owner}
            </div>
            <div class="change-detail-item">
                <strong>Status:</strong> <span class="status-badge status-${change.status}">${change.status}</span>
            </div>
            <div class="change-detail-item">
                <strong>Risk Level:</strong> <span class="change-risk risk-${riskLevel.toLowerCase()}">${riskLevel}</span>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Missing Information:</strong>
                ${missingInfoMarkup}
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Analysis Basis:</strong>
                <div class="risk-analysis-text">${riskReason}</div>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Recommendation:</strong>
                <div class="risk-recommendation">${riskRecommendation}</div>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Contributing Factors:</strong>
                ${riskFactorsMarkup}
            </div>
            <div class="change-detail-item">
                <strong>Created:</strong> ${new Date(change.created_at).toLocaleString()}
            </div>
        `;

        modal.style.display = 'block';

        // Close modal functionality - ensure we find the correct close button
        const closeBtn = modal.querySelector('.close');
        if (closeBtn) {
            closeBtn.onclick = () => {
                modal.style.display = 'none';
            };
        }
        
        // Also add click event to any element with close-modal class
        const closeButtons = modal.querySelectorAll('.close-modal, .close-btn, [data-close]');
        closeButtons.forEach(btn => {
            btn.onclick = () => {
                modal.style.display = 'none';
            };
        });
        
        // Close when clicking outside modal content
        window.onclick = (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        };
    }

    getRiskReasoning(change) {
        // Check if change has risk_scores array
        if (Array.isArray(change.risk_scores) && change.risk_scores.length > 0) {
            const latestRisk = change.risk_scores[0];
            
            // First check if there's a separate risk_reasoning field
            if (latestRisk.risk_reasoning) {
                // Remove the recommendation part from reasoning
                const reasoning = latestRisk.risk_reasoning;
                const recommendationMatch = reasoning.match(/Recommendation:\s*(.+)/i);
                if (recommendationMatch) {
                    return reasoning.replace(/Recommendation:\s*.+/i, '').trim();
                }
                return reasoning;
            }
            
            // If no risk_reasoning, check if there's a recommendation field with full text
            if (latestRisk.recommendation) {
                const fullText = latestRisk.recommendation;
                // Extract everything before "RECOMMENDATION:" as reasoning
                const recommendationMatch = fullText.match(/(.+?)RECOMMENDATION:/i);
                if (recommendationMatch) {
                    return recommendationMatch[1].trim();
                }
                // If no RECOMMENDATION: marker, return the full text as reasoning
                return fullText;
            }
        }

        // Fallback to risk_analysis if it exists
        const riskAnalysis = change.risk_analysis || {};
        if (riskAnalysis.reasoning) {
            return riskAnalysis.reasoning;
        }

        return 'No model analysis available for this change.';
    }

    getRecentRiskReasoning(change) {
        const reasoning = this.getRiskReasoning(change);
        return reasoning.replace(/^Risk Score:\s*\d+\s*\/\s*100\.\s*/i, '');
    }

    getRiskFactors(change) {
        // Check if change has risk_scores array
        if (Array.isArray(change.risk_scores) && change.risk_scores.length > 0) {
            const latestRisk = change.risk_scores[0];
            if (latestRisk.risk_factors) {
                try {
                    // Try to parse as JSON if it's a string
                    if (typeof latestRisk.risk_factors === 'string') {
                        const parsed = JSON.parse(latestRisk.risk_factors);
                        if (Array.isArray(parsed)) {
                            return parsed;
                        }
                    } else if (Array.isArray(latestRisk.risk_factors)) {
                        return latestRisk.risk_factors;
                    }
                } catch (e) {
                    console.warn('Failed to parse risk factors:', e);
                }
            }
            
            // If no risk_factors field, try to extract factors from risk_reasoning
            if (latestRisk.risk_reasoning) {
                const factors = this.extractFactorsFromReasoning(latestRisk.risk_reasoning);
                if (factors.length > 0) {
                    return factors;
                }
            }
        }

        // Fallback to risk_analysis if it exists
        const riskAnalysis = change.risk_analysis || {};
        if (Array.isArray(riskAnalysis.factors) && riskAnalysis.factors.length > 0) {
            return riskAnalysis.factors;
        }

        return [];
    }

    extractFactorsFromReasoning(reasoning) {
        // Extract contributing factors from the reasoning text
        const factors = [];
        
        // Common factor patterns to look for
        const patterns = [
            /change type is (\w+)/i,  // "change type is normal"
            /scheduled during (\w+ \w+)/i,  // "scheduled during a maintenance window"
            /does not involve (\w+ \w+)/i,  // "does not involve critical infrastructure"
            /impacts? (\d+) systems?/i,  // "impacts several systems"
            /(\w+ plan) is (not )?available/i,  // "rollback plan is available/not available"
            /(\w+ infrastructure)/i,  // "critical infrastructure"
            /(\w+ window)/i,  // "maintenance window"
            /(\w+ modification)/i,  // "planned modification"
        ];
        
        // Look for specific systems mentioned
        const systemPatterns = [
            /(\w+ \w+)/g,  // Look for system names
        ];
        
        // Extract factors based on common phrases
        if (reasoning.includes('change type is')) {
            const match = reasoning.match(/change type is (\w+)/i);
            if (match) factors.push(`Change Type: ${match[1]}`);
        }
        
        if (reasoning.includes('maintenance window')) {
            factors.push('Scheduled during maintenance window');
        }
        
        if (reasoning.includes('critical infrastructure')) {
            factors.push('Involves critical infrastructure');
        } else if (reasoning.includes('does not involve critical infrastructure')) {
            factors.push('No critical infrastructure involved');
        }
        
        if (reasoning.includes('impacts') || reasoning.includes('impact')) {
            const match = reasoning.match(/impacts? (\d+) systems?/i);
            if (match) {
                factors.push(`Impacts ${match[1]} systems`);
            } else {
                factors.push('Has system impact');
            }
        }
        
        if (reasoning.includes('rollback plan')) {
            if (reasoning.includes('rollback plan is available')) {
                factors.push('Rollback plan available');
            } else if (reasoning.includes('no rollback plan')) {
                factors.push('No rollback plan available');
            }
        }
        
        // Look for specific system names
        const systemNames = reasoning.match(/\b(?:VPN|Remote Desktop|File Sharing|Database|Application|Backend|Reporting|System|Service)\b/gi);
        if (systemNames && systemNames.length > 0) {
            const uniqueSystems = [...new Set(systemNames.map(s => s.toLowerCase()))];
            if (uniqueSystems.length > 0) {
                factors.push(`Affected Systems: ${uniqueSystems.join(', ')}`);
            }
        }
        
        return factors;
    }

    getRiskRecommendation(change) {
        // Check if change has risk_scores array
        if (Array.isArray(change.risk_scores) && change.risk_scores.length > 0) {
            const latestRisk = change.risk_scores[0];
            
            // First check if there's a separate recommendation field
            if (latestRisk.recommendation) {
                const fullText = latestRisk.recommendation;
                // Extract everything after "RECOMMENDATION:" as the recommendation
                const recommendationMatch = fullText.match(/RECOMMENDATION:\s*(.+)/i);
                if (recommendationMatch) {
                    return recommendationMatch[1].trim();
                }
                // If no RECOMMENDATION: marker, return the full text as recommendation
                return fullText;
            }
            
            // If no recommendation field, try to extract from risk_reasoning
            if (latestRisk.risk_reasoning) {
                const reasoning = latestRisk.risk_reasoning;
                const recommendationMatch = reasoning.match(/Recommendation:\s*(.+)/i);
                if (recommendationMatch) {
                    return recommendationMatch[1].trim();
                }
                
                // Try other common patterns for recommendations
                const patterns = [
                    /Recommendation:\s*(.+)/i,
                    /Recommend:\s*(.+)/i,
                    /Suggestion:\s*(.+)/i,
                    /Advice:\s*(.+)/i,
                    /Next steps?:\s*(.+)/i
                ];
                
                for (const pattern of patterns) {
                    const match = reasoning.match(pattern);
                    if (match) {
                        return match[1].trim();
                    }
                }
            }
        }

        // Fallback to risk_analysis if it exists
        const riskAnalysis = change.risk_analysis || {};
        if (riskAnalysis.recommendation) {
            return riskAnalysis.recommendation;
        }

        return 'No recommendation available for this assessment.';
    }
    getMissingInformation(change) {
        const missing = [];
        
        // Check for missing required fields
        if (!change.change_type || change.change_type.trim() === '') {
            missing.push('Change Type');
        }
        
        if (!change.change_window || change.change_window.trim() === '') {
            missing.push('Change Window');
        }
        
        if (change.critical_ci === null || change.critical_ci === undefined) {
            missing.push('Critical CI');
        }
        
        if (!change.impacted_services || change.impacted_services.length === 0) {
            missing.push('Impacted Services');
        }
        
        if (change.rollback_plan === null || change.rollback_plan === undefined) {
            missing.push('Rollback Plan');
        }
        
        if (!change.business_owner || change.business_owner.trim() === '') {
            missing.push('Business Owner');
        }
        
        if (!change.technical_owner || change.technical_owner.trim() === '') {
            missing.push('Technical Owner');
        }
        
        return missing;
    }


    getMitigationSuggestions(change) {
        const riskAnalysis = change.risk_analysis || {};
        if (Array.isArray(riskAnalysis.mitigation_suggestions) && riskAnalysis.mitigation_suggestions.length > 0) {
            return riskAnalysis.mitigation_suggestions;
        }

        return [];
    }

    async approveChange(changeId) {
        if (!confirm('Are you sure you want to approve this change?')) {
            return;
        }

        try {
            const response = await fetch(`/api/changes/${changeId}/approve`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                alert('Change approved successfully!');
                this.loadChanges();
            } else {
                alert('Error approving change');
            }
        } catch (error) {
            console.error('Error approving change:', error);
        }
    }

    async rejectChange(changeId) {
        const reason = prompt('Enter rejection reason:', 'Insufficient implementation readiness');
        if (reason === null) {
            return;
        }

        try {
            const response = await fetch(`/api/changes/${changeId}/reject`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ reason: reason.trim() || 'No reason provided' })
            });

            const result = await response.json();
            if (response.ok) {
                alert(result.message || 'Change rejected successfully!');
                this.loadChanges();
            } else {
                alert(result.error || 'Error rejecting change');
            }
        } catch (error) {
            console.error('Error rejecting change:', error);
            alert('Error rejecting change');
        }
    }

    async exportChanges() {
        const exportBtn = document.getElementById('export-changes-btn');
        this.setExportButtonLoading(true, exportBtn);

        const format = document.getElementById('changes-export-format')?.value || 'csv';
        const status = document.getElementById('status-filter')?.value;
        const riskLevel = document.getElementById('risk-filter')?.value;

        const params = new URLSearchParams();
        if (status) {
            params.set('status', status);
        }
        if (riskLevel) {
            params.set('risk_level', riskLevel);
        }

        try {
            const response = await fetch(`/api/export/changes/${format}?${params.toString()}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            const payload = await response.json();
            if (!response.ok) {
                throw new Error(payload.error || 'Unable to export changes');
            }

            this.downloadExportPayload(payload, format);
        } catch (error) {
            console.error('Error exporting changes:', error);
            alert(error.message || 'Export failed. Please try again.');
        } finally {
            this.setExportButtonLoading(false, exportBtn);
        }
    }

    async exportDashboard() {
        const timePeriod = document.getElementById('dashboard-time-period').value;

        try {
            const response = await fetch(`/api/export/dashboard-summary/csv?time_period=${timePeriod}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            const payload = await response.json();
            if (!response.ok) {
                throw new Error(payload.error || 'Unable to export dashboard summary');
            }

            this.downloadExportPayload(payload, 'csv');
        } catch (error) {
            console.error('Error exporting dashboard:', error);
            alert(error.message || 'Export failed. Please try again.');
        }
    }

    downloadExportPayload(payload, format) {
        const filename = payload.filename || `export.${format}`;
        const content = payload.content || '';

        let blob;
        if (format === 'csv') {
            blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
        } else {
            const bytes = new Uint8Array(content.length);
            for (let i = 0; i < content.length; i += 1) {
                bytes[i] = content.charCodeAt(i) & 0xff;
            }
            const mimeType = format === 'pdf'
                ? 'application/pdf'
                : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
            blob = new Blob([bytes], { type: mimeType });
        }

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    }

    setExportButtonLoading(isLoading, buttonEl) {
        if (!buttonEl) {
            return;
        }

        if (isLoading) {
            buttonEl.disabled = true;
            buttonEl.dataset.originalText = buttonEl.textContent;
            buttonEl.textContent = 'Exporting...';
            return;
        }

        buttonEl.disabled = false;
        buttonEl.textContent = buttonEl.dataset.originalText || 'Export';
    }

    logout() {
        localStorage.removeItem('token');
        this.token = null;
        this.currentUser = null;
        this.showPage('login-page');
    }

    setupPagination(changesPayload) {
        const paginationControls = document.getElementById('pagination-controls');
        const prevPageBtn = document.getElementById('prev-page-btn');
        const nextPageBtn = document.getElementById('next-page-btn');
        const pageInfo = document.getElementById('page-info');
        const pageSelect = document.getElementById('page-select');

        if (!paginationControls || !prevPageBtn || !nextPageBtn || !pageInfo || !pageSelect) {
            return;
        }

        // Extract pagination info from payload - handle both old and new API formats
        let total, perPage, currentPage, totalPages;
        
        if (changesPayload.pagination) {
            // New API format with nested pagination object
            total = changesPayload.pagination.total || 0;
            perPage = changesPayload.pagination.per_page || 20;
            currentPage = changesPayload.pagination.page || 1;
            totalPages = changesPayload.pagination.pages || Math.ceil(total / perPage);
        } else {
            // Old API format with direct fields
            total = changesPayload.total || 0;
            perPage = changesPayload.per_page || 20;
            currentPage = changesPayload.current_page || 1;
            totalPages = Math.ceil(total / perPage);
        }

        // Show/hide pagination controls based on total records
        if (total <= perPage) {
            paginationControls.style.display = 'none';
            return;
        }

        paginationControls.style.display = 'flex';

        // Update page info
        pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;

        // Update previous button
        prevPageBtn.disabled = currentPage <= 1;
        
        // Update next button
        nextPageBtn.disabled = currentPage >= totalPages;

        // Update page select dropdown
        pageSelect.innerHTML = '';
        for (let i = 1; i <= totalPages; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = `Page ${i}`;
            if (i === currentPage) {
                option.selected = true;
            }
            pageSelect.appendChild(option);
        }
    }

    handlePagination(action, pageNumber = null) {
        const paginationControls = document.getElementById('pagination-controls');
        const pageInfo = document.getElementById('page-info');
        const pageSelect = document.getElementById('page-select');

        if (!paginationControls || !pageInfo || !pageSelect) {
            return;
        }

        // Get current pagination state
        const currentPageText = pageInfo.textContent;
        const currentPage = parseInt(currentPageText.match(/Page (\d+)/)?.[1] || '1');
        const totalPages = parseInt(currentPageText.match(/of (\d+)/)?.[1] || '1');

        let newPage = currentPage;

        switch (action) {
            case 'prev':
                newPage = Math.max(1, currentPage - 1);
                break;
            case 'next':
                newPage = Math.min(totalPages, currentPage + 1);
                break;
            case 'select':
                newPage = pageNumber || currentPage;
                break;
        }

        // Load the new page
        this.loadChanges(newPage, 20);
    }

    async previewManualRisk() {
        const formData = new FormData(document.getElementById('manual-change-form'));
        const data = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/rules/evaluate', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    context: {
                        change_type: data.change_type,
                        change_window: data.change_window,
                        critical_ci: data.critical_ci === 'true',
                        impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
                        rollback_plan: data.rollback_plan === 'true',
                        business_owner: data.business_owner,
                        technical_owner: data.technical_owner
                    }
                })
            });

            const result = await response.json();
            
            const previewDiv = document.getElementById('manual-risk-preview');
            const resultDiv = document.getElementById('manual-risk-result');
            
            previewDiv.style.display = 'block';
            
            if (result.results && result.results.length > 0) {
                const risk = result.results[0];
                resultDiv.innerHTML = `
                    <h4>Risk Assessment Result</h4>
                    <p><strong>Risk Level:</strong> <span class="change-risk risk-${risk.risk_level.toLowerCase()}">${risk.risk_level}</span></p>
                    <p><strong>Risk Score:</strong> ${risk.risk_score}</p>
                    <p><strong>Reason:</strong> ${risk.reason}</p>
                `;
            } else {
                resultDiv.innerHTML = '<p>No risk assessment available. Please check your inputs.</p>';
            }
        } catch (error) {
            console.error('Error previewing risk:', error);
        }
    }

    async handleManualCreateChange(e) {
        e.preventDefault();
        
        const formData = new FormData(document.getElementById('manual-change-form'));
        const data = Object.fromEntries(formData);

        const changeData = {
            title: data.title,
            description: data.description,
            change_type: data.change_type,
            change_window: data.change_window,
            critical_ci: data.critical_ci === 'true',
            impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
            dependencies: data.dependencies ? data.dependencies.split(',').map(s => s.trim()) : [],
            rollback_plan: data.rollback_plan === 'true',
            blast_radius: data.blast_radius || 'Single Datacenter',
            business_owner: data.business_owner,
            technical_owner: data.technical_owner
        };

        try {
            const response = await fetch('/api/changes', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(changeData)
            });

            const result = await response.json();

            if (response.ok) {
                alert('Change request created successfully!');
                document.getElementById('manual-change-form').reset();
                document.getElementById('manual-risk-preview').style.display = 'none';
                this.loadChanges();
            } else {
                alert('Error creating change: ' + result.error);
            }
        } catch (error) {
            console.error('Error creating change:', error);
        }
    }

    async editChange(changeId) {
        try {
            const response = await fetch(`/api/changes/${changeId}`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const change = await response.json();
                this.showEditModal(change);
            }
        } catch (error) {
            console.error('Error loading change for edit:', error);
        }
    }

    showEditModal(change) {
        const modal = document.getElementById('edit-change-modal');
        const form = document.getElementById('edit-change-form');
        
        // Set form values
        document.getElementById('edit-change-id').value = change.id;
        document.getElementById('edit-change-title').value = change.title;
        document.getElementById('edit-change-type').value = change.change_type;
        document.getElementById('edit-change-window').value = change.change_window;
        document.getElementById('edit-critical-ci').value = change.critical_ci ? 'true' : 'false';
        document.getElementById('edit-impacted-services').value = change.impacted_services.join(', ');
        document.getElementById('edit-dependencies').value = change.dependencies ? change.dependencies.join(', ') : '';
        document.getElementById('edit-rollback-plan').value = change.rollback_plan ? 'true' : 'false';
        document.getElementById('edit-blast-radius').value = change.blast_radius || 'Single Datacenter';
        document.getElementById('edit-business-owner').value = change.business_owner;
        document.getElementById('edit-technical-owner').value = change.technical_owner;
        document.getElementById('edit-change-description').value = change.description;

        modal.style.display = 'block';
    }

    async previewEditRisk() {
        const formData = new FormData(document.getElementById('edit-change-form'));
        const data = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/rules/evaluate', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    context: {
                        change_type: data.change_type,
                        change_window: data.change_window,
                        critical_ci: data.critical_ci === 'true',
                        impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
                        rollback_plan: data.rollback_plan === 'true',
                        business_owner: data.business_owner,
                        technical_owner: data.technical_owner
                    }
                })
            });

            const result = await response.json();
            
            const previewDiv = document.getElementById('edit-risk-preview');
            const resultDiv = document.getElementById('edit-risk-result');
            
            previewDiv.style.display = 'block';
            
            if (result.results && result.results.length > 0) {
                const risk = result.results[0];
                resultDiv.innerHTML = `
                    <h4>Risk Assessment Result</h4>
                    <p><strong>Risk Level:</strong> <span class="change-risk risk-${risk.risk_level.toLowerCase()}">${risk.risk_level}</span></p>
                    <p><strong>Risk Score:</strong> ${risk.risk_score}</p>
                    <p><strong>Reason:</strong> ${risk.reason}</p>
                `;
            } else {
                resultDiv.innerHTML = '<p>No risk assessment available. Please check your inputs.</p>';
            }
        } catch (error) {
            console.error('Error previewing risk:', error);
        }
    }

    async handleEditChange(e) {
        e.preventDefault();
        
        const formData = new FormData(document.getElementById('edit-change-form'));
        const data = Object.fromEntries(formData);
        const changeId = document.getElementById('edit-change-id').value;

        const changeData = {
            title: data.title,
            description: data.description,
            change_type: data.change_type,
            change_window: data.change_window,
            critical_ci: data.critical_ci === 'true',
            impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
            dependencies: data.dependencies ? data.dependencies.split(',').map(s => s.trim()) : [],
            rollback_plan: data.rollback_plan === 'true',
            blast_radius: data.blast_radius || 'Single Datacenter',
            business_owner: data.business_owner,
            technical_owner: data.technical_owner
        };

        try {
            const response = await fetch(`/api/changes/${changeId}`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(changeData)
            });

            const result = await response.json();

            if (response.ok) {
                alert('Change request updated successfully!');
                document.getElementById('edit-change-modal').style.display = 'none';
                this.loadChanges();
            } else {
                alert('Error updating change: ' + result.error);
            }
        } catch (error) {
            console.error('Error updating change:', error);
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ChangeRiskApp();
});