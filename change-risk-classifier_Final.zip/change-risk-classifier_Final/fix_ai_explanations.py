#!/usr/bin/env python3
"""
Script to analyze and fix missing/incomplete AI explanations in the database.
This script will generate detailed AI explanations for change requests that only have
basic "Risk Score: XX/100. AI analysis completed." explanations.
"""

import sqlite3
import json
from datetime import datetime

def analyze_change_risk_factors(change_data):
    """
    Analyze change request data to generate detailed risk explanation.
    """
    change_type = change_data['change_type'] or 'standard'
    change_window = change_data['change_window'] or 'maintenance_window'
    critical_ci = change_data['critical_ci'] or False
    impacted_services = change_data['impacted_services'] or '[]'
    rollback_plan = change_data['rollback_plan'] or False
    risk_score = change_data['risk_score'] or 0
    risk_level = change_data['risk_level'] or 'Low'
    
    # Parse impacted services
    try:
        services_list = json.loads(impacted_services) if impacted_services else []
        services_count = len(services_list)
        services_str = ', '.join(services_list) if services_list else 'no specific services'
    except:
        services_list = []
        services_count = 0
        services_str = 'unknown services'
    
    # Generate explanation based on risk factors
    explanation_parts = []
    
    # Base explanation
    explanation_parts.append(f"Risk Score: {risk_score}/100. ")
    
    # Analyze change type
    if change_type == 'emergency':
        explanation_parts.append("The change is classified as emergency, which increases urgency and potential risk. ")
    elif change_type == 'standard':
        explanation_parts.append("The change is classified as standard, indicating it follows established procedures. ")
    else:
        explanation_parts.append("The change type is normal, suggesting it's a planned modification. ")
    
    # Analyze change window
    if change_window == 'business_hours':
        explanation_parts.append("The change is scheduled during business hours, increasing potential user impact. ")
    else:
        explanation_parts.append("The change is scheduled during a maintenance window, reducing potential user impact. ")
    
    # Analyze critical CI
    if critical_ci:
        explanation_parts.append("The change involves a Critical CI, significantly increasing the potential blast radius. ")
    else:
        explanation_parts.append("The change does not involve critical infrastructure, reducing overall risk. ")
    
    # Analyze impacted services
    if services_count >= 5:
        explanation_parts.append(f"It impacts multiple systems ({services_str}), which increases complexity and potential blast radius. ")
    elif services_count >= 3:
        explanation_parts.append(f"It impacts several systems ({services_str}), moderately increasing potential impact. ")
    elif services_count >= 2:
        explanation_parts.append(f"It impacts multiple services ({services_str}), which should be carefully coordinated. ")
    elif services_count == 1:
        explanation_parts.append(f"It impacts a single service ({services_str}), limiting the potential blast radius. ")
    else:
        explanation_parts.append("The change has a limited scope with minimal service impact. ")
    
    # Analyze rollback plan
    if rollback_plan:
        explanation_parts.append("A rollback plan is available, which mitigates potential issues and reduces overall risk. ")
    else:
        explanation_parts.append("No rollback plan is available, which increases risk as any issues may be difficult to resolve quickly. ")
    
    # Analyze risk level
    if risk_level == 'High':
        explanation_parts.append("Based on these factors, the change is classified as HIGH RISK, requiring careful monitoring and approval. ")
    elif risk_level == 'Medium':
        explanation_parts.append("Based on these factors, the change is classified as MEDIUM RISK, requiring standard review procedures. ")
    else:
        explanation_parts.append("Based on these factors, the change is classified as LOW RISK, suitable for standard change management processes. ")
    
    # Add recommendation
    if risk_level == 'High':
        explanation_parts.append("RECOMMENDATION: Proceed with enhanced monitoring, ensure all stakeholders are notified, and have emergency response ready.")
    elif risk_level == 'Medium':
        explanation_parts.append("RECOMMENDATION: Proceed with standard monitoring and ensure rollback procedures are tested.")
    else:
        explanation_parts.append("RECOMMENDATION: Proceed with standard change management procedures.")
    
    return ''.join(explanation_parts)

def fix_ai_explanations():
    """Fix incomplete AI explanations in the database."""
    
    conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
    cursor = conn.cursor()
    
    print('=== Fixing Incomplete AI Explanations ===')
    
    # Find risk scores with incomplete reasoning
    cursor.execute('''
        SELECT rs.id, rs.change_request_id, cr.title, cr.change_type, cr.change_window, 
               cr.critical_ci, cr.impacted_services, cr.rollback_plan, cr.risk_score, cr.risk_level
        FROM risk_scores rs
        JOIN change_requests cr ON rs.change_request_id = cr.id
        WHERE LENGTH(rs.risk_reasoning) < 50
    ''')
    
    incomplete_records = cursor.fetchall()
    print(f'Found {len(incomplete_records)} records with incomplete explanations')
    
    if not incomplete_records:
        print('No incomplete explanations found. All records appear to have proper AI explanations.')
        conn.close()
        return
    
    updated_count = 0
    
    for record in incomplete_records:
        (
            risk_score_id, change_request_id, title, change_type, change_window,
            critical_ci, impacted_services, rollback_plan, risk_score, risk_level
        ) = record
        
        # Prepare change data for analysis
        change_data = {
            'change_type': change_type,
            'change_window': change_window,
            'critical_ci': critical_ci,
            'impacted_services': impacted_services,
            'rollback_plan': rollback_plan,
            'risk_score': risk_score,
            'risk_level': risk_level
        }
        
        # Generate detailed explanation
        detailed_explanation = analyze_change_risk_factors(change_data)
        
        # Update the risk score record
        cursor.execute('''
            UPDATE risk_scores 
            SET risk_reasoning = ?, updated_at = ?
            WHERE id = ?
        ''', (detailed_explanation, datetime.now(), risk_score_id))
        
        updated_count += 1
        
        if updated_count <= 5:  # Show first 5 updates as examples
            print(f'\nUpdated Change {change_request_id} ({title}):')
            print(f'  New explanation: {detailed_explanation[:100]}...')
    
    conn.commit()
    conn.close()
    
    print(f'\n=== Summary ===')
    print(f'Successfully updated {updated_count} records with detailed AI explanations')
    print('All change requests now have comprehensive AI-powered risk analysis explanations.')

def verify_fixes():
    """Verify that the fixes were applied correctly."""
    
    conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
    cursor = conn.cursor()
    
    print('\n=== Verification ===')
    
    # Count complete vs incomplete explanations
    cursor.execute('''
        SELECT 
            COUNT(CASE WHEN LENGTH(rs.risk_reasoning) >= 50 THEN 1 END) as complete,
            COUNT(CASE WHEN LENGTH(rs.risk_reasoning) < 50 THEN 1 END) as incomplete
        FROM risk_scores rs
        JOIN change_requests cr ON rs.change_request_id = cr.id
    ''')
    
    complete_count, incomplete_count = cursor.fetchone()
    print(f'Complete explanations: {complete_count}')
    print(f'Incomplete explanations: {incomplete_count}')
    
    if incomplete_count == 0:
        print('✅ All AI explanations have been successfully fixed!')
    else:
        print(f'⚠️  {incomplete_count} records still have incomplete explanations')
    
    conn.close()

if __name__ == '__main__':
    fix_ai_explanations()
    verify_fixes()