#!/usr/bin/env python3
"""
Script to check database structure and identify missing AI explanations.
"""

import sqlite3
import json

def check_database_structure():
    # Connect to the database
    conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
    cursor = conn.cursor()

    # Get all table names
    cursor.execute('SELECT name FROM sqlite_master WHERE type="table"')
    tables = cursor.fetchall()

    print('Tables in database:')
    for table in tables:
        print(f'  {table[0]}')

    # Check the structure of the main tables
    print('\n=== change_requests table structure ===')
    cursor.execute('PRAGMA table_info(change_requests)')
    columns = cursor.fetchall()
    for col in columns:
        print(f'  {col[1]} ({col[2]})')

    print('\n=== risk_scores table structure ===')
    cursor.execute('PRAGMA table_info(risk_scores)')
    columns = cursor.fetchall()
    for col in columns:
        print(f'  {col[1]} ({col[2]})')

    # Check for missing AI explanations
    print('\n=== Checking for Missing AI Explanations ===')
    
    # Get sample data to understand the structure
    cursor.execute('''
        SELECT cr.id, cr.title, cr.risk_analysis, rs.risk_reasoning, rs.risk_factors
        FROM change_requests cr
        LEFT JOIN risk_scores rs ON cr.id = rs.change_request_id
        ORDER BY cr.id
        LIMIT 10
    ''')

    results = cursor.fetchall()
    
    missing_explanations = []
    for row in results:
        change_id, title, risk_analysis, risk_reasoning, risk_factors = row
        
        # Check if risk_analysis exists and has reasoning
        risk_analysis_has_reasoning = False
        if risk_analysis:
            try:
                risk_data = json.loads(risk_analysis)
                if risk_data.get('reasoning'):
                    risk_analysis_has_reasoning = True
            except:
                pass
        
        # Check if risk_scores has reasoning
        risk_scores_has_reasoning = bool(risk_reasoning)
        
        if not risk_analysis_has_reasoning and not risk_scores_has_reasoning:
            missing_explanations.append({
                'id': change_id,
                'title': title,
                'risk_analysis': risk_analysis,
                'risk_reasoning': risk_reasoning
            })
            print(f'Change {change_id} ({title}): Missing AI explanation')
            print(f'  risk_analysis: {risk_analysis}')
            print(f'  risk_reasoning: {risk_reasoning}')
            print()

    print(f'\nTotal changes with missing explanations: {len(missing_explanations)}')
    
    # Check total count of changes
    cursor.execute('SELECT COUNT(*) FROM change_requests')
    total_changes = cursor.fetchone()[0]
    print(f'Total changes in database: {total_changes}')
    
    conn.close()

if __name__ == '__main__':
    check_database_structure()