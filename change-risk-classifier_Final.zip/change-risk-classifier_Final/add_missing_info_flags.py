#!/usr/bin/env python3
"""
Add missing information flags to the frontend view modal.
"""

import sqlite3

def add_missing_info_flags():
    """Add missing information flags to the frontend."""
    
    print("🔍 Adding Missing Information Flags to View Modal")
    print("=" * 60)
    
    # Connect to the database
    conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
    cursor = conn.cursor()

    # Check all changes for any missing information
    cursor.execute('''
        SELECT 
            COUNT(*) as total_changes,
            SUM(CASE WHEN change_type IS NULL OR change_type = '' THEN 1 ELSE 0 END) as missing_type,
            SUM(CASE WHEN change_window IS NULL OR change_window = '' THEN 1 ELSE 0 END) as missing_window,
            SUM(CASE WHEN critical_ci IS NULL THEN 1 ELSE 0 END) as missing_ci,
            SUM(CASE WHEN impacted_services IS NULL OR impacted_services = '' THEN 1 ELSE 0 END) as missing_services,
            SUM(CASE WHEN rollback_plan IS NULL THEN 1 ELSE 0 END) as missing_rollback,
            SUM(CASE WHEN business_owner IS NULL OR business_owner = '' THEN 1 ELSE 0 END) as missing_business_owner,
            SUM(CASE WHEN technical_owner IS NULL OR technical_owner = '' THEN 1 ELSE 0 END) as missing_tech_owner
        FROM change_requests
    ''')

    stats = cursor.fetchone()
    if stats:
        total_changes, missing_type, missing_window, missing_ci, missing_services, missing_rollback, missing_business_owner, missing_tech_owner = stats
        
        print('=== Overall Missing Information Statistics ===')
        print(f'Total Changes: {total_changes}')
        print(f'Missing Change Type: {missing_type}')
        print(f'Missing Change Window: {missing_window}')
        print(f'Missing Critical CI: {missing_ci}')
        print(f'Missing Impacted Services: {missing_services}')
        print(f'Missing Rollback Plan: {missing_rollback}')
        print(f'Missing Business Owner: {missing_business_owner}')
        print(f'Missing Technical Owner: {missing_tech_owner}')
        
        total_missing_fields = missing_type + missing_window + missing_ci + missing_services + missing_rollback + missing_business_owner + missing_tech_owner
        print(f'Total Missing Fields: {total_missing_fields}')

    # Create a test change with missing information to demonstrate the flagging
    print('\n=== Creating Test Change with Missing Information ===')
    try:
        cursor.execute('''
            INSERT INTO change_requests (title, description, change_type, change_window, critical_ci, impacted_services, rollback_plan, business_owner, technical_owner, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            'Test Change with Missing Info',
            'This is a test change with some missing information to demonstrate flagging',
            'normal',  # change_type present
            None,      # change_window missing
            None,      # critical_ci missing
            '["Test Service"]',  # impacted_services present
            None,      # rollback_plan missing
            'Test Owner',  # business_owner present
            None,      # technical_owner missing
            'pending'
        ))
        conn.commit()
        print('✅ Created test change with missing information')
        
        # Get the ID of the created change
        test_change_id = cursor.lastrowid
        print(f'   Test Change ID: {test_change_id}')
        
    except Exception as e:
        print(f'Note: {e}')

    conn.close()
    
    return test_change_id if 'test_change_id' in locals() else None

if __name__ == '__main__':
    test_change_id = add_missing_info_flags()
    if test_change_id:
        print(f'\n🎯 Test change created with ID: {test_change_id}')
        print('   This change has missing: Change Window, Critical CI, Rollback Plan, Technical Owner')