#!/usr/bin/env python3
"""
Database Export Script for Change Risk Classifier

This script exports data from the SQLite database to various formats
including CSV and JSON for analysis and reporting.
"""

import sqlite3
import json
import csv
import os
from datetime import datetime
from pathlib import Path

def connect_to_database(db_path):
    """Connect to the SQLite database."""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row  # This enables column access by name
        return conn
    except sqlite3.Error as e:
        print(f"Error connecting to database: {e}")
        return None

def get_table_names(conn):
    """Get all table names from the database."""
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return [row[0] for row in cursor.fetchall()]

def export_table_to_csv(conn, table_name, output_dir):
    """Export a table to CSV format."""
    cursor = conn.cursor()
    
    # Get column names
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [row[1] for row in cursor.fetchall()]
    
    # Get data
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    
    # Create output file path
    csv_file = os.path.join(output_dir, f"{table_name}.csv")
    
    with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        
        # Write header
        writer.writerow(columns)
        
        # Write data
        for row in rows:
            writer.writerow(row)
    
    print(f"✓ Exported {table_name} to {csv_file}")
    return csv_file

def export_table_to_json(conn, table_name, output_dir):
    """Export a table to JSON format."""
    cursor = conn.cursor()
    
    # Get data
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    
    # Convert to list of dictionaries
    data = []
    for row in rows:
        row_dict = dict(row)
        # Convert any datetime strings to proper format if needed
        for key, value in row_dict.items():
            if isinstance(value, str) and value.startswith(('202', '199', '200', '201')):
                try:
                    # Try to parse as datetime
                    datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f')
                except ValueError:
                    pass
        data.append(row_dict)
    
    # Create output file path
    json_file = os.path.join(output_dir, f"{table_name}.json")
    
    with open(json_file, 'w', encoding='utf-8') as jsonfile:
        json.dump(data, jsonfile, indent=2, default=str)
    
    print(f"✓ Exported {table_name} to {json_file}")
    return json_file

def export_database(db_path, output_format='both'):
    """
    Export the entire database to specified format(s).
    
    Args:
        db_path (str): Path to the SQLite database file
        output_format (str): 'csv', 'json', or 'both'
    """
    
    # Check if database exists
    if not os.path.exists(db_path):
        print(f"Error: Database file not found at {db_path}")
        return False
    
    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"database_export_{timestamp}"
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"📁 Creating export directory: {output_dir}")
    
    # Connect to database
    conn = connect_to_database(db_path)
    if not conn:
        return False
    
    try:
        # Get table names
        tables = get_table_names(conn)
        print(f"📊 Found {len(tables)} tables: {', '.join(tables)}")
        
        exported_files = []
        
        # Export each table
        for table in tables:
            print(f"\n🔄 Exporting table: {table}")
            
            if output_format in ['csv', 'both']:
                csv_file = export_table_to_csv(conn, table, output_dir)
                exported_files.append(csv_file)
            
            if output_format in ['json', 'both']:
                json_file = export_table_to_json(conn, table, output_dir)
                exported_files.append(json_file)
        
        # Create summary file
        summary_file = os.path.join(output_dir, "export_summary.txt")
        with open(summary_file, 'w') as f:
            f.write(f"Database Export Summary\n")
            f.write(f"======================\n")
            f.write(f"Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Database: {db_path}\n")
            f.write(f"Tables Exported: {len(tables)}\n")
            f.write(f"Tables: {', '.join(tables)}\n")
            f.write(f"Output Format: {output_format}\n")
            f.write(f"\nExported Files:\n")
            for file in exported_files:
                f.write(f"- {file}\n")
        
        print(f"\n✅ Export completed successfully!")
        print(f"📁 Export directory: {output_dir}")
        print(f"📄 Summary file: {summary_file}")
        
        # List all exported files
        print(f"\n📋 Exported files:")
        for file in exported_files:
            print(f"   • {os.path.basename(file)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error during export: {e}")
        return False
    
    finally:
        conn.close()

def main():
    """Main function to run the export script."""
    print("🚀 Change Risk Classifier Database Export Tool")
    print("=" * 50)
    
    # Database path
    db_path = "backend/instance/change_risk_classifier.db"
    
    # Check if we're in the right directory
    if not os.path.exists(db_path):
        print(f"❌ Database not found at {db_path}")
        print("Please run this script from the project root directory.")
        return
    
    # Ask user for export format
    while True:
        print("\nSelect export format:")
        print("1. CSV only")
        print("2. JSON only") 
        print("3. Both CSV and JSON (default)")
        
        choice = input("\nEnter your choice (1-3) [default: 3]: ").strip()
        
        if choice == '1':
            output_format = 'csv'
            break
        elif choice == '2':
            output_format = 'json'
            break
        elif choice == '3' or choice == '':
            output_format = 'both'
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")
    
    # Run export
    success = export_database(db_path, output_format)
    
    if success:
        print(f"\n🎉 Database export completed successfully!")
        print(f"📁 Check the 'database_export_*' folder for your files.")
    else:
        print(f"\n❌ Database export failed.")
        print(f"Please check the error messages above.")

if __name__ == "__main__":
    main()