#!/usr/bin/env python3
"""
Test the dashboard service to see how many records it returns
"""

import os
import sys

# Set environment
os.environ['FORCE_SAMPLE_DATA'] = 'false'
sys.path.insert(0, 'backend')

from app import create_app
app = create_app()

with app.app_context():
    from services.dashboard_service import DashboardService
    
    # Test the dashboard service directly
    result = DashboardService.get_filtered_changes({}, None, 1, 20)
    print(f'Dashboard service returned: {len(result.get("changes", []))} changes')
    print(f'Total count: {result.get("pagination", {}).get("total", 0)}')
    
    # Check the first few changes
    changes = result.get('changes', [])
    for i, change in enumerate(changes[:5]):
        print(f'  Change {i+1}: ID={change.get("id")}, Title={change.get("title")}')
    
    # Test with different page sizes
    result_100 = DashboardService.get_filtered_changes({}, None, 1, 100)
    print(f'\nWith per_page=100: {len(result_100.get("changes", []))} changes')
    print(f'Total count: {result_100.get("pagination", {}).get("total", 0)}')