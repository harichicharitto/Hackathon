#!/usr/bin/env python3
"""
Test script to verify dashboard filter logic and identify issues.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up the path to find config
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'backend'))

from backend.app import create_app
from backend.models import db, ChangeRequest, RiskScore
from backend.services.dashboard_service import DashboardService

def test_filter_combinations():
    """Test various filter combinations to identify issues."""
    
    app = create_app()
    
    with app.app_context():
        print("=== Testing Dashboard Filter Combinations ===\n")
        
        # Test 1: No filters (baseline)
        print("1. No filters (baseline):")
        summary = DashboardService.get_dashboard_summary()
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Status distribution: {summary.get('status_distribution', {})}")
        print(f"   Risk distribution: {summary.get('risk_distribution', {})}")
        print()
        
        # Test 2: Single status filter
        print("2. Single status filter (pending):")
        summary = DashboardService.get_dashboard_summary(filters={'status': 'submitted'})
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Status distribution: {summary.get('status_distribution', {})}")
        print()
        
        # Test 3: Multiple status filters
        print("3. Multiple status filters (submitted,review):")
        summary = DashboardService.get_dashboard_summary(filters={'status': 'submitted,review'})
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Status distribution: {summary.get('status_distribution', {})}")
        print()
        
        # Test 4: Single risk filter
        print("4. Single risk filter (High):")
        summary = DashboardService.get_dashboard_summary(filters={'risk_level': 'High'})
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Risk distribution: {summary.get('risk_distribution', {})}")
        print()
        
        # Test 5: Multiple risk filters
        print("5. Multiple risk filters (High,Medium):")
        summary = DashboardService.get_dashboard_summary(filters={'risk_level': 'High,Medium'})
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Risk distribution: {summary.get('risk_distribution', {})}")
        print()
        
        # Test 6: Combined status and risk filters
        print("6. Combined filters (status: submitted, risk: High):")
        summary = DashboardService.get_dashboard_summary(
            filters={'status': 'submitted', 'risk_level': 'High'}
        )
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Status distribution: {summary.get('status_distribution', {})}")
        print(f"   Risk distribution: {summary.get('risk_distribution', {})}")
        print()
        
        # Test 7: Combined multiple status and risk filters
        print("7. Combined multiple filters (status: submitted,review, risk: High,Medium):")
        summary = DashboardService.get_dashboard_summary(
            filters={'status': 'submitted,review', 'risk_level': 'High,Medium'}
        )
        print(f"   Total changes: {summary.get('summary', {}).get('total_changes', 0)}")
        print(f"   Status distribution: {summary.get('status_distribution', {})}")
        print(f"   Risk distribution: {summary.get('risk_distribution', {})}")
        print()
        
        # Test 8: Verify raw database counts for comparison
        print("8. Raw database verification:")
        
        # Total changes
        total = ChangeRequest.query.count()
        print(f"   Raw total changes: {total}")
        
        # Changes by status
        for status in ['draft', 'submitted', 'review', 'approved', 'rejected', 'implemented']:
            count = ChangeRequest.query.filter_by(status=status).count()
            print(f"   Raw {status}: {count}")
        
        # Changes by risk level
        for risk in ['High', 'Medium', 'Low']:
            count = ChangeRequest.query.join(RiskScore).filter(RiskScore.risk_level == risk).count()
            print(f"   Raw {risk} risk: {count}")
        
        print()
        
        # Test 9: Manual query for combined filters
        print("9. Manual query for combined filters:")
        from sqlalchemy import and_
        
        # Test submitted + High risk
        combined_count = ChangeRequest.query.join(RiskScore).filter(
            and_(
                ChangeRequest.status == 'submitted',
                RiskScore.risk_level == 'High'
            )
        ).count()
        print(f"   Manual query (submitted + High): {combined_count}")
        
        # Test submitted OR review + High OR Medium
        combined_count2 = ChangeRequest.query.join(RiskScore).filter(
            and_(
                ChangeRequest.status.in_(['submitted', 'review']),
                RiskScore.risk_level.in_(['High', 'Medium'])
            )
        ).count()
        print(f"   Manual query (submitted,review + High,Medium): {combined_count2}")

if __name__ == "__main__":
    test_filter_combinations()