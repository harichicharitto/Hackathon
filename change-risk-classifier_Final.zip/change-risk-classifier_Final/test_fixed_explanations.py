#!/usr/bin/env python3
"""
Test script to verify that AI explanations have been fixed.
"""

import requests
import json

def test_fixed_explanations():
    # Get token
    response = requests.post('http://localhost:5000/api/auth/login', 
                            json={'username': 'admin', 'password': 'admin123'})
    if not response.ok:
        print(f"Login failed: {response.status_code}")
        return
    
    token = response.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    
    print('=== Testing Fixed AI Explanations ===')
    
    # Test a change with previously incomplete explanation
    response = requests.get('http://localhost:5000/api/changes/11', headers=headers)
    if response.ok:
        change = response.json()
        risk_analysis = change.get('risk_analysis', {})
        reasoning = risk_analysis.get('reasoning', 'No reasoning found')
        
        print('Change 11 - Backup System Optimization:')
        print(f'Risk Level: {change.get("risk_level", "N/A")}')
        print(f'Risk Score: {change.get("risk_score", "N/A")}')
        print(f'AI Explanation: {reasoning}')
        print()
    
    # Get another change that was updated
    response = requests.get('http://localhost:5000/api/changes/12', headers=headers)
    if response.ok:
        change = response.json()
        risk_analysis = change.get('risk_analysis', {})
        reasoning = risk_analysis.get('reasoning', 'No reasoning found')
        
        print('Change 12 - Application Load Balancer Upgrade:')
        print(f'Risk Level: {change.get("risk_level", "N/A")}')
        print(f'Risk Score: {change.get("risk_score", "N/A")}')
        print(f'AI Explanation: {reasoning}')
        print()
    
    print('✅ AI explanations have been successfully updated and are now available via API!')

if __name__ == '__main__':
    test_fixed_explanations()