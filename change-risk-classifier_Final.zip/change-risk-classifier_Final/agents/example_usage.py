#!/usr/bin/env python3
"""
Example usage of the AI Code Quality Checker
This script demonstrates how to use the CodeQualityChecker class programmatically
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from code_quality_checker import CodeQualityChecker
import json

def example_python_analysis():
    """Example: Analyze Python code"""
    print("🔍 AI Code Quality Checker - Python Example")
    print("=" * 50)
    
    # Sample Python code with various issues
    python_code = '''
def calc_total(items):
    # This function calculates total
    total = 0
    for item in items:
        total += item
    return total

def process_data(data):
    result = []
    for i in range(len(data)):
        result.append(data[i] * 2)
    return result

# TODO: Add error handling
# TODO: Add docstrings

print("Processing data...")
'''
    
    # Quality checklist for Python
    checklist = [
        "Code follows PEP 8 style guidelines",
        "Functions have proper docstrings",
        "Variables use meaningful names",
        "Code has appropriate comments",
        "Error handling is implemented",
        "Code is modular and reusable",
        "No unused imports or variables",
        "Proper exception handling",
        "Code follows security best practices"
    ]
    
    # Initialize checker
    checker = CodeQualityChecker()
    
    # Run local analysis (no API key required)
    print("Running local analysis...")
    results = checker.analyze_code_locally(python_code, checklist, "Python")
    
    # Display results
    print(f"\n📊 Quality Score: {results['score']}/100")
    print(f"🔍 Issues Found: {len(results['observations'])}")
    print(f"💡 Suggestions: {len(results['suggestions'])}")
    
    if results['observations']:
        print("\n🔍 Observations:")
        for i, obs in enumerate(results['observations'], 1):
            print(f"  {i}. [{obs['severity']}] {obs['issue']}")
    
    if results['suggestions']:
        print("\n💡 Suggestions:")
        for i, sug in enumerate(results['suggestions'], 1):
            print(f"  {i}. [{sug['priority']}] {sug['suggestion']}")
    
    return results

def example_javascript_analysis():
    """Example: Analyze JavaScript code"""
    print("\n🔍 AI Code Quality Checker - JavaScript Example")
    print("=" * 50)
    
    # Sample JavaScript code with issues
    js_code = '''
function calculateTotal(items) {
    var total = 0;
    for (var i = 0; i < items.length; i++) {
        total += items[i];
    }
    return total;
}

function processData(data) {
    let result = [];
    for (let item of data) {
        result.push(item * 2);
    }
    return result;
}

// Global variable - bad practice
var globalVar = "I'm global";

console.log("Processing data...");
'''
    
    # Quality checklist for JavaScript
    checklist = [
        "Code follows ESLint rules",
        "Functions have JSDoc comments",
        "Variables use meaningful names",
        "Proper error handling with try-catch",
        "Code is modular with proper imports/exports",
        "No global variable pollution",
        "Event handlers are properly managed",
        "Async/await used appropriately",
        "Security best practices followed"
    ]
    
    # Initialize checker
    checker = CodeQualityChecker()
    
    # Run local analysis
    print("Running local analysis...")
    results = checker.analyze_code_locally(js_code, checklist, "JavaScript")
    
    # Display results
    print(f"\n📊 Quality Score: {results['score']}/100")
    print(f"🔍 Issues Found: {len(results['observations'])}")
    print(f"💡 Suggestions: {len(results['suggestions'])}")
    
    if results['observations']:
        print("\n🔍 Observations:")
        for i, obs in enumerate(results['observations'], 1):
            print(f"  {i}. [{obs['severity']}] {obs['issue']}")
    
    if results['suggestions']:
        print("\n💡 Suggestions:")
        for i, sug in enumerate(results['suggestions'], 1):
            print(f"  {i}. [{sug['priority']}] {sug['suggestion']}")
    
    return results

def example_with_custom_checklist():
    """Example: Use custom checklist"""
    print("\n🔍 AI Code Quality Checker - Custom Checklist Example")
    print("=" * 50)
    
    # Sample code
    code = '''
def add_numbers(a, b):
    return a + b

def multiply_numbers(x, y):
    # Simple multiplication
    return x * y
'''
    
    # Custom checklist for a specific project
    custom_checklist = [
        "Functions have proper type hints",
        "Includes comprehensive docstrings",
        "Uses meaningful variable names",
        "Follows project naming conventions",
        "Includes unit tests",
        "Handles edge cases appropriately"
    ]
    
    # Initialize checker
    checker = CodeQualityChecker()
    
    # Run analysis
    print("Running analysis with custom checklist...")
    results = checker.analyze_code_locally(code, custom_checklist, "Python")
    
    # Display results
    print(f"\n📊 Quality Score: {results['score']}/100")
    print(f"🔍 Issues Found: {len(results['observations'])}")
    print(f"💡 Suggestions: {len(results['suggestions'])}")
    
    if results['observations']:
        print("\n🔍 Observations:")
        for i, obs in enumerate(results['observations'], 1):
            print(f"  {i}. [{obs['severity']}] {obs['issue']}")
    
    if results['suggestions']:
        print("\n💡 Suggestions:")
        for i, sug in enumerate(results['suggestions'], 1):
            print(f"  {i}. [{sug['priority']}] {sug['suggestion']}")
    
    return results

def save_report(results, filename):
    """Save analysis results to a file"""
    with open(filename, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\n📄 Report saved to: {filename}")

def main():
    """Run all examples"""
    print("🚀 AI Code Quality Checker - Examples")
    print("=" * 60)
    
    # Example 1: Python analysis
    python_results = example_python_analysis()
    save_report(python_results, "python_analysis_report.json")
    
    # Example 2: JavaScript analysis
    js_results = example_javascript_analysis()
    save_report(js_results, "javascript_analysis_report.json")
    
    # Example 3: Custom checklist
    custom_results = example_with_custom_checklist()
    save_report(custom_results, "custom_checklist_report.json")
    
    print("\n✅ All examples completed!")
    print("\n💡 To run the interactive web interface:")
    print("   streamlit run code_quality_checker.py")
    
    print("\n🔧 To use programmatically:")
    print("   from code_quality_checker import CodeQualityChecker")
    print("   checker = CodeQualityChecker()")
    print("   results = checker.analyze_code_with_ai(code, checklist, language)")

if __name__ == "__main__":
    main()