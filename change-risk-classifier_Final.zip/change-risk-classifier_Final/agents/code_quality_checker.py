#!/usr/bin/env python3
"""
AI Code Quality Checker
An interactive web application for analyzing code quality using AI
Built with Streamlit and OpenAI API
"""

import streamlit as st
import openai
import re
import json
from datetime import datetime
from typing import Dict, List, Tuple, Any
import os

# Configure page
st.set_page_config(
    page_title="AI Code Quality Checker",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 2rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #424242;
        margin-bottom: 1rem;
    }
    .checklist-item {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 0.5rem;
        border-left: 4px solid #1E88E5;
    }
    .observation-item {
        background-color: #fff3e0;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 0.5rem;
        border-left: 4px solid #FF9800;
    }
    .suggestion-item {
        background-color: #e8f5e9;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 0.5rem;
        border-left: 4px solid #4CAF50;
    }
    .error-item {
        background-color: #ffebee;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 0.5rem;
        border-left: 4px solid #f44336;
    }
    .metric-card {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #dee2e6;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)

class CodeQualityChecker:
    def __init__(self):
        self.checklist_templates = {
            "Python": [
                "Code follows PEP 8 style guidelines",
                "Functions have proper docstrings",
                "Variables use meaningful names",
                "Code has appropriate comments",
                "Error handling is implemented",
                "Code is modular and reusable",
                "Imports are organized properly",
                "No unused imports or variables",
                "Proper exception handling",
                "Code follows security best practices"
            ],
            "JavaScript": [
                "Code follows ESLint rules",
                "Functions have JSDoc comments",
                "Variables use meaningful names",
                "Proper error handling with try-catch",
                "Code is modular with proper imports/exports",
                "No global variable pollution",
                "Event handlers are properly managed",
                "Async/await used appropriately",
                "Security best practices followed",
                "Performance optimizations considered"
            ],
            "Java": [
                "Code follows Java naming conventions",
                "Classes and methods have proper documentation",
                "Proper exception handling",
                "Code follows SOLID principles",
                "Proper use of access modifiers",
                "Resource management (try-with-resources)",
                "Collections used appropriately",
                "Threading considerations",
                "Security best practices",
                "Performance considerations"
            ],
            "C#": [
                "Code follows C# naming conventions",
                "Proper use of access modifiers",
                "Exception handling implemented",
                "IDisposable pattern used where needed",
                "LINQ used appropriately",
                "Async/await patterns followed",
                "Proper use of collections",
                "Memory management considerations",
                "Security best practices",
                "Performance optimizations"
            ],
            "Custom": []
        }
        
        self.quality_categories = {
            "Style & Formatting": ["PEP 8", "Naming conventions", "Code organization"],
            "Documentation": ["Docstrings", "Comments", "API documentation"],
            "Functionality": ["Logic correctness", "Edge cases", "Error handling"],
            "Performance": ["Algorithm efficiency", "Memory usage", "Optimization"],
            "Security": ["Input validation", "Authentication", "Data protection"],
            "Maintainability": ["Code complexity", "Modularity", "Dependencies"]
        }

    def get_api_key(self) -> str:
        """Get OpenAI API key from environment or user input"""
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            api_key = st.sidebar.text_input(
                "OpenAI API Key", 
                type="password",
                help="Enter your OpenAI API key to enable AI analysis"
            )
        return api_key

    def analyze_code_with_ai(self, code: str, checklist: List[str], language: str) -> Dict[str, Any]:
        """Analyze code using OpenAI API"""
        if not self.get_api_key():
            return {"error": "OpenAI API key required for AI analysis"}
        
        try:
            openai.api_key = self.get_api_key()
            
            checklist_text = "\n".join([f"- {item}" for item in checklist])
            
            prompt = f"""
            Analyze the following {language} code against the provided quality checklist:

            CODE TO ANALYZE:
            ```{language.lower()}
            {code}
            ```

            QUALITY CHECKLIST:
            {checklist_text}

            Please provide a detailed analysis with:
            1. Observations: Specific issues found in the code
            2. Suggestions: Concrete improvements that can be made
            3. Severity levels: Critical, High, Medium, Low for each issue
            4. Code quality score: 1-100 based on the analysis
            5. Categorization: Which quality categories the issues belong to

            Format your response as JSON with the following structure:
            {{
                "observations": [
                    {{"issue": "description", "severity": "Critical|High|Medium|Low", "category": "category_name"}}
                ],
                "suggestions": [
                    {{"suggestion": "description", "priority": "High|Medium|Low", "implementation": "code_example"}}
                ],
                "score": number,
                "categories_affected": ["list", "of", "categories"],
                "summary": "brief_summary"
            }}
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are an expert code reviewer and quality analyst."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1500
            )
            
            content = response.choices[0].message.content
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', content, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            else:
                return {"error": "Could not parse AI response", "raw_response": content}
                
        except Exception as e:
            return {"error": f"AI analysis failed: {str(e)}"}

    def analyze_code_locally(self, code: str, checklist: List[str], language: str) -> Dict[str, Any]:
        """Basic local analysis without AI"""
        observations = []
        suggestions = []
        
        # Basic checks
        lines = code.split('\n')
        
        # Check for long lines
        long_lines = [i+1 for i, line in enumerate(lines) if len(line) > 80]
        if long_lines:
            observations.append({
                "issue": f"Found {len(long_lines)} lines longer than 80 characters",
                "severity": "Medium",
                "category": "Style & Formatting"
            })
            suggestions.append({
                "suggestion": "Break long lines into multiple lines for better readability",
                "priority": "Medium",
                "implementation": "# Example: Break long lines\nlong_variable_name = (\n    \"very long string that should be broken\"\n)"
            })
        
        # Check for TODO comments
        todo_count = sum(1 for line in lines if 'TODO' in line.upper())
        if todo_count > 0:
            observations.append({
                "issue": f"Found {todo_count} TODO comments that need attention",
                "severity": "Low",
                "category": "Maintainability"
            })
        
        # Check for print statements (in production code)
        print_count = sum(1 for line in lines if 'print(' in line and not line.strip().startswith('#'))
        if print_count > 0 and language == "Python":
            observations.append({
                "issue": f"Found {print_count} print statements (consider using logging)",
                "severity": "Medium",
                "category": "Functionality"
            })
            suggestions.append({
                "suggestion": "Replace print statements with proper logging",
                "priority": "Medium",
                "implementation": "import logging\nlogging.info('Message instead of print')"
            })
        
        # Check for empty functions
        if language == "Python":
            empty_funcs = []
            for i, line in enumerate(lines):
                if 'def ' in line and ':' in line:
                    # Check if next few lines are empty or pass
                    func_lines = lines[i+1:i+4]
                    if any('pass' in func_line or not func_line.strip() for func_line in func_lines):
                        empty_funcs.append(line.strip())
            
            if empty_funcs:
                observations.append({
                    "issue": f"Found {len(empty_funcs)} empty or stub functions",
                    "severity": "High",
                    "category": "Functionality"
                })
        
        score = max(1, 100 - (len(observations) * 10))
        
        return {
            "observations": observations,
            "suggestions": suggestions,
            "score": score,
            "categories_affected": list(set(obs["category"] for obs in observations)),
            "summary": f"Basic analysis completed. Found {len(observations)} potential issues."
        }

    def display_results(self, results: Dict[str, Any]):
        """Display analysis results in a structured format"""
        if "error" in results:
            st.error(f"Analysis Error: {results['error']}")
            return
        
        # Header with score
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            score = results.get("score", 0)
            if score >= 80:
                color = "green"
            elif score >= 60:
                color = "orange"
            else:
                color = "red"
            
            st.markdown(f"""
            <div class="metric-card">
                <h3 style="color: {color}; margin: 0;">Quality Score</h3>
                <h1 style="color: {color}; margin: 0;">{score}/100</h1>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class="metric-card">
                <h3 style="margin: 0;">Issues Found</h3>
                <h1 style="margin: 0;">{len(results.get('observations', []))}</h1>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div class="metric-card">
                <h3 style="margin: 0;">Suggestions</h3>
                <h1 style="margin: 0;">{len(results.get('suggestions', []))}</h1>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            categories = results.get('categories_affected', [])
            st.markdown(f"""
            <div class="metric-card">
                <h3 style="margin: 0;">Categories</h3>
                <h1 style="margin: 0;">{len(categories)}</h1>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Summary
        if results.get("summary"):
            st.markdown(f"**Analysis Summary:** {results['summary']}")
        
        # Categories affected
        categories = results.get('categories_affected', [])
        if categories:
            st.markdown("**Quality Categories Affected:**")
            cols = st.columns(len(categories))
            for i, category in enumerate(categories):
                with cols[i % len(cols)]:
                    st.markdown(f"- {category}")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Observations
        observations = results.get("observations", [])
        if observations:
            st.markdown("### 🔍 Observations")
            for obs in observations:
                severity_color = {
                    "Critical": "#dc3545",
                    "High": "#fd7e14", 
                    "Medium": "#ffc107",
                    "Low": "#20c997"
                }.get(obs.get("severity", "Low"), "#6c757d")
                
                st.markdown(f"""
                <div class="observation-item">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <strong>{obs.get('issue', 'Issue description')}</strong>
                        <span style="background-color: {severity_color}; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.8rem;">
                            {obs.get('severity', 'Unknown')}
                        </span>
                    </div>
                    <div style="margin-top: 0.5rem; color: #666;">
                        Category: {obs.get('category', 'General')}
                    </div>
                </div>
                """, unsafe_allow_html=True)
        
        # Suggestions
        suggestions = results.get("suggestions", [])
        if suggestions:
            st.markdown("### 💡 Suggestions")
            for sug in suggestions:
                st.markdown(f"""
                <div class="suggestion-item">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <strong>{sug.get('suggestion', 'Suggestion')}</strong>
                        <span style="background-color: #4CAF50; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.8rem;">
                            {sug.get('priority', 'Medium')}
                        </span>
                    </div>
                    {f"<div style='margin-top: 0.5rem;'><strong>Implementation:</strong><pre>{sug.get('implementation', '')}</pre></div>" if sug.get('implementation') else ""}
                </div>
                """, unsafe_allow_html=True)

def main():
    st.markdown('<h1 class="main-header">🔍 AI Code Quality Checker</h1>', unsafe_allow_html=True)
    st.markdown('<p style="text-align: center; color: #666; font-size: 1.1rem;">Upload your code and checklist for comprehensive quality analysis</p>', unsafe_allow_html=True)
    
    checker = CodeQualityChecker()
    
    # Sidebar configuration
    st.sidebar.markdown("## ⚙️ Configuration")
    
    # Language selection
    language = st.sidebar.selectbox(
        "Programming Language",
        options=list(checker.checklist_templates.keys()),
        help="Select the programming language for analysis"
    )
    
    # Checklist configuration
    st.sidebar.markdown("### 📋 Quality Checklist")
    
    if language == "Custom":
        custom_checklist = st.sidebar.text_area(
            "Custom Checklist Items (one per line)",
            height=200,
            help="Enter your custom checklist items, one per line"
        )
        checklist = [item.strip() for item in custom_checklist.split('\n') if item.strip()]
    else:
        checklist = checker.checklist_templates[language]
        
        # Allow users to customize the template
        st.sidebar.markdown("Select items to include in analysis:")
        selected_items = []
        for item in checklist:
            if st.sidebar.checkbox(item, value=True):
                selected_items.append(item)
        checklist = selected_items
    
    # Analysis options
    st.sidebar.markdown("### 🔧 Analysis Options")
    use_ai = st.sidebar.checkbox("Use AI Analysis (requires API key)", value=True)
    detailed_analysis = st.sidebar.checkbox("Detailed Analysis", value=True)
    
    # Main content area
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown('<h2 class="sub-header">📝 Input Code</h2>', unsafe_allow_html=True)
        
        # Code input options
        input_method = st.radio(
            "Input Method",
            ["Text Editor", "File Upload"],
            horizontal=True
        )
        
        code = ""
        if input_method == "Text Editor":
            code = st.text_area(
                "Paste your code here",
                height=400,
                placeholder="Enter your code here...",
                help="Supported languages: Python, JavaScript, Java, C#"
            )
        else:
            uploaded_file = st.file_uploader(
                "Upload code file",
                type=['py', 'js', 'java', 'cs', 'php', 'rb', 'go', 'rust'],
                help="Upload a single code file for analysis"
            )
            if uploaded_file:
                code = uploaded_file.read().decode('utf-8')
                st.success(f"Loaded: {uploaded_file.name}")
    
    with col2:
        st.markdown('<h2 class="sub-header">📋 Quality Checklist</h2>', unsafe_allow_html=True)
        
        if checklist:
            for i, item in enumerate(checklist, 1):
                st.markdown(f'<div class="checklist-item"><strong>{i}.</strong> {item}</div>', unsafe_allow_html=True)
        else:
            st.warning("No checklist items selected. Please select or add checklist items.")
    
    # Analysis section
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown('<h2 class="sub-header">🚀 Run Analysis</h2>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 1, 2])
    
    with col1:
        analyze_btn = st.button("🔍 Analyze Code", type="primary", use_container_width=True)
    
    with col2:
        if st.button("🧹 Clear Results", use_container_width=True):
            st.rerun()
    
    with col3:
        if checklist and code.strip():
            st.info(f"Ready to analyze {len(checklist)} checklist items against your code")
        else:
            st.warning("Please provide both code and checklist items for analysis")
    
    # Run analysis
    if analyze_btn:
        if not code.strip():
            st.error("Please provide code to analyze")
        elif not checklist:
            st.error("Please select or add checklist items")
        else:
            with st.spinner("Analyzing code quality..."):
                if use_ai and checker.get_api_key():
                    results = checker.analyze_code_with_ai(code, checklist, language)
                else:
                    if not checker.get_api_key():
                        st.warning("OpenAI API key not provided. Using basic local analysis.")
                    results = checker.analyze_code_locally(code, checklist, language)
                
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown('<h2 class="sub-header">📊 Analysis Results</h2>', unsafe_allow_html=True)
                checker.display_results(results)
                
                # Export options
                if "error" not in results:
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        # Export as JSON
                        json_data = json.dumps(results, indent=2)
                        st.download_button(
                            label="📥 Download JSON Report",
                            data=json_data,
                            file_name=f"code_quality_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                            mime="application/json"
                        )
                    
                    with col2:
                        # Export as Markdown
                        markdown_report = f"""
# Code Quality Analysis Report

**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Language:** {language}
**Checklist Items:** {len(checklist)}

## Summary
{results.get('summary', 'No summary available')}

## Quality Score
**{results.get('score', 0)}/100**

## Observations
"""
                        for obs in results.get('observations', []):
                            markdown_report += f"- **{obs.get('severity', 'Unknown')}**: {obs.get('issue', 'No issue description')}\n"
                        
                        markdown_report += "\n## Suggestions\n"
                        for sug in results.get('suggestions', []):
                            markdown_report += f"- **{sug.get('priority', 'Medium')}**: {sug.get('suggestion', 'No suggestion')}\n"
                        
                        st.download_button(
                            label="📄 Download Markdown Report",
                            data=markdown_report,
                            file_name=f"code_quality_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
                            mime="text/markdown"
                        )
                    
                    with col3:
                        # Generate improvement summary
                        improvements = len(results.get('suggestions', []))
                        if improvements > 0:
                            st.success(f"Found {improvements} potential improvements!")
                        else:
                            st.info("No major issues found. Code quality looks good!")

if __name__ == "__main__":
    main()