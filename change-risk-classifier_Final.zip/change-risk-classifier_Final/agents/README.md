# AI Code Quality Checker

An interactive web application for analyzing code quality using AI, built with Streamlit and OpenAI API.

## Overview

The AI Code Quality Checker is a comprehensive tool that analyzes source code against customizable quality checklists and provides detailed observations and suggestions for improvement. It combines AI-powered analysis with local code analysis to deliver actionable insights for developers.

## Features

### 🤖 AI-Powered Analysis
- **OpenAI Integration**: Uses GPT-3.5 Turbo for intelligent code analysis
- **Multi-Language Support**: Pre-configured checklists for Python, JavaScript, Java, and C#
- **Custom Checklists**: Create custom quality checklists for any language or framework
- **Detailed Reports**: Comprehensive analysis with severity levels and categorization

### 📊 Quality Assessment
- **Quality Score**: 1-100 scoring system based on analysis results
- **Issue Categorization**: Organizes issues into logical categories (Style, Documentation, Functionality, etc.)
- **Severity Levels**: Critical, High, Medium, Low severity classification
- **Actionable Suggestions**: Concrete improvement recommendations with code examples

### 🎨 User Experience
- **Interactive Interface**: Modern Streamlit-based web interface
- **Real-time Analysis**: Instant feedback on code quality
- **Multiple Input Methods**: Text editor and file upload support
- **Export Options**: JSON and Markdown report generation

### 🔧 Analysis Capabilities
- **Style & Formatting**: Code style and formatting analysis
- **Documentation**: Docstring and comment quality assessment
- **Functionality**: Logic correctness and error handling review
- **Performance**: Algorithm efficiency and optimization suggestions
- **Security**: Security best practices and vulnerability detection
- **Maintainability**: Code complexity and modularity analysis

## Installation

### Prerequisites
- Python 3.8 or higher
- OpenAI API key (optional for basic analysis)

### Setup Instructions

1. **Clone or download the agent files**
   ```bash
   # Copy the agents directory to your project
   cp -r agents/ /path/to/your/project/
   ```

2. **Install dependencies**
   ```bash
   cd agents
   pip install -r requirements.txt
   ```

3. **Set up OpenAI API key**
   ```bash
   # Option 1: Environment variable
   export OPENAI_API_KEY="your-api-key-here"
   
   # Option 2: Create .env file
   echo "OPENAI_API_KEY=your-api-key-here" > .env
   ```

4. **Run the application**
   ```bash
   streamlit run code_quality_checker.py
   ```

## Usage

### Quick Start

1. **Launch the application**
   ```bash
   streamlit run agents/code_quality_checker.py
   ```

2. **Configure analysis**
   - Select programming language from sidebar
   - Choose or customize quality checklist items
   - Enable/disable AI analysis

3. **Input code**
   - Paste code in text editor, or
   - Upload code file (supports .py, .js, .java, .cs, .php, .rb, .go, .rust)

4. **Run analysis**
   - Click "Analyze Code" button
   - View results with quality score and detailed observations
   - Download reports in JSON or Markdown format

### Supported Languages

The application includes pre-configured checklists for:

- **Python**: PEP 8, docstrings, naming conventions, security
- **JavaScript**: ESLint rules, JSDoc, async/await patterns
- **Java**: Naming conventions, SOLID principles, exception handling
- **C#**: .NET best practices, async patterns, memory management

### Custom Checklists

Create custom checklists for any language or framework:

1. Select "Custom" from language dropdown
2. Enter checklist items (one per line) in sidebar
3. Examples:
   ```
   Follows framework conventions
   Includes proper error handling
   Uses dependency injection
   Implements proper logging
   ```

## Analysis Process

### AI Analysis (with OpenAI API)
1. **Code Analysis**: GPT-3.5 Turbo analyzes code against checklist
2. **Issue Detection**: Identifies specific problems and violations
3. **Suggestion Generation**: Provides concrete improvement recommendations
4. **Scoring**: Calculates quality score based on analysis results
5. **Categorization**: Organizes issues into quality categories

### Local Analysis (without API)
1. **Basic Checks**: Line length, TODO comments, print statements
2. **Pattern Matching**: Empty functions, unused variables
3. **Simple Scoring**: Basic quality score calculation
4. **Limited Suggestions**: Pre-defined improvement suggestions

## Output Formats

### Quality Score
- **Range**: 1-100 (higher is better)
- **Color-coded**: Green (80+), Orange (60-79), Red (<60)
- **Factors**: Number and severity of issues found

### Observations
Each observation includes:
- **Issue Description**: Specific problem identified
- **Severity Level**: Critical, High, Medium, Low
- **Quality Category**: Style, Documentation, Functionality, etc.

### Suggestions
Each suggestion includes:
- **Description**: What to improve
- **Priority**: High, Medium, Low
- **Implementation**: Code example (when available)

### Reports
- **JSON Format**: Structured data for programmatic use
- **Markdown Format**: Human-readable report with formatting

## Configuration

### Environment Variables
```bash
OPENAI_API_KEY=your-api-key-here
```

### Customization Options
- **Language Templates**: Modify `checklist_templates` in code
- **Quality Categories**: Update `quality_categories` mapping
- **Analysis Rules**: Customize `analyze_code_locally` method
- **UI Styling**: Modify CSS in `main()` function

## Examples

### Python Code Analysis
```python
def calculate_total(items):
    total = 0
    for item in items:
        total += item
    return total

# Issues found:
# - Missing docstring
# - Function name could be more descriptive
# - No error handling for empty list
```

### JavaScript Code Analysis
```javascript
function processData(data) {
    let result = [];
    for (let i = 0; i < data.length; i++) {
        result.push(data[i] * 2);
    }
    return result;
}

// Issues found:
// - Use const/let consistently
// - Consider using map() for array transformation
// - Missing JSDoc comments
```

## Troubleshooting

### Common Issues

**"OpenAI API key required"**
- Set environment variable: `export OPENAI_API_KEY=your-key`
- Or add to .env file in project directory
- Or enter in Streamlit sidebar

**"Analysis Error"**
- Check internet connection for AI analysis
- Verify OpenAI API key is valid
- Try basic local analysis without API

**"File upload not working"**
- Ensure file extension is supported
- Check file size (large files may timeout)
- Try pasting code in text editor instead

### Performance Tips

- **Large Files**: For files >1000 lines, consider analyzing in chunks
- **API Limits**: Monitor OpenAI usage to avoid rate limits
- **Local Analysis**: Use local analysis for quick checks without API calls

## Development

### Extending Functionality

1. **Add New Languages**
   ```python
   self.checklist_templates["NewLanguage"] = [
       "Language-specific checklist item 1",
       "Language-specific checklist item 2",
       # ...
   ]
   ```

2. **Custom Analysis Rules**
   ```python
   def custom_analysis(self, code, language):
       # Add custom analysis logic
       return observations, suggestions
   ```

3. **New Output Formats**
   ```python
   def export_to_excel(self, results):
       # Export to Excel format
       pass
   ```

### Contributing

1. Fork the repository
2. Create feature branch
3. Add tests for new functionality
4. Submit pull request

## Security Considerations

- **API Key Security**: Never commit API keys to version control
- **Code Privacy**: Be cautious with proprietary code in AI analysis
- **Data Handling**: Application doesn't store uploaded code permanently
- **Network Security**: Use HTTPS when deploying publicly

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues, questions, or contributions:

- **GitHub Issues**: Report bugs or request features
- **Documentation**: Check this README for usage instructions
- **Code Comments**: Review inline documentation for implementation details

## Changelog

### v1.0.0
- Initial release with core functionality
- Support for Python, JavaScript, Java, C#
- AI analysis with OpenAI API
- Local analysis fallback
- Streamlit web interface
- Export functionality

---

**Note**: This tool is designed to assist with code quality improvement and should be used as a guide rather than an absolute authority on code quality.