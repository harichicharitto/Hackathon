import sqlite3

# Connect to the database
conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
cursor = conn.cursor()

# Get table names
cursor.execute('SELECT name FROM sqlite_master WHERE type="table"')
tables = cursor.fetchall()

print('=== Database Tables ===')
for table in tables:
    print(f'Table: {table[0]}')

# Check change_requests table structure
cursor.execute('PRAGMA table_info(change_requests)')
columns = cursor.fetchall()

print('\n=== Change Requests Table Structure ===')
for col in columns:
    print(f'Column: {col[1]}, Type: {col[2]}, Not Null: {col[3]}, Default: {col[4]}')

# Get a sample change
cursor.execute('SELECT * FROM change_requests LIMIT 1')
sample_change = cursor.fetchone()

if sample_change:
    print('\n=== Sample Change Data ===')
    cursor.execute('PRAGMA table_info(change_requests)')
    columns = [col[1] for col in cursor.fetchall()]
    for i, value in enumerate(sample_change):
        print(f'{columns[i]}: {value}')

conn.close()