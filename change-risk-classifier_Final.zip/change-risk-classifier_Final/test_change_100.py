#!/usr/bin/env python3
"""
Test script to check Change 100 API response.
"""

import requests

def test_change_100():
    try:
        # Login to get token
        login_response = requests.post('http://localhost:5000/api/auth/login', 
            json={'username': 'admin', 'password': 'admin123'})
        
        if not login_response.ok:
            print(f"Login failed: {login_response.status_code}")
            return
        
        token = login_response.json()['access_token']
        headers = {'Authorization': f'Bearer {token}'}
        
        # Get Change 100
        change_response = requests.get('http://localhost:5000/api/changes/100', headers=headers)
        
        if not change_response.ok:
            print(f"Failed to get change: {change_response.status_code}")
            return
        
        change_data = change_response.json()
        
        print('=== Change 100 API Response ===')
        print(f'Change ID: {change_data.get("id")}')
        print(f'Title: {change_data.get("title")}')
        print(f'Risk Level: {change_data.get("risk_level")}')
        print(f'Has Risk Scores: {"✅" if change_data.get("risk_scores") else "❌"}')
        
        if change_data.get('risk_scores'):
            risk_score = change_data['risk_scores'][0]
            print(f'\n=== Risk Score Data ===')
            print(f'Risk Reasoning: {bool(risk_score.get("risk_reasoning"))}')
            print(f'Risk Factors: {bool(risk_score.get("risk_factors"))}')
            print(f'Recommendation: {bool(risk_score.get("recommendation"))}')
            
            if risk_score.get('recommendation'):
                print(f'\n=== Recommendation Content ===')
                print(repr(risk_score['recommendation']))
            
            if risk_score.get('risk_reasoning'):
                print(f'\n=== Risk Reasoning Content ===')
                print(repr(risk_score['risk_reasoning']))
        else:
            print('\n❌ No risk_scores field in API response')
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    test_change_100()