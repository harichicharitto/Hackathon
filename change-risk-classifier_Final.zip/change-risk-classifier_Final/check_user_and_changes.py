#!/usr/bin/env python3
import requests
import json

def check_user_and_changes():
    # Get token
    response = requests.post('http://localhost:5000/api/auth/login', 
                            json={'username': 'admin', 'password': 'admin123'})
    if response.ok:
        token = response.json()['access_token']
        
        # Get user info to check role
        headers = {'Authorization': f'Bearer {token}'}
        response = requests.post('http://localhost:5000/api/auth/validate-token', 
                               headers=headers, 
                               json={'token': token})
        if response.ok:
            user = response.json()['user']
            print('=== Current User Info ===')
            print(f'Username: {user["username"]}')
            print(f'Role: {user["role"]}')
            print(f'Is Admin: {user.get("is_admin", False)}')
            print(f'Is Change Manager: {user.get("is_change_manager", False)}')
            print()
        
        # Get a few changes to see their status
        response = requests.get('http://localhost:5000/api/changes/?page=1&per_page=10', headers=headers)
        if response.ok:
            changes = response.json()
            print('=== First 10 Changes ===')
            for change in changes.get('changes', []):
                print(f'Change {change["id"]}: {change["title"]}')
                print(f'  Status: {change["status"]}')
                print(f'  Risk Level: {change.get("risk_level", "Unknown")}')
                print()

if __name__ == '__main__':
    check_user_and_changes()