#!/usr/bin/env python3
"""
Simple test to understand the dashboard filter issue.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up the path to find config
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'backend'))

from backend.app import create_app
from backend.models import db, ChangeRequest, RiskScore

def simple_test():
    """Simple test to understand the issue."""
    
    app = create_app()
    
    with app.app_context():
        print("=== Simple Dashboard Filter Test ===\n")
        
        # Test 1: No filters
        print("1. No filters:")
        count = ChangeRequest.query.count()
        print(f"   Total changes: {count}")
        print()
        
        # Test 2: Status filter only
        print("2. Status filter only (pending):")
        count = ChangeRequest.query.filter(ChangeRequest.status == 'pending').count()
        print(f"   Pending changes: {count}")
        print()
        
        # Test 3: Risk filter only
        print("3. Risk filter only (High):")
        count = ChangeRequest.query.join(RiskScore).filter(RiskScore.risk_level == 'High').count()
        print(f"   High risk changes: {count}")
        print()
        
        # Test 4: Combined filters with proper join
        print("4. Combined filters (status: pending, risk: High) with proper join:")
        count = ChangeRequest.query.join(RiskScore).filter(
            ChangeRequest.status == 'pending',
            RiskScore.risk_level == 'High'
        ).count()
        print(f"   Pending high risk changes: {count}")
        print()
        
        # Test 5: Combined filters without proper join (this should cause cartesian product)
        print("5. Combined filters (status: pending, risk: High) without proper join:")
        try:
            count = ChangeRequest.query.filter(
                ChangeRequest.status == 'pending',
                RiskScore.risk_level == 'High'
            ).count()
            print(f"   This should fail or give wrong count: {count}")
        except Exception as e:
            print(f"   Error (expected): {e}")
        print()

if __name__ == "__main__":
    simple_test()