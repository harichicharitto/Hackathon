# Change Request Risk Classification & Approval Assistant

An AI-powered IT change management system that classifies change requests into **Low**, **Medium**, and **High** risk categories, provides an approval workflow, and gives per-change AI reasoning and mitigation recommendations.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Technology Stack](#technology-stack)
4. [Quick Start](#quick-start)
5. [Default Credentials](#default-credentials)
6. [User Roles & Permissions](#user-roles--permissions)
7. [Key Features](#key-features)
8. [Risk Classification Rules](#risk-classification-rules)
9. [API Overview](#api-overview)
10. [Project Structure](#project-structure)
11. [Security](#security)

---

## Project Overview

The Change Risk Classifier helps ITIS teams manage change requests by:

- Automatically scoring and classifying each change as **Low**, **Medium**, or **High** risk using configured rules and an AI model.
- Surfacing the **analysis basis**, **recommendation**, **contributing factors**, and **mitigation suggestions** for every assessed change.
- Providing a configurable **Rules** engine that feeds directly into the AI assessment context.
- Supporting a full **approval and rejection workflow** with audit logging.
- Enabling **CSV**, **Excel**, and **PDF** exports from the Changes view.
- Allowing admins to **onboard new users** with role-based access control.

---

## Architecture

```
Browser (HTML/CSS/JS)
        │
        ▼
Flask Application Server (backend/app.py)
        │
        ├── /api/auth/          Authentication & JWT
        ├── /api/changes/       Change request CRUD & workflow
        ├── /api/dashboard/     Summary, filtered list, analytics
        ├── /api/rules/         Risk classification rule management
        ├── /api/users/         User management (admin only)
        └── /api/export/        CSV / Excel / PDF exports
        │
        ▼
SQLite Database (SQLAlchemy ORM)
  Tables: users, change_requests, risk_scores, rules, audit_logs
        │
        ▼
AI Risk Service (LangChain + OpenAI/ChatOpenAI)
  Prompt includes: change details, configured rule logic, scoring rules
```

The frontend is vanilla HTML/CSS/JavaScript served directly by Flask — no build step required.

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.10+, Flask, Flask-JWT-Extended, Flask-CORS, Flask-SQLAlchemy, Flask-Migrate |
| Database | SQLite (default dev), PostgreSQL-compatible via psycopg2 |
| AI / LLM | LangChain, langchain-openai, ChatOpenAI |
| Frontend | Vanilla HTML5 / CSS3 / JavaScript (ES6+), Chart.js |
| Export | pandas, xlsxwriter, reportlab |
| Auth | JWT (RS256), werkzeug password hashing |
| Testing | pytest, pytest-flask |

---

## Quick Start

### 1. Clone and install

```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate
# Linux / macOS
source venv/bin/activate

pip install -r requirements.txt
```

### 2. Run the server

```bash
cd backend
python app.py
```

The server starts on **http://localhost:5000** and serves the frontend automatically.

On first run the app will:
- Create all database tables.
- Seed a default **admin** account.
- Load sample change requests from `backend/sample_data.csv`.
- Run AI risk scoring on each seeded change.
- Backfill `CHG-XXXX` prefixed IDs for all change requests.

### 3. Open the app

Navigate to **http://localhost:5000** in your browser.

> No separate frontend build or npm install is required.

---

## Default Credentials

| Username | Password | Role |
|----------|----------|------|
| `admin` | `admin123` | Admin |

Additional users (Change Manager, Viewer) can be created from the **Users** tab while logged in as admin.

---

## User Roles & Permissions

| Permission | Admin | Change Manager | Viewer |
|-----------|-------|---------------|--------|
| View Dashboard | ✅ | ✅ | ✅ |
| View all Changes | ✅ | ✅ | ✅ (own only) |
| Approve / Reject changes | ✅ | ✅ | ❌ |
| Export changes | ✅ | ✅ | ❌ |
| Manage Rules | ✅ | ❌ | ❌ |
| Manage Users | ✅ | ❌ | ❌ |
| Onboard new users | ✅ | ❌ | ❌ |

---

## Key Features

### Dashboard
- Summary stat cards: total changes, high / medium / low risk counts.
- Risk distribution doughnut chart (Chart.js).
- Recent changes feed.

### Changes Tab
- Paginated, filterable (status, risk level, free text search) changes table.
- Per-change **CHG-XXXX** business identifier.
- **Approve** and **Reject** action buttons shown only when change is in a reviewable state (`pending`, `submitted`, `review`) and current user has permissions.
- Rejection prompts for a reason, which is recorded in the audit log.
- Inline AI risk analysis: reasoning, recommendation, contributing factors, and mitigation suggestions.
- Export to **CSV / Excel / PDF** directly from the filter bar.

### Risk Analysis (per change)
Each change detail shows:
- **Risk Level** — Low / Medium / High
- **Reasoning** — model explanation for the classification
- **Recommendation** — e.g. `APPROVED WITH OVERNIGHT MONITORING`
- **Contributing Factors** — derived from currently active configured rules
- **Mitigation Suggestions** — actionable steps from the AI

### Rules Tab (Admin only)
Card-based configurable risk rules:
- Each card defines: title, risk level (HIGH / MEDIUM / LOW), condition, base score, weight, thresholds, and mandatory fields.
- Cards can be activated / deactivated without deletion.
- Active rules are passed to the AI model as context on every assessment.

### Users Tab (Admin only)
- Lists all users with role and active status.
- **Add User** form to onboard new users (Change Manager, Viewer, or Admin roles).

### Export
- **CSV** — full change list with risk data.
- **Excel** — formatted workbook.
- **PDF** — tabular report via reportlab.
- Format selector and export button sit inline in the Changes filter bar.

---

## Risk Classification Rules

### Default Logic

| Level | Conditions |
|-------|-----------|
| **High** | Critical CI + business hours window + multiple impacted systems + no rollback plan |
| **Medium** | Non-critical CI + limited blast radius + rollback plan present |
| **Low** | Standard change type + maintenance window + single system |

Rules are configurable at runtime from the **Rules** tab. Changes feed through both the rule engine and the AI model, which uses the active rule configuration as context.

---

## API Overview

All endpoints except `/api/auth/login` and `/api/auth/validate-token` require a `Bearer` JWT token in the `Authorization` header.

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/auth/login` | Authenticate user, receive JWT |
| `POST` | `/api/auth/validate-token` | Validate existing token |
| `GET` | `/api/dashboard/summary` | Dashboard summary stats |
| `GET` | `/api/changes/` | List changes (paginated, filtered) |
| `GET` | `/api/changes/<id>` | Change detail |
| `POST` | `/api/changes/<id>/approve` | Approve a change |
| `POST` | `/api/changes/<id>/reject` | Reject a change (body: `{ reason }`) |
| `GET` | `/api/rules/risk-config` | List risk rule cards |
| `POST` | `/api/rules/risk-config` | Create rule card |
| `PUT` | `/api/rules/risk-config/<id>` | Update rule card |
| `PUT` | `/api/rules/risk-config/<id>/status` | Activate / deactivate rule card |
| `GET` | `/api/users/` | List users (admin only) |
| `POST` | `/api/users/` | Create user (admin only) |
| `DELETE` | `/api/users/<id>` | Delete user (admin only) |
| `GET` | `/api/export/changes/csv` | Export changes as CSV |
| `GET` | `/api/export/changes/excel` | Export changes as Excel |
| `GET` | `/api/export/changes/pdf` | Export changes as PDF |

---

## Project Structure

```
change-risk-classifier/
├── requirements.txt
├── README.md
├── backend/
│   ├── app.py                   # App factory, seeding, startup
│   ├── config.py                # Settings (JWT, DB URL, etc.)
│   ├── sample_data.csv          # Seed data for demo changes
│   ├── api/
│   │   ├── auth.py              # Login, validate-token
│   │   ├── change_requests.py   # Change CRUD and workflow
│   │   ├── dashboard.py         # Summary and filtered list
│   │   ├── export.py            # CSV / Excel / PDF exports
│   │   ├── rules.py             # Rule card management
│   │   └── users.py             # User management
│   ├── models/
│   │   ├── base.py              # BaseModel with save() / delete()
│   │   ├── change_request.py    # ChangeRequest, ChangeStatus
│   │   ├── user.py              # User, UserRole
│   │   ├── risk_score.py        # RiskScore
│   │   ├── rule.py              # Rule
│   │   └── audit_log.py        # AuditLog
│   └── services/
│       ├── auth_service.py      # JWT creation, user lookup
│       ├── ai_risk_service.py   # LLM-based risk analysis
│       ├── dashboard_service.py # Formatted payloads, risk_analysis
│       ├── export_service.py    # CSV / Excel / PDF generation
│       ├── risk_classifier_service.py  # Rule-based scoring
│       └── rule_engine_service.py      # Rule card CRUD + AI context
├── frontend/
│   ├── index.html               # Single-page app shell
│   ├── app.js                   # All client-side logic
│   └── styles.css               # Styles
├── agents/                      # AI agents and tooling
├── docs/                        # Documentation and deliverables
└── tests/                       # Test files
```

---

## Security

- Passwords hashed with `werkzeug.security` (PBKDF2-SHA256).
- JWT tokens signed with a secret key; identity stored and retrieved as string.
- All mutating endpoints protected by `@jwt_required()`.
- Admin-only endpoints enforce role check on every request.
- Audit log records create / update / approve / reject / login / logout actions.
- CORS enabled via Flask-CORS for development; restrict origins in production via `config.py`.

---

## Support

For questions or issues, refer to the project documentation in the `/docs` directory.