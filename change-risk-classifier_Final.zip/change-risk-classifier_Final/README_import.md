# Change Requests Import Tool

This script deletes existing rows from the `change_requests` table and imports data from a CSV file.

## Features

- Safely deletes all existing data from the change_requests table
- Imports data from a CSV file with proper data type conversion
- Handles boolean fields (converts 'true'/'false' strings to 1/0)
- Converts empty strings to NULL values for nullable fields
- Provides detailed import statistics and verification
- User confirmation before deletion

## Usage

### Basic Usage

```bash
python import_change_requests.py
```

### What the Script Does

1. **Connects to the database** at `backend/instance/change_risk_classifier.db`
2. **Shows existing data count** before deletion
3. **Prompts for confirmation** before deleting existing data
4. **Deletes all existing records** from the change_requests table
5. **Imports data from CSV** file at `backend/change_requests_100.csv`
6. **Converts data types** as needed:
   - Boolean fields: 'true'/'false' → 1/0
   - Empty strings → NULL
7. **Verifies the import** with statistics

## CSV File Format

The CSV file should have the following columns (in any order):

- `title` - Change request title
- `description` - Detailed description
- `change_type` - Type (standard, normal, emergency)
- `status` - Status (pending, approved, completed, rejected)
- `change_window` - Window (maintenance_window, business_hours, emergency_window)
- `start_time` - Start datetime
- `end_time` - End datetime
- `critical_ci` - Boolean (true/false)
- `impacted_services` - JSON array of services
- `dependencies` - Dependencies description
- `blast_radius` - Impact scope
- `risk_level` - Risk level
- `risk_score` - Numeric risk score
- `rollback_plan` - Boolean (true/false)
- `test_evidence` - Boolean (true/false)
- `business_owner` - Business owner name
- `technical_owner` - Technical owner name
- `justification` - Change justification
- `submitted_by_id` - User ID who submitted
- `approved_by_id` - User ID who approved
- `submitted_at` - Submission datetime
- `approved_at` - Approval datetime
- `priority` - Priority level
- `estimated_effort` - Estimated effort
- `implementation_notes` - Implementation notes
- `id` - Record ID
- `created_at` - Creation datetime
- `updated_at` - Update datetime
- `change_id` - Change identifier

## Example Output

```
🚀 Change Requests Import Tool
========================================
📁 Database: backend/instance/change_risk_classifier.db
📄 CSV File: backend/change_requests_100.csv

⚠️  This will DELETE all existing data from the change_requests table!
Do you want to continue? (yes/no): yes

🔄 Starting import process...
📊 Found 10 existing records in change_requests table
🗑️  Deleted 10 existing records
✅ Successfully imported 100 records from CSV

📊 Import Verification:
   Total records: 100
   Status distribution:
     - approved: 23
     - completed: 26
     - pending: 24
     - rejected: 27
   Change type distribution:
     - emergency: 38
     - normal: 30
     - standard: 32

✅ Import completed successfully!
   Deleted: 10 records
   Imported: 100 records
   Final count: 100 records
```

## Safety Notes

- **Always backup your database** before running this script
- The script requires explicit user confirmation before deleting data
- The script will only run from the project root directory
- Both the database and CSV files must exist for the script to work

## Requirements

- Python 3.x
- Standard library modules: `sqlite3`, `csv`, `os`, `datetime`