# Change Risk Classifier - Application Architecture Document

**Document Version:** 1.0  
**Date:** March 26, 2026  
**Project:** Change Risk Classifier & Approval Assistant  
**Document Type:** Application Architecture Specification  

## Table of Contents

1. [Introduction](#introduction)
2. [Architecture Overview](#architecture-overview)
3. [System Architecture](#system-architecture)
4. [Component Architecture](#component-architecture)
5. [Data Architecture](#data-architecture)
6. [Integration Architecture](#integration-architecture)
7. [Security Architecture](#security-architecture)
8. [Deployment Architecture](#deployment-architecture)
9. [Performance Architecture](#performance-architecture)
10. [Scalability Architecture](#scalability-architecture)
11. [Appendix](#appendix)

## 1. Introduction

### 1.1 Purpose
This document describes the application architecture for the Change Risk Classifier & Approval Assistant system. It provides a comprehensive view of the system's structural components, their relationships, and the principles guiding their design and evolution.

### 1.2 Scope
The application architecture covers:
- System structure and component organization
- Data flow and processing patterns
- Integration points and external dependencies
- Security and performance considerations
- Deployment and operational aspects

### 1.3 Architecture Principles
- **Modularity**: Components are designed to be independent and loosely coupled
- **Scalability**: System can handle growth in users, data, and transaction volume
- **Maintainability**: Code is well-structured, documented, and follows best practices
- **Security**: Security is built into all layers of the application
- **Performance**: System is optimized for responsiveness and efficiency
- **Flexibility**: Architecture supports future enhancements and technology changes

## 2. Architecture Overview

### 2.1 System Context
The Change Risk Classifier is a web-based application that provides automated risk assessment for IT change requests. The system integrates AI-driven analysis with traditional business rules to classify changes and provide recommendations.

### 2.2 Architecture Style
The system follows a **Layered Architecture** pattern with the following layers:
- **Presentation Layer**: Web-based user interface
- **Application Layer**: Business logic and service orchestration
- **Domain Layer**: Core business entities and rules
- **Infrastructure Layer**: Data access and external integrations

### 2.3 Technology Stack
- **Frontend**: HTML, CSS, JavaScript (Vanilla JS)
- **Backend**: Python Flask (REST API)
- **Database**: SQLite with SQLAlchemy ORM
- **AI Engine**: Deepseek AI integration
- **PDF Generation**: ReportLab
- **Authentication**: JWT tokens

## 3. System Architecture

### 3.1 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Presentation Layer                        │
├─────────────────────────────────────────────────────────────┤
│  Web Browser  │  Dashboard  │  Forms  │  Modals  │  Reports  │
├─────────────────────────────────────────────────────────────┤
│                    Application Layer                         │
├─────────────────────────────────────────────────────────────┤
│  User Service  │  Change Service  │  Risk Service  │  Export  │
├─────────────────────────────────────────────────────────────┤
│                     Domain Layer                             │
├─────────────────────────────────────────────────────────────┤
│  User Entity  │  Change Request  │  Risk Score  │  Rules     │
├─────────────────────────────────────────────────────────────┤
│                   Infrastructure Layer                       │
├─────────────────────────────────────────────────────────────┤
│  Database  │  AI Services  │  PDF Engine  │  Authentication  │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 Component Breakdown

#### 3.2.1 Presentation Layer
**Components:**
- **Index.html**: Main application interface
- **App.js**: Client-side JavaScript logic
- **Styles.css**: Styling and responsive design
- **Modal Components**: View, Edit, and Create modals
- **Dashboard Components**: Charts, filters, and metrics

**Responsibilities:**
- User interface rendering
- User interaction handling
- Client-side validation
- API communication
- Data visualization

#### 3.2.2 Application Layer
**Components:**
- **User Management Service**: Handles user registration, authentication, and profile management
- **Change Request Service**: Manages change request lifecycle (CRUD operations)
- **Risk Assessment Service**: Performs AI-driven risk analysis and classification
- **Dashboard Service**: Aggregates data for dashboard display and analytics
- **Export Service**: Generates PDF reports and data exports

**Responsibilities:**
- Business logic implementation
- Service orchestration
- Data transformation
- External API integration
- Error handling and logging

#### 3.2.3 Domain Layer
**Components:**
- **User Entity**: User account and role management
- **Change Request Entity**: Change request data and metadata
- **Risk Score Entity**: AI-generated risk assessments
- **Business Rules Entity**: Configurable risk assessment rules
- **Audit Log Entity**: System activity tracking

**Responsibilities:**
- Core business entities
- Business rule validation
- Domain logic encapsulation
- Entity relationships
- Data integrity constraints

#### 3.2.4 Infrastructure Layer
**Components:**
- **Database Layer**: SQLite database with SQLAlchemy ORM
- **AI Services Layer**: Deepseek AI integration for risk analysis
- **PDF Generation Layer**: ReportLab for report generation
- **Authentication Layer**: JWT-based authentication system
- **Configuration Layer**: Application settings and environment variables

**Responsibilities:**
- Data persistence
- External service integration
- File generation and export
- Security implementation
- Configuration management

## 4. Component Architecture

### 4.1 User Management Component

```
┌─────────────────────────────────────────┐
│              User Service               │
├─────────────────────────────────────────┤
│  Registration  │  Authentication  │     │
│  Profile Mgmt  │  Authorization   │     │
└─────────────────────────────────────────┘
           │                    │
           ▼                    ▼
┌─────────────────┐    ┌─────────────────┐
│   User Entity   │    │  Auth Provider  │
└─────────────────┘    └─────────────────┘
```

**Key Features:**
- User registration and profile management
- Role-based access control (Admin/User)
- JWT token-based authentication
- Password security with hashing
- Session management

### 4.2 Change Request Management Component

```
┌─────────────────────────────────────────┐
│          Change Request Service         │
├─────────────────────────────────────────┤
│  Create  │  Read  │  Update  │  Delete  │
│  Search  │Filter  │  Status  │  Export  │
└─────────────────────────────────────────┘
           │                    │
           ▼                    ▼
┌─────────────────┐    ┌─────────────────┐
│ Change Request  │    │  Risk Service   │
│     Entity      │    │   Integration   │
└─────────────────┘    └─────────────────┘
```

**Key Features:**
- Complete CRUD operations for change requests
- Advanced search and filtering capabilities
- Status tracking and workflow management
- Integration with risk assessment service
- Data export functionality

### 4.3 Risk Assessment Component

```
┌─────────────────────────────────────────┐
│           Risk Assessment Service       │
├─────────────────────────────────────────┤
│  Deepseek AI  │  Business Rules  │      │
│  Analysis     │  Configuration   │      │
│  Classification│  Override Logic  │      │
└─────────────────────────────────────────┘
           │                    │
           ▼                    ▼
┌─────────────────┐    ┌─────────────────┐
│  Risk Score     │    │  Deepseek API   │
│    Entity       │    │   Integration   │
└─────────────────┘    └─────────────────┘
```

**Key Features:**
- Deepseek AI integration for advanced risk analysis
- Configurable business rules engine
- Multi-factor risk classification
- Manual override capabilities
- Historical learning and improvement

### 4.4 Dashboard and Analytics Component

```
┌─────────────────────────────────────────┐
│             Dashboard Service           │
├─────────────────────────────────────────┤
│  Metrics  │  Charts  │  Filters  │      │
│  Analytics│  Export  │  Real-time│      │
└─────────────────────────────────────────┘
           │                    │
           ▼                    ▼
┌─────────────────┐    ┌─────────────────┐
│  Data Aggregator│    │  Chart Engine   │
│                 │    │                 │
└─────────────────┘    └─────────────────┘
```

**Key Features:**
- Real-time dashboard metrics
- Interactive charts and visualizations
- Advanced filtering and drill-down capabilities
- Performance analytics and reporting
- Export functionality for dashboard data

### 4.5 Export and Reporting Component

```
┌─────────────────────────────────────────┐
│              Export Service             │
├─────────────────────────────────────────┤
│  PDF Report  │  CSV Export  │  Template │
│  Generation  │             │  Engine   │
└─────────────────────────────────────────┘
           │                    │
           ▼                    ▼
┌─────────────────┐    ┌─────────────────┐
│  ReportLab      │    │  Template       │
│  PDF Engine     │    │  Manager        │
└─────────────────┘    └─────────────────┘
```

**Key Features:**
- Comprehensive PDF report generation
- CSV data export functionality
- Template-based report customization
- Landscape orientation support
- Table formatting and layout optimization

## 5. Data Architecture

### 5.1 Database Schema

```
Users Table
├── id (Primary Key)
├── username (Unique)
├── email
├── password_hash
├── full_name
├── role (Admin/User)
├── created_at
└── updated_at

ChangeRequests Table
├── id (Primary Key)
├── title
├── description
├── change_type (Standard/Emergency/Normal)
├── change_window (Business/Maintenance/Emergency)
├── start_time
├── end_time
├── business_owner
├── technical_owner
├── critical_ci (Boolean)
├── impacted_services
├── rollback_plan (Boolean)
├── status (Submitted/Review/Approved/Rejected/Completed)
├── created_at
├── updated_at
└── user_id (Foreign Key to Users)

RiskScores Table
├── id (Primary Key)
├── change_request_id (Foreign Key)
├── risk_level (High/Medium/Low)
├── confidence_score
├── ai_analysis
├── contributing_factors
├── recommendations
├── created_at
└── updated_at

AuditLogs Table
├── id (Primary Key)
├── user_id (Foreign Key)
├── action
├── entity_type
├── entity_id
├── details
├── timestamp
└── ip_address

BusinessRules Table
├── id (Primary Key)
├── rule_name
├── rule_description
├── rule_logic
├── priority
├── is_active
├── created_at
└── updated_at
```

### 5.2 Data Flow Patterns

#### 5.2.1 Change Request Creation Flow
```
User Input → Frontend Validation → API Request → Backend Validation → 
Business Rules Check → AI Analysis → Database Storage → Response
```

#### 5.2.2 Risk Assessment Flow
```
Change Request → Business Rules Engine → Deepseek AI Analysis → 
Risk Classification → Confidence Scoring → Results Storage → Dashboard Update
```

#### 5.2.3 Dashboard Data Flow
```
Database Query → Data Aggregation → Filter Application → 
Chart Generation → Real-time Updates → User Interface
```

### 5.3 Data Security
- **Encryption**: Passwords hashed using secure algorithms
- **Access Control**: Role-based data access restrictions
- **Audit Trail**: All data changes logged with user and timestamp
- **Data Validation**: Input validation at all layers
- **Backup Strategy**: Automated daily database backups

## 6. Integration Architecture

### 6.1 External System Integration

#### 6.1.1 Deepseek AI Integration
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Change Request │ →  │  Deepseek API   │ →  │  Risk Analysis  │
│    Data         │    │   Integration   │    │   Results       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

**Integration Points:**
- RESTful API calls for risk analysis
- JSON data exchange for change request context
- Confidence scoring and detailed reasoning
- Historical data for learning and improvement

#### 6.1.2 Future ITSM Integration
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  ITSM System    │ ←→ │  Integration    │ ←→ │  Change Request │
│  (ServiceNow)  │    │   Layer         │    │  Service        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

**Planned Integrations:**
- ServiceNow change management
- Jira service management
- Monitoring and alerting systems
- Configuration management databases (CMDB)

### 6.2 API Architecture

#### 6.2.1 RESTful API Design
- **Base URL**: `/api/v1/`
- **Authentication**: JWT tokens in Authorization header
- **Response Format**: JSON with consistent structure
- **Error Handling**: Standard HTTP status codes with detailed error messages

#### 6.2.2 Key API Endpoints
```
Authentication:
- POST /api/v1/auth/login
- POST /api/v1/auth/register
- POST /api/v1/auth/logout

Users:
- GET /api/v1/users
- POST /api/v1/users
- PUT /api/v1/users/{id}
- DELETE /api/v1/users/{id}

Change Requests:
- GET /api/v1/changes
- POST /api/v1/changes
- PUT /api/v1/changes/{id}
- DELETE /api/v1/changes/{id}
- GET /api/v1/changes/{id}/risk

Dashboard:
- GET /api/v1/dashboard/summary
- GET /api/v1/dashboard/charts
- GET /api/v1/dashboard/analytics

Export:
- POST /api/v1/export/csv
- POST /api/v1/export/pdf/{change_id}
```

## 7. Security Architecture

### 7.1 Authentication and Authorization

```
┌─────────────────────────────────────────┐
│              Security Layer             │
├─────────────────────────────────────────┤
│  JWT Tokens  │  Role-Based  │  Session  │
│              │  Access      │  Management│
│              │  Control     │           │
└─────────────────────────────────────────┘
           │                    │
           ▼                    ▼
┌─────────────────┐    ┌─────────────────┐
│  Auth Middleware│    │  Permission     │
│                 │    │  Checker        │
└─────────────────┘    └─────────────────┘
```

**Security Features:**
- JWT-based authentication with secure token storage
- Role-based access control (RBAC) implementation
- Session timeout and management
- Password complexity requirements
- Account lockout after failed attempts

### 7.2 Data Protection
- **Input Validation**: Comprehensive validation at all entry points
- **SQL Injection Prevention**: ORM usage with parameterized queries
- **XSS Protection**: Output encoding and content security policies
- **CSRF Protection**: Token-based protection for state-changing operations
- **HTTPS Enforcement**: Secure communication for all API calls

### 7.3 Audit and Monitoring
- **Activity Logging**: All user actions and system events logged
- **Security Monitoring**: Failed login attempts and suspicious activities
- **Data Access Logs**: Track who accessed what data and when
- **Compliance Reporting**: Generate security and audit reports

## 8. Deployment Architecture

### 8.1 Development Environment
```
┌─────────────────────────────────────────┐
│              Development Setup          │
├─────────────────────────────────────────┤
│  Local Flask Server  │  SQLite DB       │
│  Hot Reload          │  Development     │
│  Debug Mode          │  Configuration   │
└─────────────────────────────────────────┘
```

**Development Tools:**
- Python virtual environment
- SQLite for local development
- Flask development server with hot reload
- Debug mode enabled
- Local configuration files

### 8.2 Production Environment
```
┌─────────────────────────────────────────┐
│              Production Setup           │
├─────────────────────────────────────────┤
│  Production Server  │  SQLite DB        │
│  Production Config  │  Backup Strategy  │
│  Security Settings  │  Monitoring       │
└─────────────────────────────────────────┘
```

**Production Features:**
- Production-ready Flask configuration
- Optimized SQLite settings
- Comprehensive backup strategy
- Performance monitoring
- Security hardening

### 8.3 Deployment Process
1. **Code Repository**: Git-based version control
2. **Build Process**: Automated dependency installation
3. **Configuration**: Environment-specific settings
4. **Database Migration**: Schema updates and data migration
5. **Testing**: Automated testing before deployment
6. **Monitoring**: Post-deployment health checks

## 9. Performance Architecture

### 9.1 Performance Optimization Strategies

#### 9.1.1 Frontend Optimization
- **Minification**: CSS and JavaScript file compression
- **Caching**: Browser caching for static assets
- **Lazy Loading**: Load components on demand
- **Efficient DOM**: Minimize DOM manipulations

#### 9.1.2 Backend Optimization
- **Database Indexing**: Optimize query performance
- **Connection Pooling**: Efficient database connection management
- **Caching Strategy**: Implement result caching for expensive operations
- **Async Processing**: Background processing for AI analysis

#### 9.1.3 Database Optimization
- **Index Strategy**: Proper indexing for frequently queried fields
- **Query Optimization**: Efficient SQL queries with proper joins
- **Data Partitioning**: Consider partitioning for large datasets
- **Connection Management**: Optimize connection pooling

### 9.2 Performance Monitoring
- **Response Time Tracking**: Monitor API response times
- **Database Performance**: Track query execution times
- **Memory Usage**: Monitor application memory consumption
- **Error Rate**: Track and analyze error patterns

## 10. Scalability Architecture

### 10.1 Horizontal Scaling Considerations
- **Stateless Design**: Application state not stored on server
- **Database Scaling**: Consider PostgreSQL for larger deployments
- **Load Balancing**: Multiple application instances behind load balancer
- **Caching Layer**: Redis or Memcached for distributed caching

### 10.2 Vertical Scaling Options
- **Resource Allocation**: Increase CPU, memory, and storage
- **Database Optimization**: Optimize SQLite configuration
- **Network Bandwidth**: Ensure sufficient bandwidth for data transfer
- **Storage Performance**: Use SSD storage for better I/O performance

### 10.3 Future Scalability Enhancements
- **Microservices Architecture**: Break down into smaller services
- **Message Queuing**: Implement async processing with queues
- **CDN Integration**: Use CDN for static asset delivery
- **Database Replication**: Master-slave replication for read scaling

## 11. Appendix

### 11.1 Architecture Decision Records

#### ADR-001: Technology Stack Selection
**Decision**: Use Python Flask with SQLite and vanilla JavaScript
**Rationale**: Lightweight, easy to deploy, suitable for initial deployment
**Alternatives Considered**: Django, Node.js, React, PostgreSQL

#### ADR-002: AI Integration Approach
**Decision**: Integrate Deepseek AI via REST API
**Rationale**: Leverage advanced AI capabilities without maintaining ML infrastructure
**Alternatives Considered**: Local ML models, other AI providers

#### ADR-003: Authentication Strategy
**Decision**: JWT-based authentication
**Rationale**: Stateless, scalable, suitable for API-based architecture
**Alternatives Considered**: Session-based, OAuth, SAML

### 11.2 Dependencies and Libraries

#### Backend Dependencies
- **Flask**: Web framework
- **SQLAlchemy**: ORM for database operations
- **Flask-JWT-Extended**: JWT authentication
- **ReportLab**: PDF generation
- **Requests**: HTTP client for API calls

#### Frontend Dependencies
- **Chart.js**: Data visualization
- **PDF.js**: PDF rendering (if needed)
- **Bootstrap**: CSS framework (if used)

### 11.3 Configuration Management
- **Environment Variables**: Separate configs for dev/prod
- **Database Configuration**: Connection strings and settings
- **AI Service Configuration**: API keys and endpoints
- **Security Configuration**: JWT secrets and security settings

### 11.4 Testing Strategy
- **Unit Testing**: Test individual components
- **Integration Testing**: Test component interactions
- **API Testing**: Test REST endpoints
- **UI Testing**: Test user interface functionality
- **Performance Testing**: Load and stress testing

---

**Document Approval:**
- **Prepared by:** Architecture Team
- **Reviewed by:** Technical Lead
- **Approved by:** Project Manager

**Revision History:**
- **v1.0 (2026-03-26):** Initial application architecture document