# Change Risk Classifier - Functional Requirements Document

**Document Version:** 1.0  
**Date:** March 26, 2026  
**Project:** Change Risk Classifier & Approval Assistant  
**Document Type:** Functional Requirements Specification  

## Table of Contents

1. [Introduction](#introduction)
2. [System Overview](#system-overview)
3. [Functional Requirements](#functional-requirements)
   - [3.1 User Management](#31-user-management)
   - [3.2 Change Request Management](#32-change-request-management)
   - [3.3 Risk Assessment & AI Analysis](#33-risk-assessment--ai-analysis)
   - [3.4 Dashboard & Analytics](#34-dashboard--analytics)
   - [3.5 Approval Workflow](#35-approval-workflow)
   - [3.6 Data Import/Export](#36-data-importexport)
   - [3.7 Reporting & PDF Generation](#37-reporting--pdf-generation)
   - [3.8 System Configuration](#38-system-configuration)
4. [Non-Functional Requirements](#non-functional-requirements)
5. [User Interface Requirements](#user-interface-requirements)
6. [Integration Requirements](#integration-requirements)
7. [Security Requirements](#security-requirements)
8. [Appendix](#appendix)

## 1. Introduction

### 1.1 Purpose
This document outlines the functional requirements for the Change Risk Classifier & Approval Assistant system. The system is designed to automate risk assessment for IT change requests using AI-driven analysis and provide a comprehensive dashboard for change management oversight.

### 1.2 Scope
The system provides:
- AI-powered risk classification for change requests
- Automated approval workflows based on risk levels
- Comprehensive dashboard with filtering and analytics
- Manual change entry and editing capabilities
- PDF report generation
- Data import/export functionality
- User management and role-based access control

### 1.3 Definitions
- **Change Request**: A formal proposal for a modification to IT infrastructure, applications, or services
- **Risk Level**: Classification (High/Medium/Low) indicating the potential impact of a change
- **AI Analysis**: Automated risk assessment using configurable business rules and machine learning
- **Dashboard**: Web-based interface for monitoring and managing change requests

## 2. System Overview

### 2.1 System Architecture
The system follows a three-tier architecture:
- **Frontend**: HTML/CSS/JavaScript web interface
- **Backend**: Python Flask REST API
- **Database**: SQLite with SQLAlchemy ORM

### 2.2 Key Components
- **User Management Service**: Handles authentication and authorization
- **Change Request Service**: Manages change request lifecycle
- **Risk Assessment Service**: Performs AI-driven risk analysis
- **Dashboard Service**: Provides data aggregation and reporting
- **Export Service**: Generates PDF reports and data exports

## 3. Functional Requirements

### 3.1 User Management

#### 3.1.1 User Registration and Authentication
- **FR-001**: System SHALL allow users to register with username, email, password, and full name
- **FR-002**: System SHALL authenticate users using username and password
- **FR-003**: System SHALL support role-based access control (Admin, User)
- **FR-004**: System SHALL create default admin user (admin/admin123) on first run

#### 3.1.2 User Profile Management
- **FR-005**: Users SHALL be able to view their profile information
- **FR-006**: Users SHALL be able to update their profile details
- **FR-007**: Admin users SHALL be able to manage all user accounts

### 3.2 Change Request Management

#### 3.2.1 Change Request Creation
- **FR-008**: Users SHALL be able to create new change requests with the following mandatory fields:
  - Title
  - Description
  - Change type (Standard, Emergency, Normal)
  - Change window (Business Hours, Maintenance Window, Emergency)
  - Start and end times
  - Business owner
  - Technical owner
  - Critical CI (Critical Configuration Item) status
  - Impacted services
  - Rollback plan availability

#### 3.2.2 Change Request Editing
- **FR-009**: Users SHALL be able to edit pending change requests
- **FR-010**: System SHALL provide inline editing for change request fields
- **FR-011**: System SHALL validate all required fields before saving changes
- **FR-012**: System SHALL display missing information flags for incomplete fields

#### 3.2.3 Change Request Status Management
- **FR-013**: System SHALL support the following status states:
  - Submitted
  - Review
  - Approved
  - Rejected
  - Completed
- **FR-014**: Users SHALL be able to view change request details in a modal dialog
- **FR-015**: System SHALL display AI-generated risk analysis and recommendations

#### 3.2.4 Change Request Search and Filtering
- **FR-016**: Users SHALL be able to search change requests by title, description, or owner
- **FR-017**: System SHALL support filtering by status, risk level, change type, and time window
- **FR-018**: System SHALL support date range filtering for change requests
- **FR-019**: System SHALL support combined filter application

### 3.3 Risk Assessment & AI Analysis

#### 3.3.1 Deepseek AI Integration
- **FR-020**: System SHALL integrate Deepseek AI for advanced risk categorization and analysis
- **FR-021**: Deepseek AI SHALL analyze change request context including:
  - Technical complexity and dependencies
  - Business impact assessment
  - Historical change patterns and outcomes
  - Service interdependencies and criticality
  - Timing and operational window considerations
- **FR-022**: Deepseek AI SHALL generate comprehensive risk tagging with specific categorization
- **FR-023**: System SHALL use Deepseek AI to provide detailed reasoning for risk classifications

#### 3.3.2 Automated Risk Classification
- **FR-024**: System SHALL automatically classify change requests into risk levels (High/Medium/Low)
- **FR-025**: Risk classification SHALL consider:
  - Critical CI status
  - Change window timing
  - Number of impacted services
  - Rollback plan availability
  - Change type (Emergency vs Standard)
  - Deepseek AI analysis results
- **FR-026**: System SHALL generate AI-powered risk analysis with contributing factors
- **FR-027**: System SHALL provide specific mitigation suggestions based on change characteristics and Deepseek AI insights

#### 3.3.3 AI Analysis Configuration
- **FR-028**: System SHALL use configurable business rules for risk assessment
- **FR-029**: System SHALL support rule-based logic for different risk scenarios
- **FR-030**: Deepseek AI integration SHALL be configurable for different organizational contexts
- **FR-031**: System SHALL generate detailed reasoning for risk classifications using Deepseek AI
- **FR-032**: System SHALL provide confidence levels for AI assessments with Deepseek AI scoring
- **FR-033**: Deepseek AI SHALL analyze historical data to improve risk prediction accuracy over time

#### 3.3.4 Risk Tagging and Categorization
- **FR-034**: Deepseek AI SHALL categorize risks into specific tags such as:
  - Technical Risk (Infrastructure, Application, Network)
  - Business Risk (Customer Impact, Revenue Impact, Compliance)
  - Operational Risk (Timing, Resource Availability, Dependencies)
  - Security Risk (Data Protection, Access Control, Vulnerabilities)
- **FR-035**: System SHALL provide detailed reasons for each risk tag assignment
- **FR-036**: Deepseek AI SHALL identify primary and secondary risk factors
- **FR-037**: System SHALL generate actionable insights for each identified risk category

#### 3.3.5 Manual Risk Override
- **FR-038**: Authorized users SHALL be able to manually override AI-generated risk levels
- **FR-039**: System SHALL log all manual risk level changes with audit trail
- **FR-040**: Manual overrides SHALL require justification and approval workflow
- **FR-041**: System SHALL compare manual overrides with Deepseek AI recommendations for learning

### 3.4 Dashboard & Analytics

#### 3.4.1 Dashboard Overview
- **FR-030**: System SHALL provide a comprehensive dashboard with key metrics:
  - Total changes
  - Pending changes
  - Approved changes
  - Risk distribution (High/Medium/Low)
- **FR-031**: Dashboard SHALL update in real-time as changes are made

#### 3.4.2 Dashboard Filtering
- **FR-032**: Dashboard SHALL support filtering by:
  - Status
  - Risk level
  - Change type
  - Time window
  - Date range
  - Search terms
- **FR-033**: All dashboard metrics SHALL update based on applied filters
- **FR-034**: Dashboard SHALL display charts for:
  - Changes by time window
  - Changes by technical owner
  - Risk level distribution

#### 3.4.3 Data Visualization
- **FR-035**: System SHALL display interactive charts and graphs
- **FR-036**: Charts SHALL support drill-down functionality
- **FR-037**: Dashboard SHALL handle large datasets (100+ records) efficiently
- **FR-038**: System SHALL provide pagination for change request lists

#### 3.4.4 Performance Analytics
- **FR-039**: System SHALL track and display:
  - Average approval times
  - Success rates by risk level
  - Total submitted changes
  - Rejected change counts

### 3.5 Approval Workflow

#### 3.5.1 Automated Approval Rules
- **FR-040**: System SHALL automatically approve Low-risk changes
- **FR-041**: System SHALL route Medium-risk changes for manual review
- **FR-042**: System SHALL require strict conditions for High-risk change approval

#### 3.5.2 Manual Approval Process
- **FR-043**: Authorized users SHALL be able to approve or reject change requests
- **FR-044**: System SHALL display AI recommendations during approval process
- **FR-045**: System SHALL log all approval decisions with timestamps and approver information

#### 3.5.3 Approval Notifications
- **FR-046**: System SHALL notify relevant stakeholders of approval status changes
- **FR-047**: System SHALL display pending approval requests on dashboard

### 3.6 Data Import/Export

#### 3.6.1 Data Import
- **FR-048**: System SHALL support importing change requests from CSV files
- **FR-049**: Import process SHALL validate data integrity and format
- **FR-050**: System SHALL automatically generate risk scores for imported changes
- **FR-051**: Import process SHALL handle 100+ records efficiently
- **FR-052**: System SHALL provide import status and summary reports

#### 3.6.2 Data Export
- **FR-053**: System SHALL export change request data to CSV format
- **FR-054**: Export SHALL include all change request fields and risk assessments
- **FR-055**: System SHALL support filtered exports based on dashboard filters
- **FR-056**: Export process SHALL handle large datasets efficiently

### 3.7 Reporting & PDF Generation

#### 3.7.1 PDF Report Generation
- **FR-057**: System SHALL generate comprehensive PDF reports for individual change requests
- **FR-058**: PDF reports SHALL include:
  - Change request details
  - Risk assessment and analysis
  - AI-generated recommendations
  - Contributing factors
  - Mitigation suggestions
- **FR-059**: PDF reports SHALL use landscape orientation for optimal layout
- **FR-060**: System SHALL handle table formatting to prevent data overlap

#### 3.7.2 Report Customization
- **FR-061**: Users SHALL be able to select which sections to include in PDF reports
- **FR-062**: System SHALL support different report templates for different change types

### 3.8 System Configuration

#### 3.8.1 Risk Rules Configuration
- **FR-063**: System SHALL support configurable risk assessment rules
- **FR-064**: Admin users SHALL be able to modify risk calculation logic
- **FR-065**: System SHALL validate rule configurations for consistency

#### 3.8.2 System Settings
- **FR-066**: System SHALL support configuration of:
  - Default change windows
  - Risk threshold values
  - Approval workflow rules
  - Notification settings

## 4. Non-Functional Requirements

### 4.1 Performance Requirements
- **NFR-001**: System SHALL support concurrent access by multiple users
- **NFR-002**: Dashboard SHALL load and render within 3 seconds for 100+ records
- **NFR-003**: Search and filter operations SHALL complete within 2 seconds
- **NFR-004**: PDF generation SHALL complete within 10 seconds for single change requests

### 4.2 Scalability Requirements
- **NFR-005**: System SHALL handle up to 1000 change requests efficiently
- **NFR-006**: Database design SHALL support future scaling to enterprise-level volumes
- **NFR-007**: System SHALL maintain performance with increasing data volumes

### 4.3 Usability Requirements
- **NFR-008**: System SHALL be accessible via standard web browsers (Chrome, Firefox, Safari, Edge)
- **NFR-009**: User interface SHALL be intuitive and require minimal training
- **NFR-010**: System SHALL provide clear error messages and guidance for user actions
- **NFR-011**: All forms SHALL include field validation and helpful tooltips

### 4.4 Reliability Requirements
- **NFR-012**: System SHALL maintain 99% uptime during business hours
- **NFR-013**: Data SHALL be automatically backed up daily
- **NFR-014**: System SHALL handle unexpected errors gracefully without data loss

### 4.5 Maintainability Requirements
- **NFR-015**: System SHALL be modular for easy maintenance and updates
- **NFR-016**: Code SHALL be well-documented and follow established coding standards
- **NFR-017**: System SHALL support configuration changes without code modifications

## 5. User Interface Requirements

### 5.1 Dashboard Interface
- **UI-001**: Dashboard SHALL display key metrics in a clear, at-a-glance format
- **UI-002**: Charts and graphs SHALL be interactive and responsive
- **UI-003**: Filter controls SHALL be prominently placed and easy to use
- **UI-004**: Change request list SHALL support sorting and pagination

### 5.2 Change Request Forms
- **UI-005**: Forms SHALL use clear labels and intuitive field layouts
- **UI-006**: Required fields SHALL be clearly marked
- **UI-007**: Form validation SHALL provide immediate feedback
- **UI-008**: Missing information SHALL be highlighted with visual indicators

### 5.3 Modal Dialogs
- **UI-009**: Modal dialogs SHALL display comprehensive change request information
- **UI-010**: Risk analysis SHALL be presented in an easy-to-understand format
- **UI-011**: Modal SHALL include action buttons for editing and approval
- **UI-012**: Modal SHALL be responsive and work on different screen sizes

### 5.4 Navigation
- **UI-013**: System SHALL provide clear navigation between different views
- **UI-014**: Breadcrumb navigation SHALL indicate current location
- **UI-015**: Consistent layout and styling SHALL be maintained across all pages

## 6. Integration Requirements

### 6.1 External System Integration
- **IR-001**: System SHALL provide RESTful APIs for external system integration
- **IR-002**: API SHALL support CRUD operations for change requests
- **IR-003**: API SHALL include authentication and authorization
- **IR-004**: System SHALL support webhook notifications for status changes

### 6.2 Data Exchange
- **IR-005**: System SHALL support standard data formats (JSON, CSV, PDF)
- **IR-006**: Import/Export functions SHALL handle data validation and error reporting
- **IR-007**: System SHALL maintain data integrity during import/export operations

## 7. Security Requirements

### 7.1 Authentication and Authorization
- **SR-001**: System SHALL implement secure password storage using hashing
- **SR-002**: System SHALL support session management with timeout
- **SR-003**: Role-based access control SHALL restrict functionality based on user roles
- **SR-004**: Admin functions SHALL require elevated privileges

### 7.2 Data Protection
- **SR-005**: System SHALL log all sensitive operations for audit purposes
- **SR-006**: Data transmission SHALL use HTTPS encryption
- **SR-007**: System SHALL prevent SQL injection and XSS attacks
- **SR-008**: Sensitive data SHALL be masked in logs and error messages

### 7.3 Privacy Requirements
- **SR-009**: System SHALL comply with data protection regulations
- **SR-010**: User data SHALL only be used for system functionality
- **SR-011**: System SHALL provide data export capabilities for compliance

## 8. Appendix

### 8.1 Data Models
The system includes the following primary entities:
- **Users**: User accounts with roles and permissions
- **Change Requests**: Change request details and metadata
- **Risk Scores**: AI-generated risk assessments and analysis
- **Audit Logs**: System activity and change tracking
- **Rules**: Configurable business rules for risk assessment

### 8.2 Technology Stack
- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Python Flask
- **Database**: SQLite with SQLAlchemy ORM
- **AI Engine**: Deepseek AI integration for advanced risk categorization and analysis
- **Business Rules**: Configurable rule-based system with business logic
- **PDF Generation**: ReportLab library
- **Authentication**: JWT tokens
- **AI Services**: Deepseek API for natural language processing and risk assessment

### 8.3 Deployment Requirements
- **DR-001**: System SHALL be deployable on standard web servers
- **DR-002**: Database SHALL be self-contained and require minimal setup
- **DR-003**: System SHALL support both development and production configurations
- **DR-004**: Installation process SHALL be documented and automated

### 8.4 Future Enhancements
- Integration with ITSM tools (ServiceNow, Jira)
- Advanced machine learning for risk prediction
- Mobile application support
- Advanced analytics and predictive modeling
- Integration with monitoring and alerting systems

---

**Document Approval:**
- **Prepared by:** Development Team
- **Reviewed by:** Project Stakeholders
- **Approved by:** Project Manager

**Revision History:**
- **v1.0 (2026-03-26):** Initial functional requirements document