# Change Risk Classifier - End User Manual

**Document Version:** 1.0  
**Date:** March 27, 2026  
**Project:** Change Risk Classifier & Approval Assistant  
**Audience:** End Users, Administrators, and Support Staff  

## Table of Contents

1. [Introduction](#introduction)
2. [System Overview](#system-overview)
3. [Getting Started](#getting-started)
4. [User Interface Guide](#user-interface-guide)
5. [Dashboard Usage](#dashboard-usage)
6. [Change Request Management](#change-request-management)
7. [AI Risk Assessment](#ai-risk-assessment)
8. [Reporting and Export](#reporting-and-export)
9. [User Management](#user-management)
10. [Troubleshooting](#troubleshooting)
11. [FAQ](#faq)
12. [Support and Contact](#support-and-contact)

## 1. Introduction

### 1.1 Welcome to Change Risk Classifier
The Change Risk Classifier & Approval Assistant is a powerful web-based application designed to streamline your IT change management process. This system uses advanced AI technology to automatically assess and categorize change requests, helping you make informed decisions about risk levels and approval workflows.

### 1.2 What This Manual Covers
This manual provides comprehensive guidance on:
- Navigating the user interface
- Creating and managing change requests
- Understanding AI risk assessments
- Using dashboard analytics
- Generating reports and exports
- User management features

### 1.3 System Benefits
- **Automated Risk Assessment**: AI-powered risk classification
- **Streamlined Workflow**: Automated approval processes based on risk levels
- **Real-time Analytics**: Dashboard with comprehensive metrics and charts
- **Easy Reporting**: One-click PDF and CSV exports
- **User-friendly Interface**: Intuitive design for all user levels

## 2. System Overview

### 2.1 System Architecture
The Change Risk Classifier consists of:
- **Web Interface**: Browser-based user interface
- **Backend API**: RESTful services for data processing
- **AI Engine**: Deepseek AI integration for risk analysis
- **Database**: Secure data storage and management

### 2.2 Supported Browsers
For optimal performance, use:
- Google Chrome (latest version)
- Mozilla Firefox (latest version)
- Microsoft Edge (latest version)
- Safari (latest version)

### 2.3 System Requirements
- **Internet Connection**: Required for web access
- **Screen Resolution**: Minimum 1024x768
- **JavaScript**: Must be enabled
- **Cookies**: Required for session management

## 3. Getting Started

### 3.1 Accessing the System

#### 3.1.1 System URL
To access the Change Risk Classifier, open your web browser and navigate to:
```
http://localhost:5000
```
*(Replace with your actual server URL)*

#### 3.1.2 Initial Login Screen
When you first access the system, you'll see the login screen:

**Login Screen Elements:**
- **Username Field**: Enter your username
- **Password Field**: Enter your password
- **Login Button**: Click to sign in
- **Register Link**: For new user registration

### 3.2 User Registration

#### 3.2.1 Creating a New Account
1. Click the **"Register"** link on the login page
2. Fill in the registration form:
   - **Username**: Your preferred username
   - **Email**: Valid email address
   - **Password**: Strong password (minimum 8 characters)
   - **Full Name**: Your complete name
3. Click **"Register"** to create your account

#### 3.2.2 Default Admin Account
For the first-time setup, use the default admin credentials:
- **Username**: `admin`
- **Password**: `admin123`

**⚠️ Security Note**: Change the default admin password immediately after first login.

### 3.3 Logging In

#### 3.3.1 Standard Login Process
1. Enter your username in the **Username** field
2. Enter your password in the **Password** field
3. Click the **"Login"** button
4. You will be redirected to the dashboard

#### 3.3.2 Login Troubleshooting
**If login fails:**
- Check username and password for typos
- Ensure Caps Lock is off
- Verify your account is active
- Contact your system administrator if issues persist

### 3.4 First-Time User Setup

#### 3.3.1 Profile Configuration
After your first login:
1. Click on your username in the top navigation
2. Select **"Profile"** from the dropdown menu
3. Update your profile information as needed
4. Click **"Save"** to apply changes

## 4. User Interface Guide

### 4.1 Main Dashboard Layout

#### 4.1.1 Navigation Bar
Located at the top of every page:

**Navigation Elements:**
- **Dashboard**: Return to main dashboard
- **Create Change**: Start a new change request
- **Logout**: End your session

#### 4.1.2 Dashboard Overview
The main dashboard displays:

**Key Metrics Cards:**
- **Total Changes**: Total number of change requests
- **Pending Changes**: Changes awaiting approval
- **Approved Changes**: Successfully approved changes
- **Risk Distribution**: Pie chart showing High/Medium/Low risk distribution

**Charts Section:**
- **Changes by Time Window**: Bar chart of changes by timing
- **Changes by Technical Owner**: Bar chart of changes by owner
- **Risk Level Distribution**: Donut chart of risk levels

### 4.2 Change Request List View

#### 4.2.1 List Layout
The change request list displays in a table format with columns:
- **ID**: Unique change request identifier
- **Title**: Change request title
- **Type**: Change type (Standard/Emergency/Normal)
- **Window**: Time window (Business/Maintenance/Emergency)
- **Risk Level**: AI-assigned risk level (High/Medium/Low)
- **Status**: Current status (Pending/Approved/Rejected/Completed)
- **Owner**: Technical owner name
- **Actions**: View, Edit, Export buttons

#### 4.2.2 Action Buttons
- **👁️ View**: Open detailed view in modal
- **✏️ Edit**: Edit change request (if pending)
- **📄 Export**: Export to PDF report

### 4.3 Search and Filter Interface

#### 4.3.1 Search Functionality
- **Search Box**: Enter keywords to search across all fields
- **Search Button**: Click to execute search
- **Real-time Results**: Results update as you type

#### 4.3.2 Filter Options
**Available Filters:**
- **Status Filter**: Pending, Approved, Rejected, Completed
- **Risk Level Filter**: High, Medium, Low
- **Change Type Filter**: Standard, Emergency, Normal
- **Time Window Filter**: Business Hours, Maintenance Window, Emergency
- **Date Range Filter**: Custom date range selection

#### 4.3.3 Applying Filters
1. Select your desired filter criteria
2. Click **"Apply Filters"**
3. Results update automatically
4. Click **"Clear Filters"** to reset

## 5. Dashboard Usage

### 5.1 Dashboard Metrics

#### 5.1.1 Understanding Key Metrics
**Total Changes**: Shows the total number of change requests in the system

**Pending Changes**: Displays changes awaiting approval or review

**Approved Changes**: Shows successfully approved changes

**Risk Distribution**: Visual representation of risk levels across all changes

#### 5.1.2 Metric Updates
- **Real-time Updates**: Metrics update automatically
- **Filter Impact**: Metrics reflect current filter selections
- **Refresh**: Manual refresh available via browser refresh

### 5.2 Dashboard Charts

#### 5.2.1 Changes by Time Window Chart
**Purpose**: Shows distribution of changes across different time windows

**Chart Type**: Horizontal bar chart

**Data Displayed**:
- Business Hours changes
- Maintenance Window changes
- Emergency changes

#### 5.2.2 Changes by Technical Owner Chart
**Purpose**: Shows which technical owners have the most changes

**Chart Type**: Horizontal bar chart

**Usage**:
- Hover over bars for exact counts
- Click bars to filter by owner
- Useful for workload distribution analysis

#### 5.2.3 Risk Level Distribution Chart
**Purpose**: Shows the overall risk profile of your changes

**Chart Type**: Donut chart

**Risk Levels**:
- **High Risk**: Red section
- **Medium Risk**: Orange section
- **Low Risk**: Green section

### 5.3 Dashboard Filtering

#### 5.3.1 Applying Dashboard Filters
1. Use the filter controls above the charts
2. Select your criteria (status, risk level, date range, etc.)
3. Charts and metrics update automatically
4. Change list below reflects the same filters

#### 5.3.2 Filter Combinations
You can combine multiple filters:
- Status + Risk Level
- Date Range + Change Type
- All available filters together

**Note**: Results show only changes matching ALL selected criteria

### 5.4 Dashboard Export

#### 5.4.1 Exporting Dashboard Data
1. Click the **"Export CSV"** button
2. Select export options if available
3. File downloads automatically
4. Open in spreadsheet application for analysis

## 6. Change Request Management

### 6.1 Creating a New Change Request

#### 6.1.1 Accessing the Create Form
1. Click **"Create Change"** in the navigation bar
2. The create form appears in a modal dialog
3. Fill in all required fields
4. Click **"Submit"** to create the change

#### 6.1.2 Required Fields
**Mandatory Information**:
- **Title**: Brief, descriptive title
- **Description**: Detailed change description
- **Change Type**: Standard, Emergency, or Normal
- **Change Window**: Business Hours, Maintenance Window, or Emergency
- **Start Time**: When the change will begin
- **End Time**: When the change will complete
- **Business Owner**: Person responsible for business impact
- **Technical Owner**: Person responsible for technical implementation

#### 6.1.3 Optional Fields
**Additional Information**:
- **Critical CI**: Check if change affects critical configuration items
- **Impacted Services**: List of services affected
- **Rollback Plan**: Whether a rollback plan exists
- **Dependencies**: Other changes or systems this depends on

### 6.2 Editing Change Requests

#### 6.2.1 When Editing is Available
- Only **Pending** changes can be edited
- **Approved**, **Rejected**, or **Completed** changes are read-only
- Edit button only appears for editable changes

#### 6.2.2 Editing Process
1. Locate the change request in the list
2. Click the **✏️ Edit** button
3. Modify the desired fields
4. Click **"Save"** to update the change

#### 6.2.3 Edit Restrictions
- **Status**: Cannot be changed manually (updated by workflow)
- **Risk Level**: Cannot be changed manually (updated by AI)
- **Created Date**: Cannot be modified
- **User ID**: Cannot be changed

### 6.3 Viewing Change Request Details

#### 6.3.1 Opening the View Modal
1. Click the **👁️ View** button for any change
2. Detailed information appears in a modal dialog
3. Modal includes all change information and AI analysis

#### 6.3.2 View Modal Sections
**Change Information**:
- Basic change details
- Owner information
- Timing and scheduling

**AI Risk Assessment**:
- Risk level classification
- Contributing factors
- AI-generated recommendations

**Missing Information Flags**:
- Visual indicators for incomplete data
- Suggestions for additional information

### 6.4 Change Request Status Workflow

#### 6.4.1 Status States
**Pending**: Change created, awaiting review/approval

**Review**: Change under review (for Medium risk changes)

**Approved**: Change approved and ready for implementation

**Rejected**: Change rejected with reason provided

**Completed**: Change successfully implemented

#### 6.4.2 Automatic Status Changes
- **Low Risk**: Automatically approved
- **Medium Risk**: Requires manual review
- **High Risk**: Requires strict approval process

## 7. AI Risk Assessment

### 7.1 Understanding AI Risk Classification

#### 7.1.1 Risk Levels Explained
**High Risk (Red)**:
- Critical systems affected
- High business impact potential
- Requires multiple approvals
- Emergency rollback procedures needed

**Medium Risk (Orange)**:
- Moderate business impact
- Requires managerial approval
- Standard rollback procedures

**Low Risk (Green)**:
- Minimal business impact
- Automatic approval
- Standard procedures apply

#### 7.1.2 AI Analysis Factors
The AI considers multiple factors:
- **Technical Complexity**: System dependencies and complexity
- **Business Impact**: Customer and revenue impact
- **Timing**: Change window and operational timing
- **Historical Data**: Similar past changes and outcomes
- **Service Dependencies**: Interconnected systems affected

### 7.2 AI-Generated Recommendations

#### 7.2.1 Contributing Factors
The AI identifies specific factors contributing to the risk level:
- **Critical CI Impact**: Whether critical systems are affected
- **Rollback Plan**: Availability of rollback procedures
- **Change Window**: Timing of the change
- **Service Dependencies**: Number of dependent services

#### 7.2.2 Mitigation Suggestions
AI provides specific recommendations:
- **Additional Testing**: Suggested testing procedures
- **Stakeholder Notification**: Who should be informed
- **Rollback Preparation**: Rollback plan requirements
- **Monitoring**: Enhanced monitoring needs

### 7.3 Manual Risk Override

#### 7.3.1 When Override is Needed
Manual override may be necessary when:
- AI assessment doesn't match organizational risk tolerance
- Additional context not captured in the form
- Business priorities require different risk classification

#### 7.3.2 Override Process
1. View the change request details
2. Use the risk override function
3. Select new risk level
4. Provide justification
5. Submit for approval

**⚠️ Note**: Overrides require appropriate permissions and audit trail logging

## 8. Reporting and Export

### 8.1 PDF Report Generation

#### 8.1.1 Creating PDF Reports
1. Locate the desired change request
2. Click the **📄 Export** button
3. PDF file downloads automatically
4. Open with any PDF reader

#### 8.1.2 PDF Report Contents
**Report Sections**:
- Change request summary
- Detailed description and specifications
- AI risk assessment and analysis
- Contributing factors and recommendations
- Approval workflow history
- Technical and business owner information

#### 8.1.3 PDF Report Features
- **Landscape Orientation**: Optimized for wide content
- **Professional Formatting**: Clean, readable layout
- **Complete Information**: All relevant change data
- **Print Ready**: High-quality printing capability

### 8.2 CSV Data Export

#### 8.2.1 Dashboard Data Export
1. Click **"Export CSV"** on the dashboard
2. Data exports with current filter settings
3. File downloads automatically
4. Open in spreadsheet applications

#### 8.2.2 Exported Data Fields
- Change ID and title
- Risk level and status
- Owner information
- Timing and scheduling
- AI assessment results
- Approval workflow data

### 8.3 Report Customization

#### 8.3.1 Filter-Based Exports
- Apply filters before exporting
- Export only relevant data
- Customize date ranges and criteria
- Generate targeted reports

#### 8.3.2 Report Scheduling
For regular reporting needs:
- Manual export process
- Filter and export as needed
- Schedule regular manual exports
- Use browser automation for recurring reports

## 9. User Management

### 9.1 User Roles and Permissions

#### 9.1.1 Admin Role
**Admin Privileges**:
- Create and manage user accounts
- Configure system settings
- Access all change requests
- Override risk assessments
- View all reports and analytics

#### 9.1.2 User Role
**User Privileges**:
- Create change requests
- View own change requests
- Edit pending changes
- View dashboard analytics
- Export reports for owned changes

### 9.2 Profile Management

#### 9.2.1 Updating Profile Information
1. Click your username in the navigation bar
2. Select **"Profile"** from dropdown
3. Edit your information
4. Click **"Save"** to update

#### 9.2.2 Profile Fields
- **Username**: Cannot be changed
- **Email**: Update email address
- **Full Name**: Update display name
- **Password**: Change password (requires current password)

### 9.3 Password Management

#### 9.3.1 Changing Password
1. Go to Profile settings
2. Click **"Change Password"**
3. Enter current password
4. Enter new password (minimum 8 characters)
5. Confirm new password
6. Click **"Save"**

#### 9.3.2 Password Requirements
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- Special characters allowed

## 10. Troubleshooting

### 10.1 Common Issues and Solutions

#### 10.1.1 Login Problems
**Issue**: Cannot log in
**Solutions**:
- Check username and password for typos
- Ensure Caps Lock is off
- Try resetting password
- Contact administrator if account is locked

**Issue**: "Account locked" message
**Solutions**:
- Wait 15 minutes and try again
- Contact administrator to unlock account
- Verify account is still active

#### 10.1.2 Browser Issues
**Issue**: Page not loading correctly
**Solutions**:
- Clear browser cache and cookies
- Try a different browser
- Disable browser extensions temporarily
- Check internet connection

**Issue**: JavaScript errors
**Solutions**:
- Ensure JavaScript is enabled
- Update browser to latest version
- Disable conflicting browser extensions
- Contact support with error details

#### 10.1.3 Change Request Issues
**Issue**: Cannot edit change request
**Solutions**:
- Verify change status is "Pending"
- Check user permissions
- Ensure you created the change request
- Contact administrator if needed

**Issue**: AI analysis not appearing
**Solutions**:
- Ensure all required fields are filled
- Check internet connection
- Refresh the page
- Contact support if issue persists

### 10.2 Performance Optimization

#### 10.2.1 Improving System Performance
- Use recommended browsers
- Clear cache regularly
- Close unnecessary browser tabs
- Ensure stable internet connection
- Use filters to reduce data load

#### 10.2.2 Large Dataset Handling
For systems with many change requests:
- Use date range filters
- Apply specific search criteria
- Export data for offline analysis
- Use pagination for browsing

### 10.3 Error Messages

#### 10.3.1 Common Error Messages
**"Validation Error"**: Required fields missing or invalid data
**Solution**: Check all required fields and correct any errors

**"Permission Denied"**: Insufficient user permissions
**Solution**: Contact administrator for appropriate access

**"Network Error"**: Connection issues
**Solution**: Check internet connection and try again

**"Server Error"**: System issues
**Solution**: Contact support with error details and timestamp

## 11. FAQ

### 11.1 General Questions

**Q: How do I reset my password?**
A: Contact your system administrator to reset your password.

**Q: Can I access the system from mobile devices?**
A: Yes, the system is responsive and works on mobile devices, though some features may be optimized for desktop use.

**Q: How long are change requests stored?**
A: Change requests are stored indefinitely unless manually deleted by an administrator.

**Q: Can I create change requests offline?**
A: No, an internet connection is required to access and use the system.

### 11.2 Change Request Questions

**Q: Who can approve change requests?**
A: Approval depends on risk level - Low risk auto-approves, Medium and High risk require manual approval by authorized users.

**Q: How long does AI analysis take?**
A: AI analysis is typically instantaneous, but may take a few seconds for complex changes.

**Q: Can I modify a change request after approval?**
A: No, approved changes become read-only. Create a new change request for modifications.

**Q: What happens if I don't provide all optional information?**
A: The system will still work, but AI analysis may be less accurate. Missing information flags will indicate what could improve risk assessment.

### 11.3 Technical Questions

**Q: Is my data secure?**
A: Yes, the system uses industry-standard security practices including password hashing and secure data transmission.

**Q: Can multiple users work on the same change request?**
A: Multiple users can view the same change, but only the creator can edit pending changes.

**Q: What happens during system maintenance?**
A: The system will display a maintenance notice. Schedule maintenance during low-usage periods.

**Q: How often is data backed up?**
A: Data is automatically backed up daily. Contact your administrator for backup details.

## 12. Support and Contact

### 12.1 Getting Help

#### 12.1.1 Self-Help Resources
- This user manual
- In-application help text
- Error message guidance
- FAQ section

#### 12.1.2 Contacting Support
**For technical issues or questions:**
- Contact your system administrator
- Email: support@changemanagement.com
- Phone: [Your support phone number]
- Include system details and error messages when reporting issues

### 12.2 Support Information

#### 12.2.1 What to Include in Support Requests
- Your username and role
- Description of the issue
- Steps to reproduce the problem
- Browser and version used
- Screenshots if applicable
- Error messages received

#### 12.2.2 Support Hours
- **Business Hours**: Monday-Friday, 9:00 AM - 6:00 PM [Your timezone]
- **Emergency Support**: Available for critical system issues
- **Response Time**: Typically within 24 hours for standard requests

### 12.3 System Updates

#### 12.3.1 Update Notifications
- System updates will be announced in advance
- Maintenance windows will be scheduled during low-usage periods
- Updates may include new features, bug fixes, or security improvements

#### 12.3.2 Staying Informed
- Check for system announcements
- Review updated documentation
- Attend training sessions for new features
- Follow internal communication channels

---

**Document Version**: 1.0  
**Last Updated**: March 27, 2026  
**Next Review**: September 27, 2026  

**For the most current version of this manual, please visit**: [Your documentation URL]

**Feedback**: We welcome your feedback on this manual. Please contact documentation@changemanagement.com with suggestions for improvement.