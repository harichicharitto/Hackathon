# Change Risk Classifier - Quick Reference Guide

**Document Version:** 1.0  
**Date:** March 27, 2026  
**Project:** Change Risk Classifier & Approval Assistant  

## Screen Reference Guide

### 1. Login Screen

```
┌─────────────────────────────────────────────────────────────┐
│                    Change Risk Classifier                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │                    LOGIN                                │
│  │                                                       │  │
│  │  Username:  [________________________]                 │  │
│  │                                                       │  │
│  │  Password:   [________________________]                 │  │
│  │                                                       │  │
│  │  [      LOGIN      ]  [    REGISTER    ]              │  │
│  │                                                       │  │
│  │  Forgot Password?                                     │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Key Elements:**
- **Username Field**: Enter your username
- **Password Field**: Enter your password
- **Login Button**: Click to sign in
- **Register Link**: Create new account
- **Default Admin**: admin/admin123 (change immediately)

---

### 2. Main Dashboard

```
┌─────────────────────────────────────────────────────────────┐
│  Dashboard  |  Create Change  |  [Username]  |  Logout     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │   TOTAL     │  │   PENDING   │  │  APPROVED   │         │
│  │   CHANGES   │  │   CHANGES   │  │  CHANGES    │         │
│  │             │  │             │  │             │         │
│  │     100     │  │      15     │  │      85     │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  RISK DISTRIBUTION                                    │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │  High: 2    Medium: 39    Low: 59              │  │  │
│  │  │  [Donut Chart Visualization]                    │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  FILTERS                                              │  │
│  │  Status: [All ▼]  Risk: [All ▼]  Type: [All ▼]       │  │
│  │  [Apply Filters] [Clear Filters] [Export CSV]        │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  CHANGES BY TIME WINDOW                               │  │
│  │  [Horizontal Bar Chart]                               │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  CHANGES BY TECHNICAL OWNER                           │  │
│  │  [Horizontal Bar Chart]                               │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Dashboard Features:**
- **Navigation Bar**: Quick access to main functions
- **Key Metrics**: Total, Pending, and Approved change counts
- **Risk Distribution**: Visual pie/donut chart
- **Filter Controls**: Filter change list and charts
- **Export Options**: CSV export for dashboard data

---

### 3. Change Request List View

```
┌─────────────────────────────────────────────────────────────┐
│  Dashboard  |  Create Change  |  [Username]  |  Logout     │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  SEARCH: [________________] [Search]                  │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  ID  │ Title           │ Type   │ Window    │ Risk   │  │
│  │      │                 │        │           │ Level  │  │
│  ├───────────────────────────────────────────────────────┤  │
│  │  101 │ Database Update │ Normal │ Business  │ Medium │  │
│  │      │                 │        │ Hours     │        │  │
│  │      │                 │        │           │        │  │
│  │      │ [View] [Edit] [Export]                         │  │
│  ├───────────────────────────────────────────────────────┤  │
│  │  102 │ Server Patch    │ Stand- │ Mainte-   │ Low    │  │
│  │      │                 │ ard    │ nance     │        │  │
│  │      │                 │        │ Window    │        │  │
│  │      │ [View] [Edit] [Export]                         │  │
│  ├───────────────────────────────────────────────────────┤  │
│  │  103 │ Emergency Fix   │ Emer-  │ Emergency │ High   │  │
│  │      │                 │ gency  │           │        │  │
│  │      │                 │        │           │        │  │
│  │      │ [View] [Edit] [Export]                         │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  Page 1 of 5  [<<] [<] 1 2 3 4 5 [>] [>>]            │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**List View Features:**
- **Search Box**: Filter changes by keywords
- **Table Columns**: ID, Title, Type, Window, Risk Level, Status, Owner
- **Action Buttons**: View, Edit (if pending), Export
- **Pagination**: Navigate through multiple pages of results

---

### 4. Create Change Request Form

```
┌─────────────────────────────────────────────────────────────┐
│                    CREATE CHANGE REQUEST                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  BASIC INFORMATION                                    │  │
│  │                                                       │  │
│  │  Title:        [______________________________]       │  │
│  │                                                       │  │
│  │  Description: [______________________________]       │  │
│  │               [______________________________]       │  │
│  │                                                       │  │
│  │  Change Type:  [Standard ▼]                           │  │
│  │                                                       │  │
│  │  Change Window: [Business Hours ▼]                    │  │
│  │                                                       │  │
│  │  Start Time:   [MM/DD/YYYY HH:MM]                     │  │
│  │                                                       │  │
│  │  End Time:     [MM/DD/YYYY HH:MM]                     │  │
│  │                                                       │  │
│  │  Business Owner: [______________________________]     │  │
│  │                                                       │  │
│  │  Technical Owner: [______________________________]    │  │
│  │                                                       │  │
│  │  [ ] Critical CI    [ ] Rollback Plan Available       │  │
│  │                                                       │  │
│  │  Impacted Services: [______________________________]  │  │
│  │                                                       │  │
│  │  Dependencies:      [______________________________]  │  │
│  │                                                       │  │
│  │  [      CANCEL      ]  [      SUBMIT      ]          │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Form Features:**
- **Required Fields**: Marked with asterisks (*)
- **Dropdown Options**: Change type and window selection
- **Date/Time Pickers**: For scheduling changes
- **Optional Fields**: Critical CI, rollback plan, impacted services
- **Action Buttons**: Cancel or Submit the change request

---

### 5. View Change Request Modal

```
┌─────────────────────────────────────────────────────────────┐
│                    CHANGE REQUEST DETAILS                   │
├─────────────────────────────────────────────────────────────┤
│  [X]                                                      │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  CHANGE INFORMATION                                   │  │
│  │                                                       │  │
│  │  Title:        Database Update                        │  │
│  │                                                       │  │
│  │  Description: Update database schema for new feature  │  │
│  │                                                       │  │
│  │  Change Type:  Normal                                 │  │
│  │                                                       │  │
│  │  Change Window: Business Hours                        │  │
│  │                                                       │  │
│  │  Start Time:   03/30/2026 10:00 AM                    │  │
│  │                                                       │  │
│  │  End Time:     03/30/2026 12:00 PM                    │  │
│  │                                                       │  │
│  │  Business Owner: John Smith                           │  │
│  │                                                       │  │
│  │  Technical Owner: Jane Doe                            │  │
│  │                                                       │  │
│  │  Status:       Pending                                │  │
│  │                                                       │  │
│  │  Risk Level:   Medium    ⚠️                           │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  AI RISK ASSESSMENT                                   │  │
│  │                                                       │  │
│  │  Risk Level:     Medium                               │  │
│  │                                                       │  │
│  │  Confidence:     85%                                  │  │
│  │                                                       │  │
│  │  Contributing Factors:                                │  │
│  │  • Database schema changes                            │  │
│  │  • Business hours window                              │  │
│  │  • Multiple service dependencies                      │  │
│  │                                                       │  │
│  │  Recommendations:                                     │  │
│  │  • Additional testing required                        │  │
│  │  • Notify application teams                           │  │
│  │  • Prepare rollback plan                              │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  MISSING INFORMATION                                  │  │
│  │                                                       │  │
│  │  ⚠️ Critical CI not specified                          │  │
│  │  ⚠️ Rollback plan not confirmed                        │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  [      CLOSE      ]  [      EDIT      ]             │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Modal Features:**
- **Close Button**: [X] to close modal
- **Change Information**: Complete change details
- **AI Risk Assessment**: AI-generated analysis and recommendations
- **Missing Information**: Flags for incomplete data
- **Action Buttons**: Close or Edit the change request

---

### 6. AI Risk Assessment Details

```
┌─────────────────────────────────────────────────────────────┐
│                      AI RISK ANALYSIS                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  RISK CLASSIFICATION                                  │  │
│  │                                                       │  │
│  │  Overall Risk:    MEDIUM    🟠                        │  │
│  │                                                       │  │
│  │  Confidence Score: 85%                                │  │
│  │                                                       │  │
│  │  Analysis Date:    03/27/2026 10:30 AM                │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  RISK CATEGORIES                                      │  │
│  │                                                       │  │
│  │  🛠️  Technical Risk:  Medium                          │  │
│  │      • Database schema modification                    │  │
│  │      • Multiple service dependencies                   │  │
│  │                                                       │  │
│  │  💼  Business Risk:   Low                             │  │
│  │      • Business hours window                           │  │
│  │      • Standard change procedure                       │  │
│  │                                                       │  │
│  │  ⏰  Operational Risk: Medium                          │  │
│  │      • Requires coordination                           │  │
│  │      • Testing needed                                  │  │
│  │                                                       │  │
│  │  🔒  Security Risk:   Low                             │  │
│  │      • No security-sensitive changes                   │  │
│  │      • Standard access controls                        │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  MITIGATION RECOMMENDATIONS                           │  │
│  │                                                       │  │
│  │  ✅  Required Actions:                                 │  │
│  │      • Perform additional testing                     │  │
│  │      • Notify dependent service teams                 │  │
│  │      • Prepare rollback procedures                    │  │
│  │                                                       │  │
│  │  ⚠️  Considerations:                                   │  │
│  │      • Monitor during implementation                  │  │
│  │      • Have support team available                    │  │
│  │      • Document any issues encountered                │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**AI Analysis Features:**
- **Risk Classification**: Overall risk level with confidence score
- **Risk Categories**: Detailed breakdown by category
- **Mitigation Recommendations**: Specific actions and considerations
- **Visual Indicators**: Color-coded risk levels and icons

---

### 7. PDF Report Preview

```
┌─────────────────────────────────────────────────────────────┐
│                    CHANGE REQUEST REPORT                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  CHANGE REQUEST SUMMARY                               │  │
│  │                                                       │  │
│  │  Change ID:      CR-2026-00101                        │  │
│  │  Title:          Database Update                      │  │
│  │  Created:        03/27/2026 09:15 AM                  │  │
│  │  Created By:     user@example.com                     │  │
│  │  Status:         Pending                              │  │
│  │  Risk Level:     Medium                               │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  DETAILED DESCRIPTION                                 │  │
│  │                                                       │  │
│  │  Purpose: Update database schema to support new       │  │
│  │           feature requirements for customer          │  │
│  │           management system.                         │  │
│  │                                                       │  │
│  │  Scope:  Modify user table to add new fields for      │  │
│  │          customer preferences and update related     │  │
│  │          stored procedures.                          │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  AI RISK ASSESSMENT                                   │  │
│  │                                                       │  │
│  │  Risk Level:     Medium                               │  │
│  │  Confidence:     85%                                  │  │
│  │                                                       │  │
│  │  Contributing Factors:                                │  │
│  │  • Database schema changes                            │  │
│  │  • Business hours window                              │  │
│  │  • Multiple service dependencies                      │  │
│  │                                                       │  │
│  │  Recommendations:                                     │  │
│  │  • Additional testing required                        │  │
│  │  • Notify application teams                           │  │
│  │  • Prepare rollback plan                              │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │  APPROVAL WORKFLOW                                    │  │
│  │                                                       │  │
│  │  Created:       user@example.com          03/27/2026 │  │
│  │  Reviewer:      manager@example.com       Pending    │  │
│  │  Approver:       director@example.com      Pending    │  │
│  │                                                       │  │
│  │  Next Action:   Manager review required              │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**PDF Report Features:**
- **Professional Layout**: Landscape orientation with clean formatting
- **Complete Information**: All change request details included
- **AI Analysis**: Full AI risk assessment and recommendations
- **Approval History**: Complete workflow tracking
- **Print Ready**: High-quality output for printing

---

## Quick Navigation Reference

| Screen | How to Access | Key Functions |
|--------|---------------|---------------|
| **Login** | Initial page load | User authentication |
| **Dashboard** | After login or click "Dashboard" | Overview, metrics, charts |
| **Create Change** | Click "Create Change" | New change request form |
| **Change List** | Dashboard or navigation | View all changes, search, filter |
| **View/Edit** | Click action buttons | Detailed view, edit pending changes |
| **Reports** | Click "Export" buttons | PDF reports, CSV exports |

## Keyboard Shortcuts

- **Enter**: Submit forms or execute searches
- **Esc**: Close modals or cancel actions
- **Ctrl+F**: Browser search within page
- **F5**: Refresh page
- **Ctrl+P**: Print current page

## Troubleshooting Quick Tips

| Issue | Solution |
|-------|----------|
| **Can't login** | Check username/password, ensure Caps Lock off |
| **Page won't load** | Clear cache, check internet connection |
| **Can't edit change** | Verify status is "Pending" and you're the creator |
| **AI analysis missing** | Ensure all required fields are filled |
| **Charts not showing** | Check filter settings, refresh page |

---

**For detailed instructions, refer to the complete End User Manual.**

**Support Contact**: support@changemanagement.com