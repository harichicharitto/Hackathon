#!/usr/bin/env python3
"""
Test script to verify the API response structure for change requests.
"""

import requests
import json

def test_api_response():
    try:
        # Login to get token
        login_response = requests.post('http://localhost:5000/api/auth/login', 
            json={'username': 'admin', 'password': 'admin123'})
        
        if not login_response.ok:
            print(f"Login failed: {login_response.status_code}")
            return
        
        token = login_response.json()['access_token']
        headers = {'Authorization': f'Bearer {token}'}
        
        # Get changes
        changes_response = requests.get('http://localhost:5000/api/changes/?page=1&per_page=1', headers=headers)
        
        if not changes_response.ok:
            print(f"Failed to get changes: {changes_response.status_code}")
            return
        
        changes_data = changes_response.json()
        
        if 'changes' not in changes_data or not changes_data['changes']:
            print("No changes found in response")
            return
        
        change = changes_data['changes'][0]
        
        print('=== Change Data Structure ===')
        print(f'Change ID: {change.get("id")}')
        print(f'Title: {change.get("title")}')
        print(f'Risk Level: {change.get("risk_level")}')
        print(f'Risk Scores: {len(change.get("risk_scores", []))} records')
        
        if change.get('risk_scores'):
            risk_score = change['risk_scores'][0]
            print(f'\n=== Risk Score Data ===')
            print(f'Risk Reasoning: {bool(risk_score.get("risk_reasoning"))}')
            print(f'Risk Factors: {bool(risk_score.get("risk_factors"))}')
            print(f'Recommendation: {bool(risk_score.get("recommendation"))}')
            
            if risk_score.get('risk_reasoning'):
                print(f'\n=== Risk Reasoning Content ===')
                content = risk_score['risk_reasoning']
                print(repr(content[:200] + '...' if len(content) > 200 else content))
            
            if risk_score.get('risk_factors'):
                print(f'\n=== Risk Factors Content ===')
                print(repr(risk_score['risk_factors']))
            
            if risk_score.get('recommendation'):
                print(f'\n=== Recommendation Content ===')
                print(repr(risk_score['recommendation']))
        
        # Save full response for inspection
        with open('api_response_sample.json', 'w') as f:
            json.dump(changes_data, f, indent=2, default=str)
        print(f"\nFull response saved to api_response_sample.json")
        
    except Exception as e:
        print(f'Error: {e}')

if __name__ == '__main__':
    test_api_response()