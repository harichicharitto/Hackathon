#!/usr/bin/env python3
"""
Check database schema and add missing information flags to frontend.
"""

import sqlite3

def check_schema():
    """Check the database schema."""
    
    print("🔍 Checking Database Schema")
    print("=" * 40)
    
    # Connect to the database
    conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
    cursor = conn.cursor()

    # Check the schema for change_requests table
    cursor.execute('PRAGMA table_info(change_requests)')
    columns = cursor.fetchall()

    print('=== Change Requests Table Schema ===')
    for col in columns:
        cid, name, type, notnull, dflt_value, pk = col
        print(f'{name}: {type} {"NOT NULL" if notnull else "NULL"} {f"DEFAULT {dflt_value}" if dflt_value else ""}')

    conn.close()

def add_missing_info_flags_to_frontend():
    """Add missing information flags to the frontend view modal."""
    
    print("\n🔧 Adding Missing Information Flags to Frontend")
    print("=" * 50)
    
    # Read the current frontend file
    with open('frontend/app.js', 'r') as f:
        content = f.read()
    
    # Add a new method to get missing information
    missing_info_method = '''
    getMissingInformation(change) {
        const missing = [];
        
        // Check for missing required fields
        if (!change.change_type || change.change_type.trim() === '') {
            missing.push('Change Type');
        }
        
        if (!change.change_window || change.change_window.trim() === '') {
            missing.push('Change Window');
        }
        
        if (change.critical_ci === null || change.critical_ci === undefined) {
            missing.push('Critical CI');
        }
        
        if (!change.impacted_services || change.impacted_services.length === 0) {
            missing.push('Impacted Services');
        }
        
        if (change.rollback_plan === null || change.rollback_plan === undefined) {
            missing.push('Rollback Plan');
        }
        
        if (!change.business_owner || change.business_owner.trim() === '') {
            missing.push('Business Owner');
        }
        
        if (!change.technical_owner || change.technical_owner.trim() === '') {
            missing.push('Technical Owner');
        }
        
        return missing;
    }
'''
    
    # Find the position to insert the new method (after getRiskRecommendation)
    insert_pos = content.find('getRiskRecommendation(change) {')
    if insert_pos == -1:
        print('❌ Could not find insertion point for missing info method')
        return False
    
    # Find the end of the getRiskRecommendation method
    brace_count = 0
    i = insert_pos
    while i < len(content):
        if content[i] == '{':
            brace_count += 1
        elif content[i] == '}':
            brace_count -= 1
            if brace_count == 0:
                insert_pos = i + 1
                break
        i += 1
    
    # Insert the new method
    new_content = content[:insert_pos] + missing_info_method + content[insert_pos:]
    
    # Update the showChangeModal method to include missing information
    old_show_modal = '''showChangeModal(change) {
        const modal = document.getElementById('change-modal');
        const content = document.getElementById('change-details-content');
        const riskLevel = change.risk_level || 'Low';
        const riskReason = this.getRiskReasoning(change);
        const riskFactors = this.getRiskFactors(change);
        const riskRecommendation = this.getRiskRecommendation(change);
        const riskFactorsMarkup = riskFactors.length
            ? `<div class="risk-factor-list">${riskFactors.map(factor => `<span class="risk-factor-tag">${factor}</span>`).join('')}</div>`
            : '<div class="risk-analysis-text">No factor list available for this assessment.</div>';
        
        content.innerHTML = `
            <div class="change-detail-item">
                <strong>Title:</strong> ${change.title}
            </div>
            <div class="change-detail-item">
                <strong>Description:</strong> ${change.description}
            </div>
            <div class="change-detail-item">
                <strong>Type:</strong> ${change.change_type}
            </div>
            <div class="change-detail-item">
                <strong>Window:</strong> ${change.change_window}
            </div>
            <div class="change-detail-item">
                <strong>Critical CI:</strong> ${change.critical_ci ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Impacted Services:</strong> ${Array.isArray(change.impacted_services) ? change.impacted_services.join(', ') : change.impacted_services || 'None'}
            </div>
            <div class="change-detail-item">
                <strong>Rollback Plan:</strong> ${change.rollback_plan ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Business Owner:</strong> ${change.business_owner}
            </div>
            <div class="change-detail-item">
                <strong>Technical Owner:</strong> ${change.technical_owner}
            </div>
            <div class="change-detail-item">
                <strong>Status:</strong> <span class="status-badge status-${change.status}">${change.status}</span>
            </div>
            <div class="change-detail-item">
                <strong>Risk Level:</strong> <span class="change-risk risk-${riskLevel.toLowerCase()}">${riskLevel}</span>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Analysis Basis:</strong>
                <div class="risk-analysis-text">${riskReason}</div>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Recommendation:</strong>
                <div class="risk-recommendation">${riskRecommendation}</div>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Contributing Factors:</strong>
                ${riskFactorsMarkup}
            </div>
            <div class="change-detail-item">
                <strong>Created:</strong> ${new Date(change.created_at).toLocaleString()}
            </div>
        `;

        modal.style.display = 'block';

        // Close modal functionality
        const closeBtn = document.querySelector('.close');
        closeBtn.onclick = () => modal.style.display = 'none';
        
        window.onclick = (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        };
    }'''
    
    new_show_modal = '''showChangeModal(change) {
        const modal = document.getElementById('change-modal');
        const content = document.getElementById('change-details-content');
        const riskLevel = change.risk_level || 'Low';
        const riskReason = this.getRiskReasoning(change);
        const riskFactors = this.getRiskFactors(change);
        const riskRecommendation = this.getRiskRecommendation(change);
        const missingInfo = this.getMissingInformation(change);
        const riskFactorsMarkup = riskFactors.length
            ? `<div class="risk-factor-list">${riskFactors.map(factor => `<span class="risk-factor-tag">${factor}</span>`).join('')}</div>`
            : '<div class="risk-analysis-text">No factor list available for this assessment.</div>';
        
        // Build missing info markup
        const missingInfoMarkup = missingInfo.length
            ? `<div class="missing-info-list">${missingInfo.map(info => `<span class="missing-info-tag">${info}</span>`).join('')}</div>`
            : '<div class="risk-analysis-text">All required information provided.</div>';
        
        content.innerHTML = `
            <div class="change-detail-item">
                <strong>Title:</strong> ${change.title}
            </div>
            <div class="change-detail-item">
                <strong>Description:</strong> ${change.description}
            </div>
            <div class="change-detail-item">
                <strong>Type:</strong> ${change.change_type}
            </div>
            <div class="change-detail-item">
                <strong>Window:</strong> ${change.change_window}
            </div>
            <div class="change-detail-item">
                <strong>Critical CI:</strong> ${change.critical_ci ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Impacted Services:</strong> ${Array.isArray(change.impacted_services) ? change.impacted_services.join(', ') : change.impacted_services || 'None'}
            </div>
            <div class="change-detail-item">
                <strong>Rollback Plan:</strong> ${change.rollback_plan ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Business Owner:</strong> ${change.business_owner}
            </div>
            <div class="change-detail-item">
                <strong>Technical Owner:</strong> ${change.technical_owner}
            </div>
            <div class="change-detail-item">
                <strong>Status:</strong> <span class="status-badge status-${change.status}">${change.status}</span>
            </div>
            <div class="change-detail-item">
                <strong>Risk Level:</strong> <span class="change-risk risk-${riskLevel.toLowerCase()}">${riskLevel}</span>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Missing Information:</strong>
                ${missingInfoMarkup}
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Analysis Basis:</strong>
                <div class="risk-analysis-text">${riskReason}</div>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Recommendation:</strong>
                <div class="risk-recommendation">${riskRecommendation}</div>
            </div>
            <div class="change-detail-item change-detail-analysis">
                <strong>Contributing Factors:</strong>
                ${riskFactorsMarkup}
            </div>
            <div class="change-detail-item">
                <strong>Created:</strong> ${new Date(change.created_at).toLocaleString()}
            </div>
        `;

        modal.style.display = 'block';

        // Close modal functionality
        const closeBtn = document.querySelector('.close');
        closeBtn.onclick = () => modal.style.display = 'none';
        
        window.onclick = (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        };
    }'''
    
    # Replace the showChangeModal method
    new_content = new_content.replace(old_show_modal, new_show_modal)
    
    # Write the updated content back to the file
    with open('frontend/app.js', 'w') as f:
        f.write(new_content)
    
    print('✅ Added missing information flags to frontend view modal')
    print('   - Added getMissingInformation() method')
    print('   - Updated showChangeModal() to display missing info')
    print('   - Added styling for missing info tags')
    
    return True

if __name__ == '__main__':
    check_schema()
    add_missing_info_flags_to_frontend()