#!/usr/bin/env python3
"""
Test script to verify the dashboard Risk level filter fix.
"""

import sys
import os

# Add the backend directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

try:
    from backend.services.dashboard_service import DashboardService
    from backend.app import create_app
    from backend.models import db

    app = create_app()
    with app.app_context():
        print("Testing dashboard filters...")
        
        # Test without filters (should work normally)
        print("\n1. Testing without filters:")
        result = DashboardService.get_dashboard_summary()
        print(f"   Total changes: {result.get('summary', {}).get('total_changes', 0)}")
        print(f"   High risk changes: {result.get('risk_distribution', {}).get('High', 0)}")
        print(f"   Medium risk changes: {result.get('risk_distribution', {}).get('Medium', 0)}")
        print(f"   Low risk changes: {result.get('risk_distribution', {}).get('Low', 0)}")
        
        # Test with risk level filter (should be corrected)
        print("\n2. Testing with High risk filter:")
        filters = {'risk_level': 'High'}
        result = DashboardService.get_dashboard_summary(filters=filters)
        print(f"   Total changes: {result.get('summary', {}).get('total_changes', 0)}")
        print(f"   High risk changes: {result.get('risk_distribution', {}).get('High', 0)}")
        print(f"   Status distribution: {result.get('status_distribution', {})}")
        
        # Test with Medium risk filter
        print("\n3. Testing with Medium risk filter:")
        filters = {'risk_level': 'Medium'}
        result = DashboardService.get_dashboard_summary(filters=filters)
        print(f"   Total changes: {result.get('summary', {}).get('total_changes', 0)}")
        print(f"   Medium risk changes: {result.get('risk_distribution', {}).get('Medium', 0)}")
        
        # Test with Low risk filter
        print("\n4. Testing with Low risk filter:")
        filters = {'risk_level': 'Low'}
        result = DashboardService.get_dashboard_summary(filters=filters)
        print(f"   Total changes: {result.get('summary', {}).get('total_changes', 0)}")
        print(f"   Low risk changes: {result.get('risk_distribution', {}).get('Low', 0)}")
        
        print("\nTest completed successfully!")

except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()