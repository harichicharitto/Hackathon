#!/usr/bin/env python3
"""
Final verification script to test complete frontend functionality including factor extraction.
"""

import requests
import re

def test_complete_functionality():
    """Test the complete frontend functionality with factor extraction."""
    
    print("🔍 Testing Complete Frontend Functionality")
    print("=" * 60)
    
    # Login to get token
    login_response = requests.post('http://localhost:5000/api/auth/login', 
        json={'username': 'admin', 'password': 'admin123'})
    
    if not login_response.ok:
        print("❌ Login failed")
        return False
    
    token = login_response.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    
    # Get Change 100
    change_response = requests.get('http://localhost:5000/api/changes/100', headers=headers)
    
    if not change_response.ok:
        print("❌ Failed to get change")
        return False
    
    change_data = change_response.json()
    
    print(f"📋 Change: {change_data.get('title')}")
    print(f"   Change ID: {change_data.get('id')}")
    print(f"   Risk Level: {change_data.get('risk_level')}")
    
    if not change_data.get('risk_scores'):
        print("❌ No risk scores found")
        return False
    
    risk_score = change_data['risk_scores'][0]
    full_reasoning = risk_score.get('risk_reasoning', '')
    
    print(f"   Risk Reasoning Length: {len(full_reasoning)} characters")
    print(f"   Has RECOMMENDATION marker: {'✅' if 'RECOMMENDATION:' in full_reasoning else '❌'}")
    
    # Simulate complete frontend parsing logic
    def getRiskReasoning(change):
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            if latestRisk.get('risk_reasoning'):
                reasoning = latestRisk['risk_reasoning']
                recommendationMatch = re.search(r'Recommendation:\s*(.+)', reasoning, re.IGNORECASE)
                if recommendationMatch:
                    return re.sub(r'Recommendation:\s*.+', '', reasoning, flags=re.IGNORECASE).strip()
                return reasoning
        return 'No model analysis available for this change.'

    def getRiskRecommendation(change):
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            if latestRisk.get('recommendation'):
                fullText = latestRisk['recommendation']
                recommendationMatch = re.search(r'RECOMMENDATION:\s*(.+)', fullText, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
                return fullText
            elif latestRisk.get('risk_reasoning'):
                reasoning = latestRisk['risk_reasoning']
                recommendationMatch = re.search(r'Recommendation:\s*(.+)', reasoning, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
        return 'No recommendation available for this assessment.'

    def extractFactorsFromReasoning(reasoning):
        """Extract contributing factors from the reasoning text"""
        factors = []
        
        # Extract factors based on common phrases
        if 'change type is' in reasoning:
            match = re.search(r'change type is (\w+)', reasoning, re.IGNORECASE)
            if match:
                factors.append(f'Change Type: {match.group(1)}')
        
        if 'maintenance window' in reasoning:
            factors.append('Scheduled during maintenance window')
        
        if 'critical infrastructure' in reasoning:
            factors.append('Involves critical infrastructure')
        elif 'does not involve critical infrastructure' in reasoning:
            factors.append('No critical infrastructure involved')
        
        if 'impacts' in reasoning or 'impact' in reasoning:
            match = re.search(r'impacts? (\d+) systems?', reasoning, re.IGNORECASE)
            if match:
                factors.append(f'Impacts {match.group(1)} systems')
            else:
                factors.append('Has system impact')
        
        if 'rollback plan' in reasoning:
            if 'rollback plan is available' in reasoning:
                factors.append('Rollback plan available')
            elif 'no rollback plan' in reasoning:
                factors.append('No rollback plan available')
        
        # Look for specific system names
        system_names = re.findall(r'\b(?:VPN|Remote Desktop|File Sharing|Database|Application|Backend|Reporting|System|Service)\b', reasoning, re.IGNORECASE)
        if system_names:
            unique_systems = list(set([s.lower() for s in system_names]))
            if unique_systems:
                factors.append(f'Affected Systems: {", ".join(unique_systems)}')
        
        return factors

    def getRiskFactors(change):
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            if latestRisk.get('risk_factors'):
                try:
                    if isinstance(latestRisk['risk_factors'], str):
                        import json
                        parsed = json.loads(latestRisk['risk_factors'])
                        if isinstance(parsed, list):
                            return parsed
                    elif isinstance(latestRisk['risk_factors'], list):
                        return latestRisk['risk_factors']
                except:
                    pass
            
            # If no risk_factors field, extract from reasoning
            if latestRisk.get('risk_reasoning'):
                factors = extractFactorsFromReasoning(latestRisk['risk_reasoning'])
                if factors:
                    return factors
        
        return []

    # Test complete parsing
    reasoning = getRiskReasoning(change_data)
    recommendation = getRiskRecommendation(change_data)
    factors = getRiskFactors(change_data)
    
    print(f"\n🎯 Complete Frontend Parsing Results:")
    print(f"   Analysis Basis: {'✅' if reasoning and reasoning != 'No model analysis available for this change.' else '❌'}")
    print(f"   Recommendation: {'✅' if recommendation and recommendation != 'No recommendation available for this assessment.' else '❌'}")
    print(f"   Contributing Factors: {'✅' if factors else '❌'}")
    
    if reasoning and reasoning != 'No model analysis available for this change.':
        print(f"\n📝 Analysis Basis Content:")
        print(f"   Preview: {repr(reasoning[:100] + '...' if len(reasoning) > 100 else reasoning)}")
        print(f"   Length: {len(reasoning)} characters")
    
    if recommendation and recommendation != 'No recommendation available for this assessment.':
        print(f"\n💡 Recommendation Content:")
        print(f"   Preview: {repr(recommendation[:100] + '...' if len(recommendation) > 100 else recommendation)}")
        print(f"   Length: {len(recommendation)} characters")
    
    if factors:
        print(f"\n🔧 Contributing Factors:")
        for i, factor in enumerate(factors, 1):
            print(f"   {i}. {factor}")
        print(f"   Total Factors: {len(factors)}")
    
    # Final verification
    if reasoning and recommendation and factors:
        print(f"\n🎉 SUCCESS: All three sections populated!")
        print(f"   ✅ Analysis Basis: {len(reasoning)} chars")
        print(f"   ✅ Recommendation: {len(recommendation)} chars")
        print(f"   ✅ Contributing Factors: {len(factors)} factors")
        print(f"\n📋 View Modal Sections:")
        print(f"   1. Analysis Basis: Shows reasoning (separated from recommendation)")
        print(f"   2. Recommendation: Shows specific recommendation")
        print(f"   3. Contributing Factors: Shows extracted factors from reasoning")
        return True
    else:
        print(f"\n❌ FAILED: Missing content in one or more sections")
        return False

if __name__ == '__main__':
    test_complete_functionality()