#!/usr/bin/env python3
"""
Test the API to see how many records are returned
"""

import requests
import json

def test_api():
    try:
        # First get a token
        login_response = requests.post('http://localhost:5000/api/auth/login', 
            json={'username': 'admin', 'password': 'admin123'})
        
        if login_response.status_code == 200:
            token = login_response.json()['access_token']
            print(f'Token obtained successfully')
            
            # Now get changes
            headers = {'Authorization': f'Bearer {token}'}
            changes_response = requests.get('http://localhost:5000/api/changes/', headers=headers)
            
            if changes_response.status_code == 200:
                data = changes_response.json()
                print(f'Total records in database: {data.get("total", 0)}')
                print(f'Per page: {data.get("per_page", 0)}')
                print(f'Current page: {data.get("page", 0)}')
                print(f'Changes returned in this request: {len(data.get("changes", []))}')
                
                if data.get("changes"):
                    print(f'First change ID: {data["changes"][0].get("id", "N/A")}')
                    print(f'Last change ID: {data["changes"][-1].get("id", "N/A")}')
                
                # Test with no pagination
                changes_response_all = requests.get('http://localhost:5000/api/changes/?per_page=100', headers=headers)
                if changes_response_all.status_code == 200:
                    data_all = changes_response_all.json()
                    print(f'With per_page=100: {len(data_all.get("changes", []))} records returned')
                else:
                    print(f'Error with per_page=100: {changes_response_all.status_code}')
                    
            else:
                print(f'Error getting changes: {changes_response.status_code}')
                print(changes_response.text)
        else:
            print(f'Error logging in: {login_response.status_code}')
            print(login_response.text)
            
    except Exception as e:
        print(f'Error: {e}')

if __name__ == "__main__":
    test_api()