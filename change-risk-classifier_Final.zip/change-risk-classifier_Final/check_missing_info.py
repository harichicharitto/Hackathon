#!/usr/bin/env python3
"""
Check for missing information in change requests to understand what flags we need to add.
"""

import sqlite3

def check_missing_info():
    """Check for missing information in change requests."""
    
    print("🔍 Checking for Missing Information in Change Requests")
    print("=" * 60)
    
    # Connect to the database
    conn = sqlite3.connect('backend/instance/change_risk_classifier.db')
    cursor = conn.cursor()

    # Check what missing information we can detect
    cursor.execute('''
        SELECT id, title, change_type, change_window, critical_ci, impacted_services, rollback_plan, business_owner, technical_owner
        FROM change_requests 
        WHERE status = 'pending'
        LIMIT 10
    ''')
    changes = cursor.fetchall()

    print('=== Sample Changes for Missing Info Check ===')
    for change in changes:
        change_id, title, change_type, change_window, critical_ci, impacted_services, rollback_plan, business_owner, technical_owner = change
        
        print(f'\nChange {change_id}: {title}')
        print(f'  Change Type: {change_type}')
        print(f'  Change Window: {change_window}')
        print(f'  Critical CI: {critical_ci}')
        print(f'  Impacted Services: {impacted_services}')
        print(f'  Rollback Plan: {rollback_plan}')
        print(f'  Business Owner: {business_owner}')
        print(f'  Technical Owner: {technical_owner}')
        
        # Check for missing info
        missing = []
        if not change_type:
            missing.append('Change Type')
        if not change_window:
            missing.append('Change Window')
        if critical_ci is None:
            missing.append('Critical CI')
        if not impacted_services:
            missing.append('Impacted Services')
        if rollback_plan is None:
            missing.append('Rollback Plan')
        if not business_owner:
            missing.append('Business Owner')
        if not technical_owner:
            missing.append('Technical Owner')
        
        if missing:
            print(f'  ❌ Missing: {", ".join(missing)}')
        else:
            print(f'  ✅ All required fields present')

    # Check overall statistics
    cursor.execute('''
        SELECT 
            COUNT(*) as total_pending,
            SUM(CASE WHEN change_type IS NULL OR change_type = "" THEN 1 ELSE 0 END) as missing_type,
            SUM(CASE WHEN change_window IS NULL OR change_window = "" THEN 1 ELSE 0 END) as missing_window,
            SUM(CASE WHEN critical_ci IS NULL THEN 1 ELSE 0 END) as missing_ci,
            SUM(CASE WHEN impacted_services IS NULL OR impacted_services = "" THEN 1 ELSE 0 END) as missing_services,
            SUM(CASE WHEN rollback_plan IS NULL THEN 1 ELSE 0 END) as missing_rollback,
            SUM(CASE WHEN business_owner IS NULL OR business_owner = "" THEN 1 ELSE 0 END) as missing_business_owner,
            SUM(CASE WHEN technical_owner IS NULL OR technical_owner = "" THEN 1 ELSE 0 END) as missing_tech_owner
        FROM change_requests 
        WHERE status = 'pending'
    ''')
    
    stats = cursor.fetchone()
    if stats:
        total_pending, missing_type, missing_window, missing_ci, missing_services, missing_rollback, missing_business_owner, missing_tech_owner = stats
        
        print(f'\n📊 Missing Information Statistics (Pending Changes):')
        print(f'   Total Pending Changes: {total_pending}')
        print(f'   Missing Change Type: {missing_type}')
        print(f'   Missing Change Window: {missing_window}')
        print(f'   Missing Critical CI: {missing_ci}')
        print(f'   Missing Impacted Services: {missing_services}')
        print(f'   Missing Rollback Plan: {missing_rollback}')
        print(f'   Missing Business Owner: {missing_business_owner}')
        print(f'   Missing Technical Owner: {missing_tech_owner}')
        
        total_missing_fields = missing_type + missing_window + missing_ci + missing_services + missing_rollback + missing_business_owner + missing_tech_owner
        print(f'   Total Missing Fields: {total_missing_fields}')

    conn.close()

if __name__ == '__main__':
    check_missing_info()