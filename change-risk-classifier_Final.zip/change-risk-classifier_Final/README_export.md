# Database Export Tool

This script exports data from the Change Risk Classifier SQLite database to various formats for analysis and reporting.

## Features

- Exports all tables from the SQLite database
- Supports CSV and JSON formats
- Creates timestamped export directories
- Generates a summary report
- Handles datetime fields properly
- User-friendly command-line interface

## Usage

### Basic Usage

```bash
python export_database.py
```

### Command Line Options

The script will prompt you to select an export format:
1. **CSV only** - Exports data to CSV files
2. **JSON only** - Exports data to JSON files  
3. **Both CSV and JSON** (default) - Exports to both formats

## Output

The script creates a timestamped directory (e.g., `database_export_20260326_200219`) containing:

- `users.csv/json` - User information
- `rules.csv/json` - Business rules for risk classification
- `audit_logs.csv/json` - Audit trail data
- `change_requests.csv/json` - Change request data
- `risk_scores.csv/json` - Risk assessment results
- `export_summary.txt` - Summary of the export operation

## Database Structure

The database contains the following tables:

### users
User account information including usernames, emails, roles, and authentication data.

### rules
Business rules used for automated risk classification with conditions and actions.

### audit_logs
Audit trail of user activities, system events, and security-related actions.

### change_requests
Change request data including descriptions, timing, impact assessments, and approval status.

### risk_scores
Risk assessment results including scores, classifications, and reasoning.

## Requirements

- Python 3.x
- Standard library modules: `sqlite3`, `json`, `csv`, `os`, `datetime`, `pathlib`

## Example Output

```
🚀 Change Risk Classifier Database Export Tool
==================================================
Select export format:
1. CSV only
2. JSON only
3. Both CSV and JSON (default)

Enter your choice (1-3) [default: 3]: 1
📁 Creating export directory: database_export_20260326_200219
📊 Found 5 tables: users, rules, audit_logs, change_requests, risk_scores

🔄 Exporting table: users
✓ Exported users to database_export_20260326_200219\users.csv

...

✅ Export completed successfully!
📁 Export directory: database_export_20260326_200219
📄 Summary file: database_export_20260326_200219\export_summary.txt

📋 Exported files:
   • users.csv
   • rules.csv
   • audit_logs.csv
   • change_requests.csv
   • risk_scores.csv

🎉 Database export completed successfully!
📁 Check the 'database_export_*' folder for your files.
```

## Notes

- The script must be run from the project root directory where the `backend/instance/change_risk_classifier.db` file is located
- Export directories are created with timestamps to avoid conflicts
- CSV files use UTF-8 encoding for proper character support
- JSON exports include proper formatting and handle datetime objects