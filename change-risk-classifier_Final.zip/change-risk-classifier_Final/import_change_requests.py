#!/usr/bin/env python3
"""
Import Change Requests Script

This script deletes existing rows from the change_requests table
and imports data from a CSV file.
"""

import sqlite3
import csv
import os
from datetime import datetime

def connect_to_database(db_path):
    """Connect to the SQLite database."""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row  # This enables column access by name
        return conn
    except sqlite3.Error as e:
        print(f"Error connecting to database: {e}")
        return None

def delete_existing_data(conn):
    """Delete all existing data from change_requests table."""
    try:
        cursor = conn.cursor()
        
        # Get count before deletion
        cursor.execute("SELECT COUNT(*) FROM change_requests")
        count_before = cursor.fetchone()[0]
        
        print(f"📊 Found {count_before} existing records in change_requests table")
        
        # Delete all records
        cursor.execute("DELETE FROM change_requests")
        conn.commit()
        
        print(f"🗑️  Deleted {count_before} existing records")
        return count_before
        
    except sqlite3.Error as e:
        print(f"❌ Error deleting existing data: {e}")
        return 0

def import_csv_data(conn, csv_path):
    """Import data from CSV file into change_requests table."""
    try:
        cursor = conn.cursor()
        
        # Read CSV file
        with open(csv_path, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            fieldnames = reader.fieldnames
            
            # Prepare INSERT statement
            placeholders = ', '.join(['?' for _ in fieldnames])
            columns = ', '.join(fieldnames)
            insert_query = f"INSERT INTO change_requests ({columns}) VALUES ({placeholders})"
            
            imported_count = 0
            for row in reader:
                # Convert boolean fields from string to integer
                if 'critical_ci' in row:
                    row['critical_ci'] = 1 if row['critical_ci'].lower() == 'true' else 0
                if 'rollback_plan' in row:
                    row['rollback_plan'] = 1 if row['rollback_plan'].lower() == 'true' else 0
                if 'test_evidence' in row:
                    row['test_evidence'] = 1 if row['test_evidence'].lower() == 'true' else 0
                
                # Convert empty strings to None for nullable fields
                for key, value in row.items():
                    if value == '':
                        row[key] = None
                
                # Prepare values in the correct order
                values = [row[field] for field in fieldnames]
                
                try:
                    cursor.execute(insert_query, values)
                    imported_count += 1
                except sqlite3.Error as e:
                    print(f"❌ Error inserting row {imported_count + 1}: {e}")
                    print(f"   Row data: {row}")
                    continue
            
            conn.commit()
            print(f"✅ Successfully imported {imported_count} records from CSV")
            return imported_count
            
    except Exception as e:
        print(f"❌ Error reading CSV file: {e}")
        return 0

def verify_import(conn):
    """Verify the import by showing some statistics."""
    try:
        cursor = conn.cursor()
        
        # Get total count
        cursor.execute("SELECT COUNT(*) FROM change_requests")
        total_count = cursor.fetchone()[0]
        
        # Get status distribution
        cursor.execute("SELECT status, COUNT(*) FROM change_requests GROUP BY status")
        status_counts = cursor.fetchall()
        
        # Get change type distribution
        cursor.execute("SELECT change_type, COUNT(*) FROM change_requests GROUP BY change_type")
        type_counts = cursor.fetchall()
        
        print(f"\n📊 Import Verification:")
        print(f"   Total records: {total_count}")
        print(f"   Status distribution:")
        for status, count in status_counts:
            print(f"     - {status}: {count}")
        print(f"   Change type distribution:")
        for change_type, count in type_counts:
            print(f"     - {change_type}: {count}")
            
        return total_count
        
    except sqlite3.Error as e:
        print(f"❌ Error verifying import: {e}")
        return 0

def main():
    """Main function to run the import script."""
    print("🚀 Change Requests Import Tool")
    print("=" * 40)
    
    # Database and CSV paths
    db_path = "backend/instance/change_risk_classifier.db"
    csv_path = "backend/change_requests_100.csv"
    
    # Check if files exist
    if not os.path.exists(db_path):
        print(f"❌ Database not found at {db_path}")
        print("Please run this script from the project root directory.")
        return
    
    if not os.path.exists(csv_path):
        print(f"❌ CSV file not found at {csv_path}")
        print("Please ensure the CSV file exists.")
        return
    
    # Connect to database
    conn = connect_to_database(db_path)
    if not conn:
        return
    
    try:
        print(f"📁 Database: {db_path}")
        print(f"📄 CSV File: {csv_path}")
        print()
        
        # Confirm deletion
        print("⚠️  This will DELETE all existing data from the change_requests table!")
        confirm = input("Do you want to continue? (yes/no): ").strip().lower()
        
        if confirm != 'yes':
            print("❌ Import cancelled by user.")
            return
        
        print("\n🔄 Starting import process...")
        
        # Delete existing data
        deleted_count = delete_existing_data(conn)
        
        # Import CSV data
        imported_count = import_csv_data(conn, csv_path)
        
        # Verify import
        final_count = verify_import(conn)
        
        print(f"\n✅ Import completed successfully!")
        print(f"   Deleted: {deleted_count} records")
        print(f"   Imported: {imported_count} records")
        print(f"   Final count: {final_count} records")
        
    except Exception as e:
        print(f"❌ Import failed: {e}")
    
    finally:
        conn.close()

if __name__ == "__main__":
    main()