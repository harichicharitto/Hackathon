"""
Export API endpoints.
Handles data export functionality for various formats and use cases.
"""

from flask import Blueprint, request, jsonify, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging
from datetime import datetime
import io

from services.export_service import ExportService
from services.audit_service import AuditService
from services.auth_service import AuthService
from models import AuditLog, AuditAction
from config import settings

logger = logging.getLogger(__name__)

export_bp = Blueprint('export', __name__)


@export_bp.route('/changes/csv', methods=['GET'])
@jwt_required()
def export_changes_csv():
    """Export changes to CSV format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        # Get query parameters
        filters = {}
        
        # Status filter
        status = request.args.get('status')
        if status:
            filters['status'] = status.split(',')
        
        # Risk level filter
        risk_level = request.args.get('risk_level')
        if risk_level:
            filters['risk_level'] = risk_level.split(',')
        
        # Change type filter
        change_type = request.args.get('change_type')
        if change_type:
            filters['change_type'] = change_type.split(',')
        
        # Date range filter
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        if start_date and end_date:
            filters['start_date'] = start_date
            filters['end_date'] = end_date
        
        # Get changes
        from services.dashboard_service import DashboardService
        changes_result = DashboardService.get_filtered_changes(
            filters=filters,
            user_id=None if current_user.is_admin() else current_user.id,
            page=1,
            per_page=1000  # Export all changes
        )
        
        changes = changes_result['changes']
        
        # Export to CSV
        csv_content = ExportService.export_changes_to_csv(
            changes,
            include_risk_details=True,
            include_audit_trail=False
        )
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="change_request",
            description=f"User {current_user.username} exported changes to CSV",
            user_id=current_user.id,
            request_data={
                "format": "csv",
                "filters": filters,
                "count": len(changes)
            }
        )
        
        # Return CSV content
        return jsonify({
            "filename": f"changes_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
            "content": csv_content,
            "count": len(changes),
            "message": f"Successfully exported {len(changes)} changes to CSV"
        }), 200
        
    except Exception as e:
        logger.error(f"Export changes CSV error: {e}")
        return jsonify({"error": "An error occurred while exporting changes to CSV"}), 500


@export_bp.route('/changes/excel', methods=['GET'])
@jwt_required()
def export_changes_excel():
    """Export changes to Excel format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        # Get query parameters
        filters = {}
        
        # Status filter
        status = request.args.get('status')
        if status:
            filters['status'] = status.split(',')
        
        # Risk level filter
        risk_level = request.args.get('risk_level')
        if risk_level:
            filters['risk_level'] = risk_level.split(',')
        
        # Change type filter
        change_type = request.args.get('change_type')
        if change_type:
            filters['change_type'] = change_type.split(',')
        
        # Date range filter
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        if start_date and end_date:
            filters['start_date'] = start_date
            filters['end_date'] = end_date
        
        # Get changes
        from services.dashboard_service import DashboardService
        changes_result = DashboardService.get_filtered_changes(
            filters=filters,
            user_id=None if current_user.is_admin() else current_user.id,
            page=1,
            per_page=1000  # Export all changes
        )
        
        changes = changes_result['changes']
        
        # Export to Excel
        excel_content = ExportService.export_changes_to_excel(
            changes,
            include_risk_details=True,
            include_audit_trail=False
        )
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="change_request",
            description=f"User {current_user.username} exported changes to Excel",
            user_id=current_user.id,
            request_data={
                "format": "excel",
                "filters": filters,
                "count": len(changes)
            }
        )
        
        # Return Excel content as base64
        excel_base64 = excel_content.decode('latin1')
        
        return jsonify({
            "filename": f"changes_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.xlsx",
            "content": excel_base64,
            "count": len(changes),
            "message": f"Successfully exported {len(changes)} changes to Excel"
        }), 200
        
    except Exception as e:
        logger.error(f"Export changes Excel error: {e}")
        return jsonify({"error": "An error occurred while exporting changes to Excel"}), 500


@export_bp.route('/changes/pdf', methods=['GET'])
@jwt_required()
def export_changes_pdf():
    """Export changes to PDF format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        # Get query parameters
        filters = {}
        
        # Status filter
        status = request.args.get('status')
        if status:
            filters['status'] = status.split(',')
        
        # Risk level filter
        risk_level = request.args.get('risk_level')
        if risk_level:
            filters['risk_level'] = risk_level.split(',')
        
        # Change type filter
        change_type = request.args.get('change_type')
        if change_type:
            filters['change_type'] = change_type.split(',')
        
        # Date range filter
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        if start_date and end_date:
            filters['start_date'] = start_date
            filters['end_date'] = end_date
        
        # Get changes
        from services.dashboard_service import DashboardService
        changes_result = DashboardService.get_filtered_changes(
            filters=filters,
            user_id=None if current_user.is_admin() else current_user.id,
            page=1,
            per_page=100  # Limit for PDF
        )
        
        changes = changes_result['changes']
        
        # Export to PDF
        pdf_content = ExportService.export_changes_to_pdf(
            changes,
            title=f"Change Request Report - {datetime.utcnow().strftime('%Y-%m-%d')}",
            include_risk_details=True
        )
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="change_request",
            description=f"User {current_user.username} exported changes to PDF",
            user_id=current_user.id,
            request_data={
                "format": "pdf",
                "filters": filters,
                "count": len(changes)
            }
        )
        
        # Return PDF content as base64
        pdf_base64 = pdf_content.decode('latin1')
        
        return jsonify({
            "filename": f"changes_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.pdf",
            "content": pdf_base64,
            "count": len(changes),
            "message": f"Successfully exported {len(changes)} changes to PDF"
        }), 200
        
    except Exception as e:
        logger.error(f"Export changes PDF error: {e}")
        return jsonify({"error": "An error occurred while exporting changes to PDF"}), 500


@export_bp.route('/dashboard-summary/csv', methods=['GET'])
@jwt_required()
def export_dashboard_summary_csv():
    """Export dashboard summary to CSV format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        # Get time period parameter
        time_period = request.args.get('time_period', '30d')
        
        # Get dashboard summary
        from services.dashboard_service import DashboardService
        summary = DashboardService.get_dashboard_summary(
            user_id=None if current_user.is_admin() else current_user.id
        )
        
        # Export to CSV
        csv_content = ExportService.export_dashboard_summary_to_csv(
            summary,
            time_period
        )
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="dashboard",
            description=f"User {current_user.username} exported dashboard summary to CSV",
            user_id=current_user.id,
            request_data={
                "format": "csv",
                "time_period": time_period
            }
        )
        
        return jsonify({
            "filename": f"dashboard_summary_{time_period}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
            "content": csv_content,
            "message": f"Successfully exported dashboard summary to CSV"
        }), 200
        
    except Exception as e:
        logger.error(f"Export dashboard summary CSV error: {e}")
        return jsonify({"error": "An error occurred while exporting dashboard summary to CSV"}), 500


@export_bp.route('/audit-trail/csv', methods=['GET'])
@jwt_required()
def export_audit_trail_csv():
    """Export audit trail to CSV format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        user_id = request.args.get('user_id', type=int)
        action = request.args.get('action')
        resource_type = request.args.get('resource_type')
        
        # Parse dates
        start_dt = None
        end_dt = None
        if start_date:
            start_dt = datetime.fromisoformat(start_date)
        if end_date:
            end_dt = datetime.fromisoformat(end_date)
        
        # Export audit trail
        csv_content = ExportService.export_audit_trail_to_csv(
            start_date=start_dt,
            end_date=end_dt,
            user_id=user_id,
            action=action,
            resource_type=resource_type
        )
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="audit_log",
            description=f"User {current_user.username} exported audit trail to CSV",
            user_id=current_user.id,
            request_data={
                "format": "csv",
                "start_date": start_date,
                "end_date": end_date,
                "user_id": user_id,
                "action": action,
                "resource_type": resource_type
            }
        )
        
        return jsonify({
            "filename": f"audit_trail_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
            "content": csv_content,
            "message": "Successfully exported audit trail to CSV"
        }), 200
        
    except Exception as e:
        logger.error(f"Export audit trail CSV error: {e}")
        return jsonify({"error": "An error occurred while exporting audit trail to CSV"}), 500


@export_bp.route('/cab-review-pack', methods=['POST'])
@jwt_required()
def export_cab_review_pack():
    """Generate CAB review pack with multiple formats."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        data = request.get_json()
        
        if not data or 'change_ids' not in data:
            return jsonify({"error": "Missing required field: change_ids"}), 400
        
        change_ids = data['change_ids']
        cab_date = data.get('cab_date', datetime.utcnow().strftime('%Y-%m-%d'))
        cab_time = data.get('cab_time', '10:00 AM')
        
        # Get changes
        from ..models import ChangeRequest
        changes = ChangeRequest.query.filter(ChangeRequest.id.in_(change_ids)).all()
        
        if not changes:
            return jsonify({"error": "No changes found for the provided IDs"}), 404
        
        # Generate CAB review pack
        cab_pack = ExportService.generate_cab_review_pack(
            changes,
            cab_date,
            cab_time
        )
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="change_request",
            description=f"User {current_user.username} generated CAB review pack",
            user_id=current_user.id,
            request_data={
                "change_ids": change_ids,
                "cab_date": cab_date,
                "cab_time": cab_time,
                "change_count": len(changes)
            }
        )
        
        # Convert binary content to base64 for JSON response
        pack_response = {}
        for format_name, content in cab_pack.items():
            if isinstance(content, bytes):
                pack_response[format_name] = content.decode('latin1')
            else:
                pack_response[format_name] = content
        
        return jsonify({
            "message": f"Successfully generated CAB review pack for {len(changes)} changes",
            "formats": list(cab_pack.keys()),
            "change_count": len(changes),
            "cab_date": cab_date,
            "cab_time": cab_time,
            "pack": pack_response
        }), 200
        
    except Exception as e:
        logger.error(f"Export CAB review pack error: {e}")
        return jsonify({"error": "An error occurred while generating CAB review pack"}), 500


@export_bp.route('/security-report/csv', methods=['GET'])
@jwt_required()
def export_security_report_csv():
    """Export security report to CSV format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get time period parameter
        time_period = request.args.get('time_period', '24h')
        
        # Get security report
        security_report = AuditService.get_security_report(time_period)
        
        # Convert to CSV
        import pandas as pd
        df = pd.DataFrame([security_report])
        csv_content = df.to_csv(index=False)
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="security_report",
            description=f"User {current_user.username} exported security report to CSV",
            user_id=current_user.id,
            request_data={
                "format": "csv",
                "time_period": time_period
            }
        )
        
        return jsonify({
            "filename": f"security_report_{time_period}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
            "content": csv_content,
            "message": f"Successfully exported security report to CSV"
        }), 200
        
    except Exception as e:
        logger.error(f"Export security report CSV error: {e}")
        return jsonify({"error": "An error occurred while exporting security report to CSV"}), 500


@export_bp.route('/compliance-report/csv', methods=['GET'])
@jwt_required()
def export_compliance_report_csv():
    """Export compliance report to CSV format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get date range parameters
        start_date_str = request.args.get('start_date')
        end_date_str = request.args.get('end_date')
        
        if not start_date_str or not end_date_str:
            return jsonify({"error": "Missing required parameters: start_date and end_date"}), 400
        
        # Parse dates
        start_date = datetime.fromisoformat(start_date_str)
        end_date = datetime.fromisoformat(end_date_str)
        
        # Get compliance report
        compliance_report = AuditService.get_compliance_report(start_date, end_date)
        
        # Convert to CSV
        import pandas as pd
        df = pd.DataFrame([compliance_report])
        csv_content = df.to_csv(index=False)
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="compliance_report",
            description=f"User {current_user.username} exported compliance report to CSV",
            user_id=current_user.id,
            request_data={
                "format": "csv",
                "start_date": start_date_str,
                "end_date": end_date_str
            }
        )
        
        return jsonify({
            "filename": f"compliance_report_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
            "content": csv_content,
            "message": f"Successfully exported compliance report to CSV"
        }), 200
        
    except Exception as e:
        logger.error(f"Export compliance report CSV error: {e}")
        return jsonify({"error": "An error occurred while exporting compliance report to CSV"}), 500


@export_bp.route('/user-activity-report/csv', methods=['GET'])
@jwt_required()
def export_user_activity_report_csv():
    """Export user activity report to CSV format."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get parameters
        user_id = request.args.get('user_id', type=int)
        days = request.args.get('days', 30, type=int)
        
        if not user_id:
            return jsonify({"error": "Missing required parameter: user_id"}), 400
        
        # Get user activity report
        user_report = AuditService.get_user_activity_report(user_id, days)
        
        # Convert to CSV
        import pandas as pd
        df = pd.DataFrame([user_report])
        csv_content = df.to_csv(index=False)
        
        # Log export
        AuditLog.log_action(
            action=AuditAction.EXPORT,
            resource_type="user_activity_report",
            description=f"User {current_user.username} exported user activity report to CSV",
            user_id=current_user.id,
            request_data={
                "format": "csv",
                "user_id": user_id,
                "days": days
            }
        )
        
        return jsonify({
            "filename": f"user_activity_report_{user_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv",
            "content": csv_content,
            "message": f"Successfully exported user activity report to CSV"
        }), 200
        
    except Exception as e:
        logger.error(f"Export user activity report CSV error: {e}")
        return jsonify({"error": "An error occurred while exporting user activity report to CSV"}), 500


@export_bp.route('/formats', methods=['GET'])
@jwt_required()
def get_export_formats():
    """Get available export formats and their descriptions."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        formats = {
            "changes": {
                "csv": {
                    "description": "Comma-separated values format for spreadsheets",
                    "features": ["All change details", "Risk scores", "User information"],
                    "use_cases": ["Data analysis", "Import to other systems", "Backup"]
                },
                "excel": {
                    "description": "Microsoft Excel format with formatting",
                    "features": ["Formatted tables", "Multiple sheets", "Charts"],
                    "use_cases": ["Reporting", "Presentation", "Detailed analysis"]
                },
                "pdf": {
                    "description": "Portable Document Format for viewing",
                    "features": ["Print-ready", "Professional layout", "Read-only"],
                    "use_cases": ["Documentation", "CAB meetings", "Archival"]
                }
            },
            "reports": {
                "dashboard_summary": {
                    "description": "Summary statistics and metrics",
                    "formats": ["CSV"],
                    "use_cases": ["Management reporting", "Trend analysis"]
                },
                "security": {
                    "description": "Security audit and compliance information",
                    "formats": ["CSV"],
                    "use_cases": ["Security reviews", "Compliance audits"]
                },
                "compliance": {
                    "description": "Regulatory compliance and audit trail",
                    "formats": ["CSV"],
                    "use_cases": ["Regulatory reporting", "Audit preparation"]
                },
                "audit_trail": {
                    "description": "Complete audit trail of system activities",
                    "formats": ["CSV"],
                    "use_cases": ["Forensic analysis", "Security investigations"]
                },
                "user_activity": {
                    "description": "Detailed user activity and access patterns",
                    "formats": ["CSV"],
                    "use_cases": ["User behavior analysis", "Access reviews"]
                }
            },
            "special": {
                "cab_review_pack": {
                    "description": "Complete package for CAB meetings",
                    "formats": ["CSV", "Excel", "PDF"],
                    "features": ["Multiple formats", "Summary documents", "Change details"],
                    "use_cases": ["CAB meetings", "Change approval process"]
                }
            }
        }
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="export",
            description=f"User {current_user.username} accessed export formats",
            user_id=current_user.id,
            request_data={"view": "formats"}
        )
        
        return jsonify({
            "formats": formats,
            "note": "Some formats may require specific permissions",
            "last_updated": datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Get export formats error: {e}")
        return jsonify({"error": "An error occurred while retrieving export formats"}), 500