"""
User model for authentication and authorization.
Handles user roles and permissions for the application.
"""

from typing import Optional
from sqlalchemy import String, Boolean, Enum
from sqlalchemy.orm import Mapped, mapped_column
from werkzeug.security import generate_password_hash, check_password_hash
from enum import Enum as PyEnum
from .base import BaseModel, db


class UserRole(PyEnum):
    """User roles in the system."""
    ADMIN = "admin"
    CHANGE_MANAGER = "change_manager"
    VIEWER = "viewer"


class User(BaseModel):
    """User model for authentication and authorization."""
    
    __tablename__ = "users"
    
    # User fields
    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(120), unique=True, nullable=False, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(100), nullable=False)
    role: Mapped[UserRole] = mapped_column(Enum(UserRole), default=UserRole.CHANGE_MANAGER, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    last_login: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    
    def set_password(self, password: str) -> None:
        """Hash and set the user's password."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password: str) -> bool:
        """Check if the provided password matches the hash."""
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self) -> bool:
        """Check if the user has admin privileges."""
        return self.role == UserRole.ADMIN
    
    def is_change_manager(self) -> bool:
        """Check if the user is a change manager."""
        return self.role == UserRole.CHANGE_MANAGER
    
    def to_dict(self) -> dict:
        """Convert user to dictionary, excluding sensitive information."""
        data = super().to_dict()
        # Remove sensitive fields
        data.pop('password_hash', None)
        # Convert role to string
        data['role'] = self.role.value if self.role else None
        return data
    
    @classmethod
    def create_admin(cls, username: str, email: str, password: str, full_name: str) -> 'User':
        """Create an admin user."""
        user = cls(
            username=username,
            email=email,
            full_name=full_name,
            role=UserRole.ADMIN
        )
        user.set_password(password)
        return user
    
    @classmethod
    def create_change_manager(cls, username: str, email: str, password: str, full_name: str) -> 'User':
        """Create a change manager user."""
        user = cls(
            username=username,
            email=email,
            full_name=full_name,
            role=UserRole.CHANGE_MANAGER
        )
        user.set_password(password)
        return user

    @classmethod
    def create_viewer(cls, username: str, email: str, password: str, full_name: str) -> 'User':
        """Create a viewer user."""
        user = cls(
            username=username,
            email=email,
            full_name=full_name,
            role=UserRole.VIEWER
        )
        user.set_password(password)
        return user
    
    def __repr__(self) -> str:
        """String representation of the user."""
        return f"<User(username='{self.username}', role='{self.role.value}')>"