"""
Export service for generating reports and exporting data in various formats.
Supports CSV, PDF, and Excel export functionality.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
import pandas as pd
from io import BytesIO
import base64

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

from models import ChangeRequest, RiskScore, User, AuditLog
from config import settings

logger = logging.getLogger(__name__)


class ExportService:
    """Export service for generating reports and exporting data."""

    @staticmethod
    def _change_value(change: Any, field: str, default: Any = None) -> Any:
        """Safely get a field from either a model instance or a dict payload."""
        if isinstance(change, dict):
            return change.get(field, default)
        return getattr(change, field, default)

    @staticmethod
    def _enum_to_value(value: Any) -> Any:
        """Return enum value when present, otherwise raw value."""
        return getattr(value, 'value', value)

    @staticmethod
    def _as_iso(value: Any) -> str:
        """Convert datetime-like value to ISO string."""
        if value is None:
            return ''
        if hasattr(value, 'isoformat'):
            return value.isoformat()
        return str(value)

    @staticmethod
    def _duration_hours(change: Any) -> float:
        """Get duration in hours from model/dict."""
        if isinstance(change, dict):
            return float(change.get('duration_hours') or 0)
        if hasattr(change, 'calculate_duration_hours'):
            return float(change.calculate_duration_hours())
        return 0.0
    
    @staticmethod
    def export_changes_to_csv(
        changes: List[ChangeRequest],
        include_risk_details: bool = True,
        include_audit_trail: bool = False
    ) -> str:
        """
        Export change requests to CSV format.
        
        Args:
            changes: List of change requests to export
            include_risk_details: Include detailed risk information
            include_audit_trail: Include audit trail information
            
        Returns:
            CSV string content
        """
        try:
            # Prepare data
            data = []
            
            for change in changes:
                row = {
                    'ID': ExportService._change_value(change, 'id', ''),
                    'Title': ExportService._change_value(change, 'title', ''),
                    'Description': ExportService._change_value(change, 'description', ''),
                    'Change Type': ExportService._enum_to_value(ExportService._change_value(change, 'change_type', '')),
                    'Status': ExportService._enum_to_value(ExportService._change_value(change, 'status', '')),
                    'Risk Level': ExportService._change_value(change, 'risk_level', ''),
                    'Risk Score': ExportService._change_value(change, 'risk_score', ''),
                    'Change Window': ExportService._enum_to_value(ExportService._change_value(change, 'change_window', '')),
                    'Start Time': ExportService._as_iso(ExportService._change_value(change, 'start_time')),
                    'End Time': ExportService._as_iso(ExportService._change_value(change, 'end_time')),
                    'Duration (Hours)': ExportService._duration_hours(change),
                    'Critical CI': ExportService._change_value(change, 'critical_ci', False),
                    'Rollback Plan': ExportService._change_value(change, 'rollback_plan', False),
                    'Test Evidence': ExportService._change_value(change, 'test_evidence', False),
                    'Business Owner': ExportService._change_value(change, 'business_owner', ''),
                    'Technical Owner': ExportService._change_value(change, 'technical_owner', ''),
                    'Submitted By': '',
                    'Approved By': '',
                    'Submitted At': ExportService._as_iso(ExportService._change_value(change, 'submitted_at')),
                    'Approved At': ExportService._as_iso(ExportService._change_value(change, 'approved_at')),
                    'Created At': ExportService._as_iso(ExportService._change_value(change, 'created_at')),
                    'Updated At': ExportService._as_iso(ExportService._change_value(change, 'updated_at'))
                }

                if not isinstance(change, dict):
                    row['Submitted By'] = change.submitted_by.username if change.submitted_by else ''
                    row['Approved By'] = change.approved_by.username if change.approved_by else ''
                
                # Add risk details if requested
                if include_risk_details:
                    change_id = ExportService._change_value(change, 'id')
                    risk_scores = RiskScore.query.filter_by(change_request_id=change_id).first() if change_id else None
                    if risk_scores:
                        row.update({
                            'Base Score': risk_scores.base_score,
                            'CI Impact Score': risk_scores.ci_impact_score,
                            'Timing Score': risk_scores.timing_score,
                            'Scope Score': risk_scores.scope_score,
                            'Rollback Score': risk_scores.rollback_score,
                            'CI Criticality': risk_scores.ci_criticality,
                            'Impacted Systems Count': risk_scores.impacted_systems_count,
                            'Dependencies Count': risk_scores.dependencies_count,
                            'Rollback Available': risk_scores.rollback_available,
                            'Risk Reasoning': risk_scores.risk_reasoning,
                            'Assessment Method': risk_scores.assessment_method
                        })
                
                # Add audit trail if requested
                if include_audit_trail:
                    change_id = ExportService._change_value(change, 'id')
                    audit_logs = AuditLog.query.filter_by(
                        resource_type='change_request',
                        resource_id=str(change_id)
                    ).order_by(AuditLog.created_at).all()
                    
                    if audit_logs:
                        row['Audit Trail'] = '; '.join([
                            f"{log.created_at.isoformat()} - {log.action} by {log.user_email or 'System'}"
                            for log in audit_logs
                        ])
                
                data.append(row)
            
            # Create DataFrame and convert to CSV
            df = pd.DataFrame(data)
            csv_content = df.to_csv(index=False)
            
            logger.info(f"Exported {len(changes)} changes to CSV")
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting changes to CSV: {e}")
            return ""
    
    @staticmethod
    def export_changes_to_excel(
        changes: List[ChangeRequest],
        include_risk_details: bool = True,
        include_audit_trail: bool = False
    ) -> bytes:
        """
        Export change requests to Excel format.
        
        Args:
            changes: List of change requests to export
            include_risk_details: Include detailed risk information
            include_audit_trail: Include audit trail information
            
        Returns:
            Excel file content as bytes
        """
        try:
            # Prepare data
            data = []
            
            for change in changes:
                row = {
                    'ID': ExportService._change_value(change, 'id', ''),
                    'Title': ExportService._change_value(change, 'title', ''),
                    'Description': ExportService._change_value(change, 'description', ''),
                    'Change Type': ExportService._enum_to_value(ExportService._change_value(change, 'change_type', '')),
                    'Status': ExportService._enum_to_value(ExportService._change_value(change, 'status', '')),
                    'Risk Level': ExportService._change_value(change, 'risk_level', ''),
                    'Risk Score': ExportService._change_value(change, 'risk_score', ''),
                    'Change Window': ExportService._enum_to_value(ExportService._change_value(change, 'change_window', '')),
                    'Start Time': ExportService._change_value(change, 'start_time', ''),
                    'End Time': ExportService._change_value(change, 'end_time', ''),
                    'Duration (Hours)': ExportService._duration_hours(change),
                    'Critical CI': ExportService._change_value(change, 'critical_ci', False),
                    'Rollback Plan': ExportService._change_value(change, 'rollback_plan', False),
                    'Test Evidence': ExportService._change_value(change, 'test_evidence', False),
                    'Business Owner': ExportService._change_value(change, 'business_owner', ''),
                    'Technical Owner': ExportService._change_value(change, 'technical_owner', ''),
                    'Submitted By': '',
                    'Approved By': '',
                    'Submitted At': ExportService._change_value(change, 'submitted_at', ''),
                    'Approved At': ExportService._change_value(change, 'approved_at', ''),
                    'Created At': ExportService._change_value(change, 'created_at', ''),
                    'Updated At': ExportService._change_value(change, 'updated_at', '')
                }

                if not isinstance(change, dict):
                    row['Submitted By'] = change.submitted_by.username if change.submitted_by else ''
                    row['Approved By'] = change.approved_by.username if change.approved_by else ''
                
                # Add risk details if requested
                if include_risk_details:
                    change_id = ExportService._change_value(change, 'id')
                    risk_scores = RiskScore.query.filter_by(change_request_id=change_id).first() if change_id else None
                    if risk_scores:
                        row.update({
                            'Base Score': risk_scores.base_score,
                            'CI Impact Score': risk_scores.ci_impact_score,
                            'Timing Score': risk_scores.timing_score,
                            'Scope Score': risk_scores.scope_score,
                            'Rollback Score': risk_scores.rollback_score,
                            'CI Criticality': risk_scores.ci_criticality,
                            'Impacted Systems Count': risk_scores.impacted_systems_count,
                            'Dependencies Count': risk_scores.dependencies_count,
                            'Rollback Available': risk_scores.rollback_available,
                            'Risk Reasoning': risk_scores.risk_reasoning,
                            'Assessment Method': risk_scores.assessment_method
                        })
                
                data.append(row)
            
            # Create Excel file
            output = BytesIO()
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                df = pd.DataFrame(data)
                df.to_excel(writer, sheet_name='Changes', index=False)
            
            excel_content = output.getvalue()
            logger.info(f"Exported {len(changes)} changes to Excel")
            return excel_content
            
        except Exception as e:
            logger.error(f"Error exporting changes to Excel: {e}")
            return b""
    
    @staticmethod
    def export_changes_to_pdf(
        changes: List[ChangeRequest],
        title: str = "Change Request Report",
        include_risk_details: bool = True
    ) -> bytes:
        """
        Export change requests to PDF format.
        
        Args:
            changes: List of change requests to export
            title: Report title
            include_risk_details: Include detailed risk information
            
        Returns:
            PDF file content as bytes
        """
        try:
            # Create PDF in memory with landscape orientation
            buffer = BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=landscape(A4), rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
            styles = getSampleStyleSheet()
            story = []
            
            # Title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                spaceAfter=30,
                alignment=TA_CENTER
            )
            story.append(Paragraph(title, title_style))
            story.append(Spacer(1, 12))
            
            # Summary
            summary_data = [
                ['Total Changes', str(len(changes))],
                ['High Risk', str(sum(1 for c in changes if ExportService._change_value(c, 'risk_level') == 'High'))],
                ['Medium Risk', str(sum(1 for c in changes if ExportService._change_value(c, 'risk_level') == 'Medium'))],
                ['Low Risk', str(sum(1 for c in changes if ExportService._change_value(c, 'risk_level') == 'Low'))],
                ['Approved', str(sum(1 for c in changes if ExportService._enum_to_value(ExportService._change_value(c, 'status')) == 'approved'))],
                ['Pending', str(sum(1 for c in changes if ExportService._enum_to_value(ExportService._change_value(c, 'status')) in ['submitted', 'review']))]
            ]
            
            summary_table = Table(summary_data, colWidths=[3*inch, 3*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(Paragraph("Summary", styles['Heading2']))
            story.append(summary_table)
            story.append(Spacer(1, 12))
            
            # Changes table
            story.append(Paragraph("Change Details", styles['Heading2']))
            story.append(Spacer(1, 12))
            
            # Table headers
            headers = [
                'ID', 'Title', 'Type', 'Status', 'Risk', 'Window', 
                'Start Time', 'End Time', 'Duration', 'Owner', 'Submitted'
            ]
            
            if include_risk_details:
                headers.extend(['CI Impact', 'Timing', 'Scope', 'Rollback'])
            
            # Table data
            table_data = [headers]
            
            for change in changes:
                row = [
                    str(ExportService._change_value(change, 'id', '')),
                    (ExportService._change_value(change, 'title', '') or '')[:50] + '...' if len(ExportService._change_value(change, 'title', '') or '') > 50 else (ExportService._change_value(change, 'title', '') or ''),
                    str(ExportService._enum_to_value(ExportService._change_value(change, 'change_type', ''))),
                    str(ExportService._enum_to_value(ExportService._change_value(change, 'status', ''))),
                    str(ExportService._change_value(change, 'risk_level', '')),
                    str(ExportService._enum_to_value(ExportService._change_value(change, 'change_window', ''))),
                    str(ExportService._change_value(change, 'start_time', '') or ''),
                    str(ExportService._change_value(change, 'end_time', '') or ''),
                    f"{ExportService._duration_hours(change):.1f}",
                    str(ExportService._change_value(change, 'business_owner', '')),
                    str(ExportService._change_value(change, 'submitted_at', '') or '')
                ]
                
                if include_risk_details:
                    change_id = ExportService._change_value(change, 'id')
                    risk_scores = RiskScore.query.filter_by(change_request_id=change_id).first() if change_id else None
                    if risk_scores:
                        row.extend([
                            str(risk_scores.ci_impact_score),
                            str(risk_scores.timing_score),
                            str(risk_scores.scope_score),
                            str(risk_scores.rollback_score)
                        ])
                    else:
                        row.extend(['-', '-', '-', '-'])
                
                table_data.append(row)
            
            # Create table with proper column widths and text wrapping
            # Calculate available width for content columns (landscape provides more horizontal space)
            page_width = landscape(A4)[0] - 2 * inch  # Account for margins, use landscape width
            num_cols = len(headers)
            
            # Set column widths - ensure all columns fit within page width
            # Landscape orientation provides more space, but we need to be conservative
            col_widths = []
            for i, header in enumerate(headers):
                if header in ['Title', 'Risk Reasoning']:
                    # Wider columns for text content, but not too wide
                    col_widths.append(page_width * 0.22)
                elif header in ['ID', 'Risk', 'Window', 'Duration', 'Submitted']:
                    # Narrower columns for short data
                    col_widths.append(page_width * 0.06)
                else:
                    # Medium columns for other data
                    col_widths.append(page_width * 0.08)
            
            table = Table(table_data, colWidths=col_widths, repeatRows=1)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
                ('ALIGN', (0, 1), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),  # Changed from MIDDLE to TOP for better text wrapping
                ('WORDWRAP', (0, 0), (-1, -1), True),  # Enable word wrapping
                ('TEXTFONT', (0, 0), (-1, -1), 'Helvetica'),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                ('LEFTPADDING', (0, 0), (-1, -1), 4),
                ('RIGHTPADDING', (0, 0), (-1, -1), 4),
                ('TOPPADDING', (0, 0), (-1, -1), 4),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ]))
            
            story.append(table)
            
            # Build PDF
            doc.build(story)
            pdf_content = buffer.getvalue()
            buffer.close()
            
            logger.info(f"Exported {len(changes)} changes to PDF")
            return pdf_content
            
        except Exception as e:
            logger.error(f"Error exporting changes to PDF: {e}")
            return b""
    
    @staticmethod
    def export_dashboard_summary_to_csv(
        dashboard_data: Dict[str, Any],
        time_period: str = "30d"
    ) -> str:
        """
        Export dashboard summary to CSV format.
        
        Args:
            dashboard_data: Dashboard data to export
            time_period: Time period for the report
            
        Returns:
            CSV string content
        """
        try:
            data = []
            
            # Summary section
            summary = dashboard_data.get('summary', {})
            data.append(['Summary', ''])
            data.append(['Total Changes', summary.get('total_changes', 0)])
            data.append(['Pending Changes', summary.get('pending_changes', 0)])
            data.append(['Approved Changes', summary.get('approved_changes', 0)])
            data.append(['High Risk Changes', summary.get('high_risk_changes', 0)])
            data.append(['Medium Risk Changes', summary.get('medium_risk_changes', 0)])
            data.append(['Low Risk Changes', summary.get('low_risk_changes', 0)])
            data.append(['', ''])
            
            # Status distribution
            status_dist = dashboard_data.get('status_distribution', {})
            data.append(['Status Distribution', ''])
            for status, count in status_dist.items():
                data.append([status, count])
            data.append(['', ''])
            
            # Risk distribution
            risk_dist = dashboard_data.get('risk_distribution', {})
            data.append(['Risk Distribution', ''])
            for risk, count in risk_dist.items():
                data.append([risk, count])
            data.append(['', ''])
            
            # Performance metrics
            perf_metrics = dashboard_data.get('performance_metrics', {})
            data.append(['Performance Metrics', ''])
            data.append(['Average Approval Time (Hours)', perf_metrics.get('average_approval_time_hours', 0)])
            data.append(['Success Rate (%)', perf_metrics.get('success_rate_percentage', 0)])
            data.append(['Total Submitted', perf_metrics.get('total_submitted', 0)])
            data.append(['Approved Count', perf_metrics.get('approved_count', 0)])
            data.append(['Rejected Count', perf_metrics.get('rejected_count', 0)])
            
            # Create DataFrame and convert to CSV
            df = pd.DataFrame(data, columns=['Metric', 'Value'])
            csv_content = df.to_csv(index=False)
            
            logger.info(f"Exported dashboard summary to CSV for period {time_period}")
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting dashboard summary to CSV: {e}")
            return ""
    
    @staticmethod
    def export_audit_trail_to_csv(
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        user_id: Optional[int] = None,
        resource_type: Optional[str] = None
    ) -> str:
        """
        Export audit trail to CSV format.
        
        Args:
            start_date: Start date for filtering
            end_date: End date for filtering
            user_id: User ID to filter by
            resource_type: Resource type to filter by
            
        Returns:
            CSV string content
        """
        try:
            # Build query
            query = AuditLog.query
            
            if start_date:
                query = query.filter(AuditLog.created_at >= start_date)
            if end_date:
                query = query.filter(AuditLog.created_at <= end_date)
            if user_id:
                query = query.filter(AuditLog.user_id == user_id)
            if resource_type:
                query = query.filter(AuditLog.resource_type == resource_type)
            
            audit_logs = query.order_by(AuditLog.created_at.desc()).all()
            
            # Prepare data
            data = []
            for log in audit_logs:
                row = {
                    'Timestamp': log.created_at.isoformat(),
                    'User': log.user_email or 'System',
                    'Action': log.action,
                    'Resource Type': log.resource_type,
                    'Resource ID': log.resource_id,
                    'Description': log.description,
                    'IP Address': log.ip_address,
                    'Status Code': log.status_code,
                    'Is Suspicious': log.is_suspicious,
                    'Suspicious Reason': log.suspicious_reason
                }
                data.append(row)
            
            # Create DataFrame and convert to CSV
            df = pd.DataFrame(data)
            csv_content = df.to_csv(index=False)
            
            logger.info(f"Exported {len(audit_logs)} audit logs to CSV")
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting audit trail to CSV: {e}")
            return ""
    
    @staticmethod
    def generate_cab_review_pack(
        changes: List[ChangeRequest],
        cab_date: str,
        cab_time: str
    ) -> Dict[str, bytes]:
        """
        Generate a complete CAB review pack with multiple formats.
        
        Args:
            changes: List of changes for CAB review
            cab_date: CAB meeting date
            cab_time: CAB meeting time
            
        Returns:
            Dict containing different format files
        """
        try:
            pack = {}
            
            # Generate title
            title = f"CAB Review Pack - {cab_date} at {cab_time}"
            
            # Generate CSV
            csv_content = ExportService.export_changes_to_csv(changes, include_risk_details=True)
            pack['csv'] = csv_content.encode('utf-8')
            
            # Generate Excel
            excel_content = ExportService.export_changes_to_excel(changes, include_risk_details=True)
            pack['excel'] = excel_content
            
            # Generate PDF
            pdf_content = ExportService.export_changes_to_pdf(changes, title, include_risk_details=True)
            pack['pdf'] = pdf_content
            
            # Generate summary CSV
            summary_data = {
                'summary': {
                    'total_changes': len(changes),
                    'high_risk_changes': sum(1 for c in changes if c.risk_level == 'High'),
                    'medium_risk_changes': sum(1 for c in changes if c.risk_level == 'Medium'),
                    'low_risk_changes': sum(1 for c in changes if c.risk_level == 'Low'),
                    'pending_changes': sum(1 for c in changes if c.status in ['submitted', 'review']),
                    'approved_changes': sum(1 for c in changes if c.status == 'approved')
                }
            }
            summary_csv = ExportService.export_dashboard_summary_to_csv(summary_data)
            pack['summary_csv'] = summary_csv.encode('utf-8')
            
            logger.info(f"Generated CAB review pack for {len(changes)} changes")
            return pack
            
        except Exception as e:
            logger.error(f"Error generating CAB review pack: {e}")
            return {}