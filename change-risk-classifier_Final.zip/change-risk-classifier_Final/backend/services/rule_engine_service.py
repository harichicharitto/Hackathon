"""
Rule Engine service for managing and executing business rules.
Provides dynamic rule evaluation and management functionality.
"""

from typing import List, Dict, Any, Optional
import ast
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import Rule, AuditLog, AuditAction, db
from config import settings

logger = logging.getLogger(__name__)


class RuleEngineService:
    """Rule Engine service for managing and executing business rules."""

    DEFAULT_RISK_LOGIC = {
        "high_risk": "Critical CI + business hours + multiple systems + no rollback plan",
        "medium_risk": "Non-critical CI + limited blast radius + rollback available",
        "low_risk": "Standard change + approved window + single system"
    }

    RISK_RULE_NAMES = {
        "high_risk": "high_risk_classification",
        "medium_risk": "medium_risk_classification",
        "low_risk": "low_risk_classification"
    }

    GENERIC_RISK_DESCRIPTIONS = {
        "high_risk": "Classify change as High Risk",
        "medium_risk": "Classify change as Medium Risk",
        "low_risk": "Classify change as Low Risk"
    }

    DEFAULT_RISK_CONFIG_RULES = [
        {
            "name": "risk_config_ci_criticality_scoring",
            "title": "CI Criticality Scoring",
            "risk_level": "HIGH",
            "condition": "critical CI -> 30 pts; high -> 25 pts; medium -> 15 pts; low -> 5 pts",
            "base_score": 30.0,
            "weight": 1.0,
            "thresholds": "L: 0.0 · M: 30.0 · H: 60.0",
            "mandatory_fields": "ci_name,ci_criticality",
            "status": "active",
            "priority": 10
        },
        {
            "name": "risk_config_systems_impact_scoring",
            "title": "Systems Impact Scoring",
            "risk_level": "MEDIUM",
            "condition": ">=10 systems -> 20 pts; >=5 -> 15 pts; >=3 -> 10 pts; >=2 -> 5 pts; 1 -> 0 pts",
            "base_score": 20.0,
            "weight": 1.0,
            "thresholds": "L: 0.0 · M: 30.0 · H: 60.0",
            "mandatory_fields": "number_of_systems",
            "status": "active",
            "priority": 20
        },
        {
            "name": "risk_config_business_hours_risk",
            "title": "Business Hours Risk",
            "risk_level": "MEDIUM",
            "condition": "Weekday 9-17 -> 15 pts; weekday off-hours -> 5 pts; weekend -> 0 pts",
            "base_score": 15.0,
            "weight": 1.0,
            "thresholds": "L: 0.0 · M: 30.0 · H: 60.0",
            "mandatory_fields": "change_start,change_end",
            "status": "active",
            "priority": 30
        },
        {
            "name": "risk_config_rollback_plan_check",
            "title": "Rollback Plan Check",
            "risk_level": "HIGH",
            "condition": "No rollback plan -> 15 pts; rollback plan present -> 0 pts",
            "base_score": 15.0,
            "weight": 1.0,
            "thresholds": "L: 0.0 · M: 30.0 · H: 60.0",
            "mandatory_fields": "has_rollback_plan",
            "status": "active",
            "priority": 40
        }
    ]

    @staticmethod
    def _parse_rule_parameters(parameters: Any) -> Dict[str, Any]:
        """Normalize rule parameters into a dictionary."""
        if not parameters:
            return {}

        if isinstance(parameters, dict):
            return parameters

        if isinstance(parameters, str):
            try:
                parsed = ast.literal_eval(parameters)
                return parsed if isinstance(parsed, dict) else {}
            except Exception:
                return {}

        return {}

    @staticmethod
    def _ensure_risk_config_rules() -> None:
        """Create default risk configuration rules if they do not exist."""
        existing_names = {
            name for (name,) in Rule.query.with_entities(Rule.name).filter(
                Rule.name.like('risk_config_%')
            ).all()
        }

        created_any = False

        for config in RuleEngineService.DEFAULT_RISK_CONFIG_RULES:
            if config["name"] in existing_names:
                continue

            rule = Rule(
                name=config["name"],
                description=config["title"],
                rule_type="notification",
                status=config["status"],
                condition="True",
                action="result = {'configured': True}",
                priority=config["priority"],
                created_by="system",
                last_modified_by="system",
                parameters=str({
                    "risk_level": config["risk_level"],
                    "condition": config["condition"],
                    "base_score": config["base_score"],
                    "weight": config["weight"],
                    "thresholds": config["thresholds"],
                    "mandatory_fields": config["mandatory_fields"]
                })
            )
            db.session.add(rule)
            created_any = True

        if created_any:
            db.session.commit()

    @staticmethod
    def get_risk_config_rules() -> List[Dict[str, Any]]:
        """Get card-style configurable risk rules for UI and AI context."""
        try:
            RuleEngineService._ensure_risk_config_rules()
            rules = Rule.query.filter(
                Rule.name.like('risk_config_%')
            ).order_by(Rule.priority.asc(), Rule.created_at.asc()).all()

            formatted = []
            for rule in rules:
                parameters = RuleEngineService._parse_rule_parameters(rule.parameters)
                formatted.append({
                    "id": rule.id,
                    "name": rule.name,
                    "title": rule.description or rule.name,
                    "risk_level": parameters.get("risk_level", "MEDIUM"),
                    "condition": parameters.get("condition", ""),
                    "base_score": parameters.get("base_score", 0.0),
                    "weight": parameters.get("weight", 1.0),
                    "thresholds": parameters.get("thresholds", "L: 0.0 · M: 30.0 · H: 60.0"),
                    "mandatory_fields": parameters.get("mandatory_fields", ""),
                    "status": rule.status,
                    "priority": rule.priority
                })

            return formatted
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving risk config rules: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error retrieving risk config rules: {e}")
            return []

    @staticmethod
    def create_risk_config_rule(data: Dict[str, Any], created_by: Optional[str]) -> Optional[Dict[str, Any]]:
        """Create a new configurable risk rule card."""
        try:
            title = data.get("title", "").strip()
            if not title:
                return None

            safe_name = "risk_config_" + "_".join(title.lower().split())
            suffix = 1
            unique_name = safe_name
            while Rule.query.filter_by(name=unique_name).first() is not None:
                suffix += 1
                unique_name = f"{safe_name}_{suffix}"

            rule = Rule(
                name=unique_name,
                description=title,
                rule_type="notification",
                status=data.get("status", "active"),
                condition="True",
                action="result = {'configured': True}",
                priority=int(data.get("priority", 100)),
                created_by=created_by,
                last_modified_by=created_by,
                parameters=str({
                    "risk_level": data.get("risk_level", "MEDIUM"),
                    "condition": data.get("condition", ""),
                    "base_score": float(data.get("base_score", 0) or 0),
                    "weight": float(data.get("weight", 1) or 1),
                    "thresholds": data.get("thresholds", "L: 0.0 · M: 30.0 · H: 60.0"),
                    "mandatory_fields": data.get("mandatory_fields", "")
                })
            )
            db.session.add(rule)
            db.session.commit()
            return {"id": rule.id}
        except Exception as e:
            logger.error(f"Error creating risk config rule: {e}")
            return None

    @staticmethod
    def update_risk_config_rule(rule_id: int, data: Dict[str, Any], modified_by: Optional[str]) -> bool:
        """Update an existing configurable risk rule card."""
        try:
            rule = Rule.query.get(rule_id)
            if not rule or not rule.name.startswith("risk_config_"):
                return False

            current = RuleEngineService._parse_rule_parameters(rule.parameters)
            current.update({
                "risk_level": data.get("risk_level", current.get("risk_level", "MEDIUM")),
                "condition": data.get("condition", current.get("condition", "")),
                "base_score": float(data.get("base_score", current.get("base_score", 0)) or 0),
                "weight": float(data.get("weight", current.get("weight", 1)) or 1),
                "thresholds": data.get("thresholds", current.get("thresholds", "L: 0.0 · M: 30.0 · H: 60.0")),
                "mandatory_fields": data.get("mandatory_fields", current.get("mandatory_fields", ""))
            })

            if data.get("title"):
                rule.description = data["title"].strip()
            if data.get("status") in ["active", "inactive"]:
                rule.status = data["status"]
            if data.get("priority") is not None:
                rule.priority = int(data["priority"])

            rule.parameters = str(current)
            rule.last_modified_by = modified_by
            db.session.commit()
            return True
        except Exception as e:
            logger.error(f"Error updating risk config rule {rule_id}: {e}")
            return False

    @staticmethod
    def set_risk_config_rule_status(rule_id: int, active: bool, modified_by: Optional[str]) -> bool:
        """Activate or deactivate a configurable risk rule card."""
        status = "active" if active else "inactive"
        return RuleEngineService.update_risk_config_rule(
            rule_id=rule_id,
            data={"status": status},
            modified_by=modified_by
        )

    @staticmethod
    def get_risk_logic_for_ai() -> Dict[str, str]:
        """Get configurable high/medium/low logic text for AI context."""
        try:
            rule_names = list(RuleEngineService.RISK_RULE_NAMES.values())
            rules = Rule.query.filter(Rule.name.in_(rule_names)).all()
            by_name = {rule.name: rule for rule in rules}

            resolved_logic = {}
            for level, rule_name in RuleEngineService.RISK_RULE_NAMES.items():
                rule = by_name.get(rule_name)
                description = rule.description.strip() if rule and rule.description else ""

                if not description or description == RuleEngineService.GENERIC_RISK_DESCRIPTIONS[level]:
                    resolved_logic[level] = RuleEngineService.DEFAULT_RISK_LOGIC[level]
                else:
                    resolved_logic[level] = description

            return resolved_logic
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving configurable risk logic: {e}")
            return RuleEngineService.DEFAULT_RISK_LOGIC.copy()
    
    @staticmethod
    def get_active_rules(rule_type: Optional[str] = None) -> List[Rule]:
        """
        Get all active rules, optionally filtered by type.
        
        Args:
            rule_type: Optional rule type to filter by
            
        Returns:
            List of active rules, sorted by priority
        """
        try:
            query = Rule.query.filter_by(status="active")
            
            if rule_type:
                query = query.filter_by(rule_type=rule_type)
            
            rules = query.order_by(Rule.priority.asc()).all()
            return rules
            
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving active rules: {e}")
            return []
    
    @staticmethod
    def evaluate_rules(context: Dict[str, Any], rule_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Evaluate rules against a context and return results.
        
        Args:
            context: Dictionary containing context data for rule evaluation
            rule_type: Optional rule type to filter by
            
        Returns:
            List of rule evaluation results
        """
        results = []
        rules = RuleEngineService.get_active_rules(rule_type)
        
        for rule in rules:
            try:
                # Evaluate rule condition
                condition_result = rule.evaluate_condition(context)
                
                if condition_result:
                    # Execute rule action
                    action_result = rule.execute_action(context)
                    
                    result = {
                        "rule_name": rule.name,
                        "rule_type": rule.rule_type,
                        "condition_met": True,
                        "action_result": action_result,
                        "priority": rule.priority,
                        "description": rule.description
                    }
                    
                    results.append(result)
                    
                    # Log rule execution
                    AuditLog.log_action(
                        action=AuditAction.READ,
                        resource_type="rule",
                        description=f"Rule {rule.name} evaluated and executed",
                        resource_id=rule.name,
                        request_data={"context": context},
                        response_data={"result": action_result}
                    )
                    
            except Exception as e:
                logger.error(f"Error evaluating rule {rule.name}: {e}")
                
                # Log rule evaluation error
                AuditLog.log_action(
                    action=AuditAction.UPDATE,
                    resource_type="rule",
                    description=f"Error evaluating rule {rule.name}: {str(e)}",
                    resource_id=rule.name,
                    request_data={"context": context}
                )
        
        # Sort results by priority (lower number = higher priority)
        results.sort(key=lambda x: x["priority"])
        
        return results
    
    @staticmethod
    def create_rule(
        name: str,
        description: str,
        rule_type: str,
        condition: str,
        action: str,
        priority: int = 100,
        parameters: Optional[Dict[str, Any]] = None,
        created_by: Optional[str] = None
    ) -> Optional[Rule]:
        """
        Create a new rule.
        
        Args:
            name: Rule name
            description: Rule description
            rule_type: Rule type
            condition: Rule condition (Python expression)
            action: Rule action (Python expression)
            priority: Rule priority (lower = higher priority)
            parameters: Optional rule parameters
            created_by: User who created the rule
            
        Returns:
            Created Rule object or None if creation fails
        """
        try:
            # Check if rule name already exists
            if Rule.query.filter_by(name=name).first():
                logger.warning(f"Rule name {name} already exists")
                return None
            
            # Create rule
            rule = Rule(
                name=name,
                description=description,
                rule_type=rule_type,
                condition=condition,
                action=action,
                priority=priority,
                created_by=created_by,
                last_modified_by=created_by
            )
            
            # Set parameters if provided
            if parameters:
                rule.parameters = str(parameters)
            
            # Validate rule
            rule.validate_rule()
            
            # Save to database
            rule.save()
            
            # Log rule creation
            AuditLog.log_action(
                action=AuditAction.CREATE,
                resource_type="rule",
                description=f"Rule {name} created",
                resource_id=name,
                user_email=created_by,
                request_data={
                    "name": name,
                    "description": description,
                    "rule_type": rule_type,
                    "priority": priority
                }
            )
            
            logger.info(f"Rule {name} created successfully")
            return rule
            
        except SQLAlchemyError as e:
            logger.error(f"Database error creating rule {name}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error creating rule {name}: {e}")
            return None
    
    @staticmethod
    def update_rule(
        rule_id: int,
        name: Optional[str] = None,
        description: Optional[str] = None,
        rule_type: Optional[str] = None,
        condition: Optional[str] = None,
        action: Optional[str] = None,
        priority: Optional[int] = None,
        parameters: Optional[Dict[str, Any]] = None,
        status: Optional[str] = None,
        modified_by: Optional[str] = None
    ) -> Optional[Rule]:
        """
        Update an existing rule.
        
        Args:
            rule_id: Rule ID to update
            name: Optional new name
            description: Optional new description
            rule_type: Optional new rule type
            condition: Optional new condition
            action: Optional new action
            priority: Optional new priority
            parameters: Optional new parameters
            status: Optional new status
            modified_by: User who modified the rule
            
        Returns:
            Updated Rule object or None if update fails
        """
        try:
            rule = Rule.query.get(rule_id)
            if not rule:
                logger.warning(f"Rule {rule_id} not found")
                return None
            
            # Update rule fields
            if name is not None:
                rule.name = name
            if description is not None:
                rule.description = description
            if rule_type is not None:
                rule.rule_type = rule_type
            if condition is not None:
                rule.condition = condition
            if action is not None:
                rule.action = action
            if priority is not None:
                rule.priority = priority
            if status is not None:
                rule.status = status
            
            # Update parameters if provided
            if parameters is not None:
                rule.parameters = str(parameters)
            
            # Update last modified info
            if modified_by:
                rule.last_modified_by = modified_by
            
            # Re-validate rule
            rule.validate_rule()
            
            # Save to database
            rule.save()
            
            # Log rule update
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="rule",
                description=f"Rule {rule.name} updated",
                resource_id=rule.name,
                user_email=modified_by,
                request_data={
                    "rule_id": rule_id,
                    "name": name,
                    "description": description,
                    "rule_type": rule_type,
                    "priority": priority,
                    "status": status
                }
            )
            
            logger.info(f"Rule {rule.name} updated successfully")
            return rule
            
        except SQLAlchemyError as e:
            logger.error(f"Database error updating rule {rule_id}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error updating rule {rule_id}: {e}")
            return None
    
    @staticmethod
    def delete_rule(rule_id: int, deleted_by: Optional[str] = None) -> bool:
        """
        Delete a rule.
        
        Args:
            rule_id: Rule ID to delete
            deleted_by: User who deleted the rule
            
        Returns:
            True if deletion successful, False otherwise
        """
        try:
            rule = Rule.query.get(rule_id)
            if not rule:
                logger.warning(f"Rule {rule_id} not found")
                return False
            
            rule_name = rule.name
            
            # Delete rule from database
            rule.delete()
            
            # Log rule deletion
            AuditLog.log_action(
                action=AuditAction.DELETE,
                resource_type="rule",
                description=f"Rule {rule_name} deleted",
                resource_id=rule_name,
                user_email=deleted_by
            )
            
            logger.info(f"Rule {rule_name} deleted successfully")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"Database error deleting rule {rule_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error deleting rule {rule_id}: {e}")
            return False
    
    @staticmethod
    def get_rule_by_name(name: str) -> Optional[Rule]:
        """
        Get a rule by name.
        
        Args:
            name: Rule name
            
        Returns:
            Rule object or None if not found
        """
        try:
            return Rule.query.filter_by(name=name).first()
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving rule {name}: {e}")
            return None
    
    @staticmethod
    def validate_rule_syntax(condition: str, action: str) -> Dict[str, Any]:
        """
        Validate rule syntax without creating a rule.
        
        Args:
            condition: Rule condition (Python expression)
            action: Rule action (Python expression)
            
        Returns:
            Dict containing validation results
        """
        errors = []
        
        # Check if condition is valid Python
        try:
            compile(condition, "<rule_condition>", 'eval')
        except SyntaxError as e:
            errors.append(f"Invalid condition syntax: {e}")
        
        # Check if action is valid Python
        try:
            compile(action, "<rule_action>", 'exec')
        except SyntaxError as e:
            errors.append(f"Invalid action syntax: {e}")
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors
        }
    
    @staticmethod
    def get_rules_summary() -> Dict[str, Any]:
        """
        Get a summary of all rules.
        
        Returns:
            Dict containing rule statistics
        """
        try:
            total_rules = Rule.query.count()
            active_rules = Rule.query.filter_by(status="active").count()
            inactive_rules = Rule.query.filter_by(status="inactive").count()
            draft_rules = Rule.query.filter_by(status="draft").count()
            
            # Group by type
            rule_types = {}
            for rule_type in ["risk_classification", "validation", "approval", "notification"]:
                count = Rule.query.filter_by(rule_type=rule_type).count()
                rule_types[rule_type] = count
            
            return {
                "total_rules": total_rules,
                "active_rules": active_rules,
                "inactive_rules": inactive_rules,
                "draft_rules": draft_rules,
                "by_type": rule_types
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting rules summary: {e}")
            return {}
    
    @staticmethod
    def reset_to_default_rules() -> bool:
        """
        Reset rules to default configuration.
        
        Returns:
            True if reset successful, False otherwise
        """
        try:
            # Delete all existing rules
            Rule.query.delete()
            
            # Create default rules
            default_rules = Rule.create_risk_classification_rules()
            
            for rule in default_rules:
                rule.save()
            
            # Log rule reset
            AuditLog.log_action(
                action=AuditAction.RULE_UPDATE,
                resource_type="rule",
                description="Rules reset to default configuration",
                user_email="system"
            )
            
            logger.info("Rules reset to default configuration successfully")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"Database error resetting rules: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error resetting rules: {e}")
            return False