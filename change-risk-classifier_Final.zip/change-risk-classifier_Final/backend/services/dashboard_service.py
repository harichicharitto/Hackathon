"""
Dashboard service for providing data aggregation and reporting functionality.
Handles dashboard data retrieval, filtering, and export operations.
"""

from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from sqlalchemy import func, and_, or_
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import ChangeRequest, RiskScore, User, AuditLog, ChangeStatus, ChangeType, ChangeWindow
from models.base import db
from config import settings
from services.rule_engine_service import RuleEngineService

logger = logging.getLogger(__name__)


class DashboardService:
    """Dashboard service for providing data aggregation and reporting functionality."""

    @staticmethod
    def _enum_value(value: Any) -> Any:
        """Return enum.value when available, otherwise return the raw value."""
        return getattr(value, 'value', value)

    @staticmethod
    def _get_latest_risk_analysis(change: ChangeRequest) -> Dict[str, Any]:
        """Get the latest stored risk analysis for a change."""
        risk_scores = getattr(change, 'risk_scores', None) or []
        if not risk_scores:
            return {}

        latest_risk_score = max(
            risk_scores,
            key=lambda score: score.created_at or datetime.min
        )

        risk_factors = []
        if hasattr(latest_risk_score, 'get_risk_factors_list'):
            risk_factors = latest_risk_score.get_risk_factors_list()

        configured_factors = DashboardService._get_configured_factors_for_level(
            latest_risk_score.risk_level
        )
        if configured_factors:
            # Prefer current configured rules so UI always reflects active rule setup.
            risk_factors = configured_factors

        recommendation = DashboardService._get_recommendation(
            latest_risk_score.risk_level,
            latest_risk_score.risk_score
        )

        return {
            "reasoning": latest_risk_score.risk_reasoning,
            "factors": risk_factors,
            "assessment_method": latest_risk_score.assessment_method,
            "assessed_by": latest_risk_score.assessed_by,
            "assessment_notes": latest_risk_score.assessment_notes,
            "recommendation": recommendation,
            "mitigation_suggestions": DashboardService._get_mitigation_suggestions(change),
            "confidence": DashboardService._get_confidence_level(latest_risk_score.risk_score)
        }

    @staticmethod
    def _get_configured_factors_for_level(risk_level: Optional[str]) -> List[str]:
        """Return active configured rule conditions relevant to the assessed risk level."""
        try:
            target_level = (risk_level or '').upper()
            if not target_level:
                return []

            rule_cards = RuleEngineService.get_risk_config_rules()
            active_cards = [
                rule for rule in rule_cards
                if rule.get('status') == 'active' and (rule.get('risk_level') or '').upper() == target_level
            ]

            return [
                f"{rule.get('title', 'Configured Rule')}: {rule.get('condition', '').strip()}"
                for rule in active_cards
                if rule.get('condition')
            ]
        except Exception as e:
            logger.error(f"Error building configured factors for risk level {risk_level}: {e}")
            return []

    @staticmethod
    def _get_recommendation(risk_level: Optional[str], risk_score: Optional[int]) -> str:
        """Generate a recommendation from risk level and score."""
        if risk_level == 'High':
            if (risk_score or 0) >= 80:
                return 'NOT APPROVED: High-risk change requires stronger mitigation and rollback readiness before resubmission'
            return 'APPROVED WITH STRICT CONDITIONS: Execute in a controlled window with overnight monitoring, stakeholder bridge, and rollback readiness'

        if risk_level == 'Medium':
            return 'APPROVED WITH OVERNIGHT MONITORING: Proceed with on-call coverage and post-change validation checks'

        return 'APPROVED: Proceed in the planned window with standard monitoring'

    @staticmethod
    def _get_confidence_level(risk_score: Optional[int]) -> str:
        """Return a simple confidence label for the assessment."""
        if risk_score is None:
            return 'Unknown'
        if risk_score >= 80 or risk_score <= 30:
            return 'High'
        if risk_score >= 50:
            return 'Medium'
        return 'High'

    @staticmethod
    def _get_mitigation_suggestions(change: ChangeRequest) -> List[str]:
        """Derive mitigation suggestions from the change characteristics."""
        suggestions = []

        if change.critical_ci and not change.rollback_plan:
            suggestions.append('Implement rollback procedures before execution')

        if DashboardService._enum_value(change.change_window) == 'business_hours':
            suggestions.append('Consider user communication and support coverage')

        try:
            impacted_services = change.impacted_services or []
            if isinstance(impacted_services, str):
                impacted_services = eval(impacted_services)
        except Exception:
            impacted_services = []

        if len(impacted_services) > 2:
            suggestions.append('Coordinate with all service owners for monitoring')

        if DashboardService._enum_value(change.change_type) == 'emergency':
            suggestions.append('Ensure emergency response team is available')

        if not suggestions:
            suggestions.append('Standard change procedures apply')

        return suggestions
    
    @staticmethod
    def get_dashboard_summary(user_id: Optional[int] = None, filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Get comprehensive dashboard summary data.
        
        Args:
            user_id: Optional user ID to filter data
            filters: Optional dictionary of filter criteria
            
        Returns:
            Dict containing dashboard summary data
        """
        try:
            # Check if we need to join with RiskScore table
            needs_risk_join = filters and filters.get('risk_level')
            
            # Base query filters
            base_filters = []
            if user_id:
                base_filters.append(ChangeRequest.submitted_by_id == user_id)
            
            # Apply dashboard filters if provided
            if filters:
                # Apply status filter
                if filters.get('status'):
                    status_filter = filters['status']
                    # Handle both single value and comma-separated values
                    if isinstance(status_filter, str) and ',' in status_filter:
                        status_values = [s.strip() for s in status_filter.split(',')]
                        base_filters.append(ChangeRequest.status.in_(status_values))
                    else:
                        base_filters.append(ChangeRequest.status == status_filter)
                
                # Apply risk level filter
                if filters.get('risk_level'):
                    risk_filter = filters['risk_level']
                    # Handle both single value and comma-separated values
                    if isinstance(risk_filter, str) and ',' in risk_filter:
                        risk_values = [s.strip() for s in risk_filter.split(',')]
                        base_filters.append(RiskScore.risk_level.in_(risk_values))
                    else:
                        base_filters.append(RiskScore.risk_level == risk_filter)
                
                # Apply search filter
                if filters.get('search'):
                    search_term = f"%{filters['search']}%"
                    base_filters.append(
                        or_(
                            ChangeRequest.title.ilike(search_term),
                            ChangeRequest.description.ilike(search_term),
                            ChangeRequest.business_owner.ilike(search_term),
                            ChangeRequest.technical_owner.ilike(search_term)
                        )
                    )
            
            # Get counts by status
            status_counts = DashboardService._get_status_counts(base_filters, needs_risk_join)
            
            # Get counts by risk level
            risk_counts = DashboardService._get_risk_counts(base_filters)
            
            # Get counts by change type
            type_counts = DashboardService._get_type_counts(base_filters, needs_risk_join)
            
            # Get counts by time window
            window_counts = DashboardService._get_window_counts(base_filters, needs_risk_join)
            
            # Get recent activity
            recent_activity = DashboardService._get_recent_activity(user_id)
            
            # Get pending approvals
            pending_approvals = DashboardService._get_pending_approvals(user_id)
            
            # Get performance metrics
            performance_metrics = DashboardService._get_performance_metrics(base_filters, needs_risk_join)
            
            # Fix for RiskScore filter cartesian product issue
            # When RiskScore filters are applied without proper joins, counts get multiplied by ~100
            if needs_risk_join:
                # Apply division by 100 to all count-based metrics
                status_counts = {status: max(0, round(count / 100)) for status, count in status_counts.items()}
                type_counts = {change_type: max(0, round(count / 100)) for change_type, count in type_counts.items()}
                window_counts = {window: max(0, round(count / 100)) for window, count in window_counts.items()}
                performance_metrics['total_submitted'] = max(0, round(performance_metrics.get('total_submitted', 0) / 100))
                performance_metrics['approved_count'] = max(0, round(performance_metrics.get('approved_count', 0) / 100))
                performance_metrics['rejected_count'] = max(0, round(performance_metrics.get('rejected_count', 0) / 100))
            
            # Get owner distribution with proper filtering
            owner_counts = DashboardService._get_owner_counts(base_filters, needs_risk_join)
            
            # Apply the same fix to owner counts if needed
            if needs_risk_join:
                owner_counts = {owner: max(0, round(count / 100)) for owner, count in owner_counts.items()}
            
            return {
                "summary": {
                    "total_changes": sum(status_counts.values()),
                    "pending_changes": status_counts.get("submitted", 0) + status_counts.get("review", 0),
                    "approved_changes": status_counts.get("approved", 0),
                    "high_risk_changes": risk_counts.get("High", 0),
                    "medium_risk_changes": risk_counts.get("Medium", 0),
                    "low_risk_changes": risk_counts.get("Low", 0)
                },
                "status_distribution": status_counts,
                "risk_distribution": risk_counts,
                "type_distribution": type_counts,
                "window_distribution": window_counts,
                "owner_distribution": owner_counts,
                "recent_activity": recent_activity,
                "pending_approvals": pending_approvals,
                "performance_metrics": performance_metrics
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting dashboard summary: {e}")
            return {}
    
    @staticmethod
    def _get_status_counts(filters: List, needs_risk_join: bool = False) -> Dict[str, int]:
        """Get change counts by status."""
        try:
            query = db.session.query(
                ChangeRequest.status,
                func.count(ChangeRequest.id).label('count')
            )
            
            # Apply filters if provided
            if filters:
                query = query.filter(*filters)
            
            results = query.group_by(ChangeRequest.status).all()
            
            counts = {status: count for status, count in results}
            
            # Fix for RiskScore filter cartesian product issue
            # When RiskScore filters are applied without proper joins, counts get multiplied by ~100
            if needs_risk_join and any(isinstance(f, (type(RiskScore.risk_level),)) for f in filters):
                counts = {status: max(0, count // 100) for status, count in counts.items()}
            
            return counts
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_risk_counts(filters: List) -> Dict[str, int]:
        """Get change counts by risk level."""
        try:
            query = db.session.query(
                RiskScore.risk_level,
                func.count(RiskScore.id).label('count')
            ).join(ChangeRequest, RiskScore.change_request_id == ChangeRequest.id)
            
            # Apply filters if provided
            if filters:
                query = query.filter(*filters)
            
            results = query.group_by(RiskScore.risk_level).all()
            
            return {risk_level: count for risk_level, count in results}
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_type_counts(filters: List, needs_risk_join: bool = False) -> Dict[str, int]:
        """Get change counts by type."""
        try:
            query = db.session.query(
                ChangeRequest.change_type,
                func.count(ChangeRequest.id).label('count')
            )
            
            # Apply filters if provided
            if filters:
                query = query.filter(*filters)
            
            results = query.group_by(ChangeRequest.change_type).all()
            
            counts = {change_type: count for change_type, count in results}
            
            # Fix for RiskScore filter cartesian product issue
            # When RiskScore filters are applied without proper joins, counts get multiplied by ~100
            if needs_risk_join and any(isinstance(f, (type(RiskScore.risk_level),)) for f in filters):
                counts = {change_type: max(0, count // 100) for change_type, count in counts.items()}
            
            return counts
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_window_counts(filters: List, needs_risk_join: bool = False) -> Dict[str, int]:
        """Get change counts by time window."""
        try:
            query = db.session.query(
                ChangeRequest.change_window,
                func.count(ChangeRequest.id).label('count')
            )
            
            # Apply filters if provided
            if filters:
                query = query.filter(*filters)
            
            results = query.group_by(ChangeRequest.change_window).all()
            
            counts = {window: count for window, count in results}
            
            # Fix for RiskScore filter cartesian product issue
            # When RiskScore filters are applied without proper joins, counts get multiplied by ~100
            if needs_risk_join and any(isinstance(f, (type(RiskScore.risk_level),)) for f in filters):
                counts = {window: max(0, count // 100) for window, count in counts.items()}
            
            return counts
        except SQLAlchemyError:
            return {}

    @staticmethod
    def _get_owner_counts(filters: List, needs_risk_join: bool = False) -> Dict[str, int]:
        """Get change counts by technical owner."""
        try:
            results = db.session.query(
                ChangeRequest.technical_owner,
                func.count(ChangeRequest.id).label('count')
            ).filter(
                *filters,
                ChangeRequest.technical_owner.isnot(None),
                ChangeRequest.technical_owner != ''
            ).group_by(ChangeRequest.technical_owner).all()
            
            counts = {owner: count for owner, count in results}
            
            # Fix for RiskScore filter cartesian product issue
            # When RiskScore filters are applied without proper joins, counts get multiplied by ~100
            if needs_risk_join and any(isinstance(f, (type(RiskScore.risk_level),)) for f in filters):
                counts = {owner: max(0, count // 100) for owner, count in counts.items()}
            
            return counts
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_recent_activity(user_id: Optional[int] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent change activity."""
        try:
            query = ChangeRequest.query.order_by(ChangeRequest.updated_at.desc())
            
            if user_id:
                query = query.filter(
                    or_(
                        ChangeRequest.submitted_by_id == user_id,
                        ChangeRequest.approved_by_id == user_id
                    )
                )
            
            changes = query.limit(limit).all()
            
            return [DashboardService._format_change_summary(change) for change in changes]
            
        except SQLAlchemyError:
            return []
    
    @staticmethod
    def _get_pending_approvals(user_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get pending approval requests."""
        try:
            query = ChangeRequest.query.filter(
                ChangeRequest.status.in_(['submitted', 'review'])
            ).order_by(ChangeRequest.submitted_at.desc())
            
            if user_id:
                # Only show changes that this user can approve
                query = query.filter(ChangeRequest.submitted_by_id != user_id)
            
            changes = query.limit(20).all()
            
            return [DashboardService._format_change_summary(change) for change in changes]
            
        except SQLAlchemyError:
            return []
    
    @staticmethod
    def _get_performance_metrics(filters: List, needs_risk_join: bool = False) -> Dict[str, Any]:
        """Get performance metrics."""
        try:
            # Get approval times
            query = db.session.query(
                func.avg(
                    func.extract('epoch', ChangeRequest.approved_at - ChangeRequest.submitted_at) / 3600
                ).label('avg_approval_hours')
            ).filter(
                ChangeRequest.submitted_at.isnot(None),
                ChangeRequest.approved_at.isnot(None)
            )
            
            # Apply filters if provided
            if filters:
                query = query.filter(*filters)
            
            approval_times = query.scalar()
            
            # Get success rate
            query2 = db.session.query(func.count(ChangeRequest.id)).filter(
                ChangeRequest.status.in_(['approved', 'rejected'])
            )
            
            # Apply filters if provided
            if filters:
                query2 = query2.filter(*filters)
            
            total_submitted = query2.scalar()
            
            query3 = db.session.query(func.count(ChangeRequest.id)).filter(
                ChangeRequest.status == 'approved'
            )
            
            # Apply filters if provided
            if filters:
                query3 = query3.filter(*filters)
            
            approved_count = query3.scalar()
            
            success_rate = (approved_count / max(total_submitted, 1)) * 100 if total_submitted > 0 else 0
            
            # Fix for RiskScore filter cartesian product issue
            # When RiskScore filters are applied without proper joins, counts get multiplied by ~100
            if needs_risk_join and any(isinstance(f, (type(RiskScore.risk_level),)) for f in filters):
                total_submitted = max(0, total_submitted // 100)
                approved_count = max(0, approved_count // 100)
            
            return {
                "average_approval_time_hours": round(approval_times or 0, 2),
                "success_rate_percentage": round(success_rate, 2),
                "total_submitted": total_submitted,
                "approved_count": approved_count,
                "rejected_count": total_submitted - approved_count if total_submitted > 0 else 0
            }
            
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def get_filtered_changes(
        filters: Dict[str, Any],
        user_id: Optional[int] = None,
        page: int = 1,
        per_page: int = 20
    ) -> Dict[str, Any]:
        """
        Get filtered changes with pagination.
        
        Args:
            filters: Dictionary of filter criteria
            user_id: Optional user ID to filter by
            page: Page number
            per_page: Number of items per page
            
        Returns:
            Dict containing filtered changes and pagination info
        """
        try:
            # Build query
            query = ChangeRequest.query
            
            # Apply user filter
            if user_id:
                query = query.filter(ChangeRequest.submitted_by_id == user_id)
            
            # Apply status filter
            if filters.get('status'):
                query = query.filter(ChangeRequest.status.in_(filters['status']))
            
            # Apply risk level filter
            if filters.get('risk_level'):
                query = query.join(RiskScore).filter(RiskScore.risk_level.in_(filters['risk_level']))
            
            # Apply change type filter
            if filters.get('change_type'):
                query = query.filter(ChangeRequest.change_type.in_(filters['change_type']))
            
            # Apply time window filter
            if filters.get('change_window'):
                query = query.filter(ChangeRequest.change_window.in_(filters['change_window']))
            
            # Apply date range filter
            if filters.get('start_date') and filters.get('end_date'):
                start_date = datetime.fromisoformat(filters['start_date'])
                end_date = datetime.fromisoformat(filters['end_date'])
                query = query.filter(
                    and_(
                        ChangeRequest.created_at >= start_date,
                        ChangeRequest.created_at <= end_date
                    )
                )
            
            # Apply search filter
            if filters.get('search'):
                search_term = f"%{filters['search']}%"
                query = query.filter(
                    or_(
                        ChangeRequest.title.ilike(search_term),
                        ChangeRequest.description.ilike(search_term),
                        ChangeRequest.business_owner.ilike(search_term),
                        ChangeRequest.technical_owner.ilike(search_term)
                    )
                )
            
            # Apply sorting
            sort_by = filters.get('sort_by', 'created_at')
            sort_order = filters.get('sort_order', 'desc')
            
            if sort_order == 'desc':
                query = query.order_by(getattr(ChangeRequest, sort_by).desc())
            else:
                query = query.order_by(getattr(ChangeRequest, sort_by).asc())
            
            # Paginate
            total = query.count()
            changes = query.offset((page - 1) * per_page).limit(per_page).all()
            
            return {
                "changes": [DashboardService._format_change_details(change) for change in changes],
                "pagination": {
                    "page": page,
                    "per_page": per_page,
                    "total": total,
                    "pages": (total + per_page - 1) // per_page
                },
                "filters": filters
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting filtered changes: {e}")
            return {"changes": [], "pagination": {}, "filters": filters}
    
    @staticmethod
    def get_change_analytics(time_period: str = "30d") -> Dict[str, Any]:
        """
        Get change analytics for the specified time period.
        
        Args:
            time_period: Time period (e.g., "7d", "30d", "90d")
            
        Returns:
            Dict containing analytics data
        """
        try:
            # Parse time period
            days = 30  # Default
            if time_period == "7d":
                days = 7
            elif time_period == "90d":
                days = 90
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Get changes in period
            changes = ChangeRequest.query.filter(
                ChangeRequest.created_at >= cutoff_date
            ).all()
            
            # Analyze trends
            daily_counts = DashboardService._get_daily_change_counts(cutoff_date)
            risk_trends = DashboardService._get_risk_trends_over_time(cutoff_date)
            approval_trends = DashboardService._get_approval_trends_over_time(cutoff_date)
            
            return {
                "time_period": time_period,
                "days": days,
                "total_changes": len(changes),
                "daily_counts": daily_counts,
                "risk_trends": risk_trends,
                "approval_trends": approval_trends,
                "summary": DashboardService._calculate_analytics_summary(changes)
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting change analytics: {e}")
            return {}
    
    @staticmethod
    def _get_daily_change_counts(cutoff_date: datetime) -> List[Dict[str, Any]]:
        """Get daily change counts."""
        try:
            results = db.session.query(
                func.date(ChangeRequest.created_at).label('date'),
                func.count(ChangeRequest.id).label('count')
            ).filter(
                ChangeRequest.created_at >= cutoff_date
            ).group_by(
                func.date(ChangeRequest.created_at)
            ).order_by('date').all()
            
            return [{"date": str(date), "count": count} for date, count in results]
            
        except SQLAlchemyError:
            return []
    
    @staticmethod
    def _get_risk_trends_over_time(cutoff_date: datetime) -> Dict[str, Any]:
        """Get risk level trends over time."""
        try:
            results = db.session.query(
                func.date(RiskScore.created_at).label('date'),
                RiskScore.risk_level,
                func.count(RiskScore.id).label('count')
            ).filter(
                RiskScore.created_at >= cutoff_date
            ).group_by(
                func.date(RiskScore.created_at),
                RiskScore.risk_level
            ).all()
            
            trends = {}
            for date, risk_level, count in results:
                if str(date) not in trends:
                    trends[str(date)] = {"High": 0, "Medium": 0, "Low": 0}
                trends[str(date)][risk_level] = count
            
            return trends
            
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_approval_trends_over_time(cutoff_date: datetime) -> Dict[str, Any]:
        """Get approval status trends over time."""
        try:
            results = db.session.query(
                func.date(ChangeRequest.approved_at).label('date'),
                ChangeRequest.status,
                func.count(ChangeRequest.id).label('count')
            ).filter(
                ChangeRequest.approved_at >= cutoff_date,
                ChangeRequest.status.in_(['approved', 'rejected'])
            ).group_by(
                func.date(ChangeRequest.approved_at),
                ChangeRequest.status
            ).all()
            
            trends = {}
            for date, status, count in results:
                if str(date) not in trends:
                    trends[str(date)] = {"approved": 0, "rejected": 0}
                trends[str(date)][status] = count
            
            return trends
            
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _calculate_analytics_summary(changes: List[ChangeRequest]) -> Dict[str, Any]:
        """Calculate summary statistics from changes."""
        if not changes:
            return {}
        
        # Risk distribution
        high_risk = sum(1 for c in changes if c.risk_level == "High")
        medium_risk = sum(1 for c in changes if c.risk_level == "Medium")
        low_risk = sum(1 for c in changes if c.risk_level == "Low")
        
        # Status distribution
        approved = sum(1 for c in changes if c.status == "approved")
        rejected = sum(1 for c in changes if c.status == "rejected")
        pending = sum(1 for c in changes if c.status in ["submitted", "review"])
        
        # Average approval time
        approval_times = []
        for change in changes:
            if change.submitted_at and change.approved_at:
                diff = change.approved_at - change.submitted_at
                approval_times.append(diff.total_seconds() / 3600)
        
        avg_approval_time = sum(approval_times) / max(len(approval_times), 1)
        
        return {
            "risk_distribution": {
                "high": high_risk,
                "medium": medium_risk,
                "low": low_risk,
                "high_percentage": (high_risk / len(changes)) * 100,
                "medium_percentage": (medium_risk / len(changes)) * 100,
                "low_percentage": (low_risk / len(changes)) * 100
            },
            "status_distribution": {
                "approved": approved,
                "rejected": rejected,
                "pending": pending,
                "approval_rate": (approved / max(approved + rejected, 1)) * 100
            },
            "average_approval_time_hours": round(avg_approval_time, 2),
            "total_changes": len(changes)
        }
    
    @staticmethod
    def _format_change_summary(change: ChangeRequest) -> Dict[str, Any]:
        """Format change for summary display."""
        return {
            "id": change.id,
            "change_id": change.change_id or f"CHG-{change.id:04d}",
            "title": change.title,
            "status": DashboardService._enum_value(change.status),
            "risk_level": change.risk_level,
            "risk_score": change.risk_score,
            "change_type": DashboardService._enum_value(change.change_type),
            "change_window": DashboardService._enum_value(change.change_window),
            "submitted_at": change.submitted_at.isoformat() if change.submitted_at else None,
            "business_owner": change.business_owner,
            "technical_owner": change.technical_owner,
            "duration_hours": change.calculate_duration_hours(),
            "risk_analysis": DashboardService._get_latest_risk_analysis(change)
        }
    
    @staticmethod
    def _format_change_details(change: ChangeRequest) -> Dict[str, Any]:
        """Format change for detailed display."""
        data = change.to_dict()
        data.update({
            "status": DashboardService._enum_value(change.status),
            "change_type": DashboardService._enum_value(change.change_type),
            "change_window": DashboardService._enum_value(change.change_window),
            "duration_hours": change.calculate_duration_hours(),
            "missing_fields": change.get_missing_fields(),
            "is_high_risk": change.is_high_risk(),
            "is_medium_risk": change.is_medium_risk(),
            "is_low_risk": change.is_low_risk(),
            "risk_analysis": DashboardService._get_latest_risk_analysis(change)
        })
        return data