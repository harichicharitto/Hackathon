#!/usr/bin/env python3
"""
Test script to verify the owner distribution fix for dashboard Risk level filters.
"""

import sys
import os

# Add the backend directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

try:
    from backend.services.dashboard_service import DashboardService
    from backend.app import create_app
    from backend.models import db

    app = create_app()
    with app.app_context():
        print("Testing owner distribution with Risk level filters...")
        
        # Test without filters (should show all owners)
        print("\n1. Testing without filters:")
        result = DashboardService.get_dashboard_summary()
        owner_dist = result.get('owner_distribution', {})
        print(f"   Total owners: {len(owner_dist)}")
        print(f"   Total changes by owners: {sum(owner_dist.values())}")
        print(f"   Sample owners: {dict(list(owner_dist.items())[:3])}")
        
        # Test with High risk filter
        print("\n2. Testing with High risk filter:")
        filters = {'risk_level': 'High'}
        result = DashboardService.get_dashboard_summary(filters=filters)
        owner_dist = result.get('owner_distribution', {})
        print(f"   Total owners: {len(owner_dist)}")
        print(f"   Total changes by owners: {sum(owner_dist.values())}")
        print(f"   Sample owners: {dict(list(owner_dist.items())[:3])}")
        
        # Test with Medium risk filter
        print("\n3. Testing with Medium risk filter:")
        filters = {'risk_level': 'Medium'}
        result = DashboardService.get_dashboard_summary(filters=filters)
        owner_dist = result.get('owner_distribution', {})
        print(f"   Total owners: {len(owner_dist)}")
        print(f"   Total changes by owners: {sum(owner_dist.values())}")
        print(f"   Sample owners: {dict(list(owner_dist.items())[:3])}")
        
        # Test with Low risk filter
        print("\n4. Testing with Low risk filter:")
        filters = {'risk_level': 'Low'}
        result = DashboardService.get_dashboard_summary(filters=filters)
        owner_dist = result.get('owner_distribution', {})
        print(f"   Total owners: {len(owner_dist)}")
        print(f"   Total changes by owners: {sum(owner_dist.values())}")
        print(f"   Sample owners: {dict(list(owner_dist.items())[:3])}")
        
        print("\nOwner distribution test completed successfully!")

except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()