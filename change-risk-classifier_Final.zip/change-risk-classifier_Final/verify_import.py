#!/usr/bin/env python3
"""
Verify Import Script

This script verifies that the 100 change requests were successfully imported
and are not being overridden by the application's sample data creation.
"""

import sqlite3
import json
from datetime import datetime

def connect_to_database(db_path):
    """Connect to the SQLite database."""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row  # This enables column access by name
        return conn
    except sqlite3.Error as e:
        print(f"Error connecting to database: {e}")
        return None

def verify_change_requests(conn):
    """Verify the change requests in the database."""
    try:
        cursor = conn.cursor()
        
        # Get total count
        cursor.execute("SELECT COUNT(*) FROM change_requests")
        total_count = cursor.fetchone()[0]
        
        print(f"📊 Total change requests: {total_count}")
        
        if total_count != 100:
            print(f"❌ Expected 100 records, but found {total_count}")
            return False
        
        # Get status distribution
        cursor.execute("SELECT status, COUNT(*) FROM change_requests GROUP BY status")
        status_counts = cursor.fetchall()
        
        print(f"📋 Status distribution:")
        for status, count in status_counts:
            print(f"   - {status}: {count}")
        
        # Get change type distribution
        cursor.execute("SELECT change_type, COUNT(*) FROM change_requests GROUP BY change_type")
        type_counts = cursor.fetchall()
        
        print(f"📋 Change type distribution:")
        for change_type, count in type_counts:
            print(f"   - {change_type}: {count}")
        
        # Get a sample of records
        cursor.execute("SELECT id, title, change_type, status, change_id FROM change_requests LIMIT 5")
        sample_records = cursor.fetchall()
        
        print(f"📋 Sample records:")
        for record in sample_records:
            print(f"   - ID: {record['id']}, Change ID: {record['change_id']}, Type: {record['change_type']}, Status: {record['status']}")
            print(f"     Title: {record['title'][:60]}...")
        
        # Check for risk scores
        cursor.execute("SELECT COUNT(*) FROM risk_scores")
        risk_score_count = cursor.fetchone()[0]
        
        print(f"📊 Total risk scores: {risk_score_count}")
        
        return True
        
    except sqlite3.Error as e:
        print(f"❌ Error verifying data: {e}")
        return False

def main():
    """Main function to run the verification."""
    print("🔍 Change Requests Verification Tool")
    print("=" * 40)
    
    # Database path
    db_path = "backend/instance/change_risk_classifier.db"
    
    # Connect to database
    conn = connect_to_database(db_path)
    if not conn:
        return
    
    try:
        # Verify data
        success = verify_change_requests(conn)
        
        if success:
            print(f"\n✅ Verification successful!")
            print(f"   The database contains 100 change requests as expected.")
            print(f"   The application should now use these records instead of sample data.")
            print(f"\n💡 To test the application:")
            print(f"   1. Set environment variable: FORCE_SAMPLE_DATA=false")
            print(f"   2. Run: python backend/app.py")
            print(f"   3. Visit: http://localhost:5000")
        else:
            print(f"\n❌ Verification failed!")
            print(f"   The database does not contain the expected 100 records.")
        
    finally:
        conn.close()

if __name__ == "__main__":
    main()