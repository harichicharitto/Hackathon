#!/usr/bin/env python3
"""
Final verification script to test the complete frontend parsing logic.
"""

import requests
import re

def test_frontend_parsing():
    """Test the complete frontend parsing logic with real data."""
    
    print("🔍 Final Verification: Frontend Parsing Logic")
    print("=" * 60)
    
    # Login to get token
    login_response = requests.post('http://localhost:5000/api/auth/login', 
        json={'username': 'admin', 'password': 'admin123'})
    
    if not login_response.ok:
        print("❌ Login failed")
        return False
    
    token = login_response.json()['access_token']
    headers = {'Authorization': f'Bearer {token}'}
    
    # Get Change 100
    change_response = requests.get('http://localhost:5000/api/changes/100', headers=headers)
    
    if not change_response.ok:
        print("❌ Failed to get change")
        return False
    
    change_data = change_response.json()
    
    print(f"📋 Change: {change_data.get('title')}")
    print(f"   Change ID: {change_data.get('id')}")
    print(f"   Risk Level: {change_data.get('risk_level')}")
    
    if not change_data.get('risk_scores'):
        print("❌ No risk scores found")
        return False
    
    risk_score = change_data['risk_scores'][0]
    full_reasoning = risk_score.get('risk_reasoning', '')
    
    print(f"   Risk Reasoning Length: {len(full_reasoning)} characters")
    print(f"   Has RECOMMENDATION marker: {'✅' if 'RECOMMENDATION:' in full_reasoning else '❌'}")
    
    # Simulate frontend parsing logic
    def getRiskReasoning(change):
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            if latestRisk.get('risk_reasoning'):
                reasoning = latestRisk['risk_reasoning']
                recommendationMatch = re.search(r'Recommendation:\s*(.+)', reasoning, re.IGNORECASE)
                if recommendationMatch:
                    return re.sub(r'Recommendation:\s*.+', '', reasoning, flags=re.IGNORECASE).strip()
                return reasoning
        return 'No model analysis available for this change.'

    def getRiskRecommendation(change):
        if 'risk_scores' in change and change['risk_scores']:
            latestRisk = change['risk_scores'][0]
            if latestRisk.get('recommendation'):
                fullText = latestRisk['recommendation']
                recommendationMatch = re.search(r'RECOMMENDATION:\s*(.+)', fullText, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
                return fullText
            elif latestRisk.get('risk_reasoning'):
                reasoning = latestRisk['risk_reasoning']
                recommendationMatch = re.search(r'Recommendation:\s*(.+)', reasoning, re.IGNORECASE)
                if recommendationMatch:
                    return recommendationMatch.group(1).strip()
        return 'No recommendation available for this assessment.'

    # Test parsing
    reasoning = getRiskReasoning(change_data)
    recommendation = getRiskRecommendation(change_data)
    
    print(f"\n🎯 Frontend Parsing Results:")
    print(f"   Analysis Basis: {'✅' if reasoning and reasoning != 'No model analysis available for this change.' else '❌'}")
    print(f"   Recommendation: {'✅' if recommendation and recommendation != 'No recommendation available for this assessment.' else '❌'}")
    
    if reasoning and reasoning != 'No model analysis available for this change.':
        print(f"\n📝 Analysis Basis Content:")
        print(f"   Preview: {repr(reasoning[:100] + '...' if len(reasoning) > 100 else reasoning)}")
        print(f"   Length: {len(reasoning)} characters")
    
    if recommendation and recommendation != 'No recommendation available for this assessment.':
        print(f"\n💡 Recommendation Content:")
        print(f"   Preview: {repr(recommendation[:100] + '...' if len(recommendation) > 100 else recommendation)}")
        print(f"   Length: {len(recommendation)} characters")
    
    # Verify separation
    if reasoning and recommendation:
        print(f"\n✅ SUCCESS: Content properly separated!")
        print(f"   Analysis Basis: {len(reasoning)} chars")
        print(f"   Recommendation: {len(recommendation)} chars")
        print(f"   Total: {len(reasoning) + len(recommendation)} chars")
        print(f"   Original: {len(full_reasoning)} chars")
        
        # Check if they add up (approximately, accounting for removed markers)
        total_parsed = len(reasoning) + len(recommendation)
        if abs(total_parsed - len(full_reasoning)) <= 20:  # Allow for removed "RECOMMENDATION:" marker
            print("   ✅ Lengths match (within expected range)")
        else:
            print("   ⚠️  Length mismatch - may need adjustment")
    else:
        print(f"\n❌ FAILED: Could not separate content")
    
    return True

if __name__ == '__main__':
    test_frontend_parsing()