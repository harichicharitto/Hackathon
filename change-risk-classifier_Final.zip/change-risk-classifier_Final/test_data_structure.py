#!/usr/bin/env python3
"""
Test the data structure returned by the dashboard service
"""

import os
import sys

# Set environment
os.environ['FORCE_SAMPLE_DATA'] = 'false'
sys.path.insert(0, 'backend')

from app import create_app
app = create_app()

with app.app_context():
    from services.dashboard_service import DashboardService
    
    # Test with no pagination parameters (like the frontend)
    result = DashboardService.get_filtered_changes({}, None, 1, 20)
    print(f'With default pagination: {len(result.get("changes", []))} changes')
    print(f'Total count: {result.get("pagination", {}).get("total", 0)}')
    
    # Check the actual data structure
    changes = result.get('changes', [])
    print(f'\nFirst change structure:')
    if changes:
        first_change = changes[0]
        print(f'  Keys: {list(first_change.keys())}')
        print(f'  ID: {first_change.get("id")}')
        print(f'  Title: {first_change.get("title")}')
        print(f'  Risk Level: {first_change.get("risk_level")}')