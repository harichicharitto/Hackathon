// Change Risk Classifier Frontend Application
class ChangeRiskApp {
    constructor() {
        this.token = localStorage.getItem('token');
        this.currentUser = null;
        this.changes = [];
        this.rules = [];
        
        this.init();
    }

    async init() {
        this.setupEventListeners();
        
        if (this.token) {
            const isValid = await this.validateToken();
            if (isValid) {
                await this.loadDashboard();
                this.showPage('dashboard-page');
            } else {
                this.showPage('login-page');
            }
        } else {
            this.showPage('login-page');
        }
    }

    setupEventListeners() {
        // Login Form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Navigation
        document.querySelectorAll('.nav-item[data-view]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const view = e.target.getAttribute('data-view');
                this.switchView(view);
            });
        });

        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }

        // Change Form
        const changeForm = document.getElementById('change-form');
        if (changeForm) {
            changeForm.addEventListener('submit', (e) => this.handleCreateChange(e));
        }

        // Preview Risk
        const previewBtn = document.getElementById('preview-risk-btn');
        if (previewBtn) {
            previewBtn.addEventListener('click', () => this.previewRisk());
        }

        // Filters
        const statusFilter = document.getElementById('status-filter');
        const riskFilter = document.getElementById('risk-filter');
        const searchInput = document.getElementById('search-input');
        
        if (statusFilter) statusFilter.addEventListener('change', () => this.filterChanges());
        if (riskFilter) riskFilter.addEventListener('change', () => this.filterChanges());
        if (searchInput) searchInput.addEventListener('input', () => this.filterChanges());

        // Export buttons
        const exportChangesBtn = document.getElementById('export-changes-btn');
        const exportDashboardBtn = document.getElementById('export-dashboard-btn');
        
        if (exportChangesBtn) exportChangesBtn.addEventListener('click', () => this.exportChanges());
        if (exportDashboardBtn) exportDashboardBtn.addEventListener('click', () => this.exportDashboard());
    }

    async handleLogin(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('login-error');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
                this.token = data.access_token;
                localStorage.setItem('token', this.token);
                this.currentUser = data.user;
                
                this.updateUserInfo();
                await this.loadDashboard();
                this.showPage('dashboard-page');
            } else {
                errorDiv.style.display = 'block';
                errorDiv.textContent = data.error || 'Login failed';
            }
        } catch (error) {
            errorDiv.style.display = 'block';
            errorDiv.textContent = 'Network error. Please try again.';
        }
    }

    async validateToken() {
        try {
            const response = await fetch('/api/auth/validate', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.currentUser = data;
                return true;
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    updateUserInfo() {
        const userNameEl = document.getElementById('current-user-name');
        const userRoleEl = document.getElementById('current-user-role');
        
        if (userNameEl && userRoleEl && this.currentUser) {
            userNameEl.textContent = this.currentUser.username;
            userRoleEl.textContent = this.currentUser.role.toUpperCase();
            userRoleEl.className = `role-badge role-${this.currentUser.role}`;
        }
    }

    showPage(pageId) {
        document.querySelectorAll('.page').forEach(page => {
            page.classList.remove('active');
        });
        
        const page = document.getElementById(pageId);
        if (page) {
            page.classList.add('active');
        }
    }

    switchView(viewName) {
        // Update active navigation
        document.querySelectorAll('.nav-item').forEach(link => {
            link.classList.remove('active');
        });
        
        const activeLink = document.querySelector(`.nav-item[data-view="${viewName}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        // Show/hide views
        document.querySelectorAll('.view').forEach(view => {
            view.classList.remove('active');
        });
        
        const view = document.getElementById(`${viewName}-view`);
        if (view) {
            view.classList.add('active');
        }

        // Load data for specific views
        switch(viewName) {
            case 'changes':
                this.loadChanges();
                break;
            case 'rules':
                this.loadRules();
                break;
            case 'users':
                this.loadUsers();
                break;
        }
    }

    async loadDashboard() {
        try {
            const [changesResponse, statsResponse] = await Promise.all([
                fetch('/api/changes', {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                }),
                fetch('/api/dashboard/summary', {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                })
            ]);

            if (changesResponse.ok && statsResponse.ok) {
                this.changes = await changesResponse.json();
                const stats = await statsResponse.json();
                
                this.updateDashboardStats(stats);
                this.renderRecentChanges(this.changes.slice(0, 5));
                this.renderRiskChart(stats);
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
        }
    }

    updateDashboardStats(stats) {
        document.getElementById('total-changes').textContent = stats.total_changes || 0;
        document.getElementById('high-risk-count').textContent = stats.high_risk_count || 0;
        document.getElementById('medium-risk-count').textContent = stats.medium_risk_count || 0;
        document.getElementById('low-risk-count').textContent = stats.low_risk_count || 0;
    }

    renderRecentChanges(changes) {
        const container = document.getElementById('recent-changes-list');
        container.innerHTML = '';

        changes.forEach(change => {
            const div = document.createElement('div');
            div.className = 'change-item';
            div.innerHTML = `
                <div>
                    <div class="change-title">${change.title}</div>
                    <div class="change-meta">${change.change_type} • ${change.status} • ${new Date(change.created_at).toLocaleDateString()}</div>
                </div>
                <span class="change-risk risk-${change.risk_level.toLowerCase()}">${change.risk_level}</span>
            `;
            container.appendChild(div);
        });
    }

    renderRiskChart(stats) {
        const ctx = document.getElementById('risk-chart').getContext('2d');
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['High Risk', 'Medium Risk', 'Low Risk'],
                datasets: [{
                    data: [
                        stats.high_risk_count || 0,
                        stats.medium_risk_count || 0,
                        stats.low_risk_count || 0
                    ],
                    backgroundColor: ['#ff4757', '#ffa502', '#2ed573'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    async loadChanges() {
        try {
            const response = await fetch('/api/changes', {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                this.changes = await response.json();
                this.renderChangesTable(this.changes);
            }
        } catch (error) {
            console.error('Error loading changes:', error);
        }
    }

    renderChangesTable(changes) {
        const tbody = document.getElementById('changes-tbody');
        tbody.innerHTML = '';

        changes.forEach(change => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${change.id}</td>
                <td>${change.title}</td>
                <td><span class="status-badge status-${change.status}">${change.status}</span></td>
                <td><span class="change-risk risk-${change.risk_level.toLowerCase()}">${change.risk_level}</span></td>
                <td>${new Date(change.created_at).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-secondary" onclick="app.viewChange(${change.id})">View</button>
                    ${this.currentUser.is_admin ? `<button class="btn btn-primary" onclick="app.approveChange(${change.id})">Approve</button>` : ''}
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    filterChanges() {
        const status = document.getElementById('status-filter').value;
        const risk = document.getElementById('risk-filter').value;
        const search = document.getElementById('search-input').value.toLowerCase();

        let filtered = this.changes;

        if (status) {
            filtered = filtered.filter(c => c.status === status);
        }

        if (risk) {
            filtered = filtered.filter(c => c.risk_level === risk);
        }

        if (search) {
            filtered = filtered.filter(c => 
                c.title.toLowerCase().includes(search) ||
                c.description.toLowerCase().includes(search)
            );
        }

        this.renderChangesTable(filtered);
    }

    async previewRisk() {
        const formData = new FormData(document.getElementById('change-form'));
        const data = Object.fromEntries(formData);

        try {
            const response = await fetch('/api/rules/evaluate', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    context: {
                        change_type: data.change_type,
                        change_window: data.change_window,
                        critical_ci: data.critical_ci === 'true',
                        impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
                        rollback_plan: data.rollback_plan === 'true',
                        business_owner: data.business_owner,
                        technical_owner: data.technical_owner
                    }
                })
            });

            const result = await response.json();
            
            const previewDiv = document.getElementById('risk-preview');
            const resultDiv = document.getElementById('risk-result');
            
            previewDiv.style.display = 'block';
            
            if (result.results && result.results.length > 0) {
                const risk = result.results[0];
                resultDiv.innerHTML = `
                    <h4>Risk Assessment Result</h4>
                    <p><strong>Risk Level:</strong> <span class="change-risk risk-${risk.risk_level.toLowerCase()}">${risk.risk_level}</span></p>
                    <p><strong>Risk Score:</strong> ${risk.risk_score}</p>
                    <p><strong>Reason:</strong> ${risk.reason}</p>
                `;
            } else {
                resultDiv.innerHTML = '<p>No risk assessment available. Please check your inputs.</p>';
            }
        } catch (error) {
            console.error('Error previewing risk:', error);
        }
    }

    async handleCreateChange(e) {
        e.preventDefault();
        
        const formData = new FormData(document.getElementById('change-form'));
        const data = Object.fromEntries(formData);

        const changeData = {
            title: data.title,
            description: data.description,
            change_type: data.change_type,
            change_window: data.change_window,
            critical_ci: data.critical_ci === 'true',
            impacted_services: data.impacted_services ? data.impacted_services.split(',').map(s => s.trim()) : [],
            rollback_plan: data.rollback_plan === 'true',
            business_owner: data.business_owner,
            technical_owner: data.technical_owner
        };

        try {
            const response = await fetch('/api/changes', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(changeData)
            });

            const result = await response.json();

            if (response.ok) {
                alert('Change request created successfully!');
                document.getElementById('change-form').reset();
                document.getElementById('risk-preview').style.display = 'none';
                this.loadDashboard();
                this.switchView('changes');
            } else {
                alert('Error creating change: ' + result.error);
            }
        } catch (error) {
            console.error('Error creating change:', error);
        }
    }

    async viewChange(changeId) {
        try {
            const response = await fetch(`/api/changes/${changeId}`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });

            if (response.ok) {
                const change = await response.json();
                this.showChangeModal(change);
            }
        } catch (error) {
            console.error('Error viewing change:', error);
        }
    }

    showChangeModal(change) {
        const modal = document.getElementById('change-modal');
        const content = document.getElementById('change-details-content');
        
        content.innerHTML = `
            <div class="change-detail-item">
                <strong>Title:</strong> ${change.title}
            </div>
            <div class="change-detail-item">
                <strong>Description:</strong> ${change.description}
            </div>
            <div class="change-detail-item">
                <strong>Type:</strong> ${change.change_type}
            </div>
            <div class="change-detail-item">
                <strong>Window:</strong> ${change.change_window}
            </div>
            <div class="change-detail-item">
                <strong>Critical CI:</strong> ${change.critical_ci ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Impacted Services:</strong> ${change.impacted_services.join(', ')}
            </div>
            <div class="change-detail-item">
                <strong>Rollback Plan:</strong> ${change.rollback_plan ? 'Yes' : 'No'}
            </div>
            <div class="change-detail-item">
                <strong>Business Owner:</strong> ${change.business_owner}
            </div>
            <div class="change-detail-item">
                <strong>Technical Owner:</strong> ${change.technical_owner}
            </div>
            <div class="change-detail-item">
                <strong>Status:</strong> <span class="status-badge status-${change.status}">${change.status}</span>
            </div>
            <div class="change-detail-item">
                <strong>Risk Level:</strong> <span class="change-risk risk-${change.risk_level.toLowerCase()}">${change.risk_level}</span>
            </div>
            <div class="change-detail-item">
                <strong>Created:</strong> ${new Date(change.created_at).toLocaleString()}
            </div>
        `;

        modal.style.display = 'block';

        // Close modal functionality
        const closeBtn = document.querySelector('.close');
        closeBtn.onclick = () => modal.style.display = 'none';
        
        window.onclick = (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        };
    }

    async approveChange(changeId) {
        if (!confirm('Are you sure you want to approve this change?')) {
            return;
        }

        try {
            const response = await fetch(`/api/changes/${changeId}/approve`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                alert('Change approved successfully!');
                this.loadChanges();
            } else {
                alert('Error approving change');
            }
        } catch (error) {
            console.error('Error approving change:', error);
        }
    }

    async exportChanges() {
        const format = document.querySelector('input[name="export-format"]:checked').value;
        const filters = Array.from(document.querySelectorAll('input[type="checkbox"]:checked')).map(cb => cb.value);

        try {
            const response = await fetch('/api/export/changes/' + format, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `changes_export_${new Date().toISOString().slice(0, 10)}.${format}`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Error exporting changes:', error);
        }
    }

    async exportDashboard() {
        const timePeriod = document.getElementById('dashboard-time-period').value;

        try {
            const response = await fetch(`/api/export/dashboard-summary/csv?time_period=${timePeriod}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `dashboard_summary_${timePeriod}.csv`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error('Error exporting dashboard:', error);
        }
    }

    logout() {
        localStorage.removeItem('token');
        this.token = null;
        this.currentUser = null;
        this.showPage('login-page');
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ChangeRiskApp();
});