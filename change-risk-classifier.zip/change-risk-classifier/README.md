# Change Request Risk Classification & Approval Assistant

A production-grade rule-based system that classifies IT change requests into Low, Medium, and High risk categories, provides an approval dashboard, and generates all SDLC deliverables using AI models.

## 🎯 Project Overview

This system streamlines IT change management by automatically classifying change requests based on infrastructure impact and timing, enabling faster approvals and reducing failed changes.

## 🏗️ Architecture

### Backend (Python/Flask)
- **Auth Service**: User authentication and role management
- **Rule Engine**: Core risk classification logic
- **Risk Classifier**: Implements business rules for risk assessment
- **Dashboard API**: RESTful endpoints for frontend integration
- **Export Service**: CSV/PDF generation for CAB review packs

### Frontend (React)
- **Login Screen**: Administrator and Change Manager roles
- **Change Entry Form**: Manual change request submission
- **Dashboard**: Risk-based filtering and summary views
- **Rule Configuration**: Administrator panel for rule management

### Database (PostgreSQL/SQLite)
- Users, ChangeRequests, Rules, RiskScores tables
- RDBMS-based storage for production reliability

## 🧠 AI Model Strategy

### Rule Engine & Logic
- **Primary**: azure_ai/genailab-maas-DeepSeek-R1
- **Secondary**: azure_ai/genailab-maas-Phi-4-reasoning

### Documentation & Architecture
- **Primary**: azure/genailab-maas-gpt-4.1
- **Secondary**: genailab-maas-gpt-4o

### Code Generation
- **Primary**: azure_ai/genailab-maas-Llama-3.3-70B-Instruct
- **Secondary**: azure_ai/genailab-maas-Llama-4-Maverick-17B

### Fast Iterations
- azure/genailab-maas-gpt-4.1-mini
- azure/genailab-maas-gpt-4.1-nano

## 📋 Risk Classification Rules

### High Risk
- Critical CI + business hours + multiple systems + no rollback plan

### Medium Risk
- Non-critical CI + limited blast radius + rollback available

### Low Risk
- Standard change + approved window + single system

## 🚀 Quick Start

1. **Setup Backend**
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # or venv\Scripts\activate  # Windows
   pip install -r requirements.txt
   python app.py
   ```

2. **Setup Frontend**
   ```bash
   cd frontend
   npm install
   npm start
   ```

3. **Access Application**
   - Backend API: http://localhost:5000
   - Frontend UI: http://localhost:3000

## 📦 Deliverables

1. ✅ Functional Requirements Document
2. ✅ Application Architecture Documentation
3. ✅ Technical Architecture (stack + AI components)
4. ✅ Database Design (Logical + Physical models)
5. ✅ UI/UX Wireframes
6. ✅ Working Software
7. ✅ Functional Test Cases (CSV)
8. ✅ Traceability Matrix (CSV)
9. ✅ End User Manual
10. ✅ AI Agent: Code Quality Checker

## 🔧 Technology Stack

### Backend
- Python 3.10+
- Flask/FastAPI
- SQLAlchemy (ORM)
- PostgreSQL/SQLite
- JWT Authentication

### Frontend
- React 18
- React Router
- Bootstrap/Tailwind CSS
- Axios for API calls

### AI Components
- Multiple LLM models for different tasks
- Embedding models for semantic search
- Code quality analysis agents

## 📁 Project Structure

```
change-risk-classifier/
├── backend/           # Flask API server
├── frontend/          # React application
├── docs/             # Documentation and deliverables
├── tests/            # Test cases and validation
├── agents/           # AI agents and tools
└── README.md         # This file
```

## 🎯 Key Features

- **Rule-Based Classification**: No advanced analytics required
- **Multi-Role Support**: Administrator and Change Manager roles
- **Export Capabilities**: CSV/PDF for CAB review packs
- **Missing Field Detection**: Flags incomplete change requests
- **Risk Scoring**: Quantitative risk assessment
- **Approval Workflow**: Streamlined change approval process

## 📊 Dashboard Features

- Changes by risk category
- Filter by time window and owner
- Summary totals and trends
- Export functionality
- Real-time risk classification

## 🔐 Security Features

- Role-based access control
- JWT authentication
- Input validation and sanitization
- Secure password storage
- Audit logging

## 🤖 AI Integration

- **Code Quality Checker**: Validates code against best practices
- **Documentation Generation**: AI-powered requirement and design docs
- **Test Case Generation**: Automated test script creation
- **Risk Analysis**: Enhanced risk assessment with AI insights

## 📈 Production Readiness

- Clean architecture (MVC pattern)
- Proper error handling and logging
- Database migrations support
- API documentation (Swagger/OpenAPI)
- Unit and integration tests
- Docker support for containerization

## 🎨 UI/UX Design

- User-centric interface design
- Responsive layout for all devices
- Intuitive navigation and workflows
- Professional appearance suitable for enterprise use
- Accessibility compliance

## 📋 Compliance & Standards

- Follows ITIL change management best practices
- Enterprise-grade security standards
- Production-level code quality
- Comprehensive documentation
- Industry-standard architecture patterns

## 🚀 Deployment

The system is designed for easy deployment in enterprise environments with support for:

- Container deployment (Docker)
- Cloud platforms (AWS, Azure, GCP)
- On-premise installations
- Scalable architecture for growth

## 📞 Support

For questions, issues, or contributions, please refer to the project documentation in the `/docs` directory.