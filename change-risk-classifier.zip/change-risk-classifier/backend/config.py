"""
Configuration module for the Change Risk Classifier application.
Handles environment variables, database settings, and AI model configurations.
"""

import os
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Application
    app_name: str = "Change Risk Classifier"
    debug: bool = Field(default=False, env="DEBUG")
    environment: str = Field(default="development", env="ENVIRONMENT")
    
    # Database
    database_url: str = Field(
        default="sqlite:///./change_risk_classifier.db",
        env="DATABASE_URL"
    )
    database_echo: bool = Field(default=False, env="DATABASE_ECHO")
    
    # Authentication
    secret_key: str = Field(
        default="your-secret-key-change-in-production",
        env="SECRET_KEY"
    )
    jwt_algorithm: str = Field(default="HS256", env="JWT_ALGORITHM")
    jwt_expiration_minutes: int = Field(default=1440, env="JWT_EXPIRATION_MINUTES")  # 24 hours
    
    # AI Models Configuration
    # Rule Engine & Logic Models
    rule_engine_model: str = Field(
        default="azure_ai/genailab-maas-DeepSeek-R1",
        env="RULE_ENGINE_MODEL"
    )
    reasoning_model: str = Field(
        default="azure_ai/genailab-maas-Phi-4-reasoning",
        env="REASONING_MODEL"
    )
    
    # Documentation & Architecture Models
    documentation_model: str = Field(
        default="azure/genailab-maas-gpt-4.1",
        env="DOCUMENTATION_MODEL"
    )
    architecture_model: str = Field(
        default="genailab-maas-gpt-4o",
        env="ARCHITECTURE_MODEL"
    )
    
    # Code Generation Models
    code_generation_model: str = Field(
        default="azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
        env="CODE_GENERATION_MODEL"
    )
    code_secondary_model: str = Field(
        default="azure_ai/genailab-maas-Llama-4-Maverick-17B",
        env="CODE_SECONDARY_MODEL"
    )
    
    # Fast Iteration Models
    fast_generation_model: str = Field(
        default="azure/genailab-maas-gpt-4.1-mini",
        env="FAST_GENERATION_MODEL"
    )
    nano_generation_model: str = Field(
        default="azure/genailab-maas-gpt-4.1-nano",
        env="NANO_GENERATION_MODEL"
    )
    
    # Vision Models
    vision_model: str = Field(
        default="azure_ai/genailab-maas-Llama-3.2-90B-Vision-Instruct",
        env="VISION_MODEL"
    )
    
    # Embeddings
    embedding_model: str = Field(
        default="azure/genailab-maas-text-embedding-3-large",
        env="EMBEDDING_MODEL"
    )
    
    # Audio (Optional)
    audio_model: str = Field(
        default="azure/genailab-maas-whisper",
        env="AUDIO_MODEL"
    )
    
    # API Keys (for external AI services)
    openai_api_key: Optional[str] = Field(default=None, env="OPENAI_API_KEY")
    azure_openai_endpoint: Optional[str] = Field(default=None, env="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_key: Optional[str] = Field(default=None, env="AZURE_OPENAI_API_KEY")
    
    # Export Settings
    export_formats: list = ["csv", "pdf", "xlsx"]
    max_export_records: int = 10000
    
    # Logging
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Initialize settings
settings = Settings()


def get_database_config():
    """Get database configuration based on environment."""
    if settings.environment == "production":
        # Use PostgreSQL in production
        if not settings.database_url.startswith("postgresql"):
            raise ValueError("Production environment requires PostgreSQL database")
    else:
        # Use SQLite for development and testing
        if settings.database_url.startswith("postgresql"):
            print("Warning: Using PostgreSQL in non-production environment")
    
    return {
        "url": settings.database_url,
        "echo": settings.database_echo,
        "pool_size": 20 if settings.environment == "production" else 5,
        "max_overflow": 30 if settings.environment == "production" else 10,
    }


def get_ai_model_config():
    """Get AI model configuration."""
    return {
        "rule_engine": settings.rule_engine_model,
        "reasoning": settings.reasoning_model,
        "documentation": settings.documentation_model,
        "architecture": settings.architecture_model,
        "code_generation": settings.code_generation_model,
        "code_secondary": settings.code_secondary_model,
        "fast_generation": settings.fast_generation_model,
        "nano_generation": settings.nano_generation_model,
        "vision": settings.vision_model,
        "embedding": settings.embedding_model,
        "audio": settings.audio_model,
    }


def validate_config():
    """Validate configuration settings."""
    errors = []
    
    # Validate database URL
    if not settings.database_url:
        errors.append("DATABASE_URL is required")
    
    # Validate secret key in production
    if settings.environment == "production":
        if settings.secret_key == "your-secret-key-change-in-production":
            errors.append("SECRET_KEY must be changed in production")
        if len(settings.secret_key) < 32:
            errors.append("SECRET_KEY must be at least 32 characters long")
    
    # Validate JWT settings
    if settings.jwt_expiration_minutes < 1:
        errors.append("JWT_EXPIRATION_MINUTES must be greater than 0")
    
    if errors:
        raise ValueError(f"Configuration validation failed: {'; '.join(errors)}")
    
    return True


# Validate configuration on import
try:
    validate_config()
except ValueError as e:
    print(f"Configuration Error: {e}")
    raise