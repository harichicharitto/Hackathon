"""
AI Risk Analysis service for using AI models to analyze change requests.
Provides AI-powered risk assessment and recommendations.
"""

from typing import Dict, Any, Optional, List
import logging
import json
import httpx
from langchain_openai import ChatOpenAI

logger = logging.getLogger(__name__)


class AIRiskService:
    """AI Risk Analysis service for using AI models to analyze change requests."""
    
    def __init__(self):
        """Initialize the AI Risk Service with the configured model."""
        try:
            # Configure HTTP client with SSL verification disabled
            client = httpx.Client(verify=False, timeout=30.0)
            
            # Initialize the AI model
            self.llm = ChatOpenAI(
                base_url="https://genailab.tcs.in",
                model="azure_ai/genailab-maas-DeepSeek-V3-0324",
                api_key="sk-aVZ4O8h_u71vRIJpQWh5Dg",
                http_client=client,
                temperature=0.3  # Lower temperature for more consistent, deterministic responses
            )
            logger.info("AI Risk Service initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize AI Risk Service: {e}. Using rule-based fallback.")
            self.llm = None
    
    def analyze_risk_with_ai(self, change_context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze risk using AI model based on change context.
        
        Args:
            change_context: Dictionary containing change request context
            
        Returns:
            Dict containing AI analysis results
        """
        if not self.llm:
            logger.error("AI model not initialized, falling back to rule-based analysis")
            return self._fallback_risk_analysis(change_context)
        
        try:
            # Prepare the prompt for the AI model
            prompt = self._create_risk_analysis_prompt(change_context)
            
            # Get AI response
            response = self.llm.invoke(prompt)
            ai_response = response.content
            
            # Parse and validate AI response
            result = self._parse_ai_response(ai_response, change_context)
            
            logger.info(f"AI risk analysis completed for change: {change_context.get('title', 'Unknown')}")
            return result
            
        except Exception as e:
            logger.error(f"Error in AI risk analysis: {e}")
            return self._fallback_risk_analysis(change_context)
    
    def _create_risk_analysis_prompt(self, change_context: Dict[str, Any]) -> str:
        """Create a prompt for the AI model to analyze risk."""
        impacted_services = change_context.get('impacted_services', [])
        if isinstance(impacted_services, list):
            services_str = ", ".join(impacted_services)
        else:
            services_str = str(impacted_services)
        
        prompt = f"""
        Analyze the risk level for this change request and provide a detailed assessment.

        Change Request Details:
        - Title: {change_context.get('title', 'N/A')}
        - Description: {change_context.get('description', 'N/A')}
        - Change Type: {change_context.get('change_type', 'N/A')}
        - Change Window: {change_context.get('change_window', 'N/A')}
        - Critical CI: {change_context.get('critical_ci', False)}
        - Impacted Services: {services_str}
        - Rollback Plan: {change_context.get('rollback_plan', False)}
        - Business Owner: {change_context.get('business_owner', 'N/A')}
        - Technical Owner: {change_context.get('technical_owner', 'N/A')}

        Business Rules for Risk Assessment:
        1. HIGH RISK: Critical CI + business hours + multiple systems + no rollback plan
        2. MEDIUM RISK: Non-critical CI + limited blast radius + rollback available
        3. LOW RISK: Standard change + approved window + single system

        Please provide your analysis in the following JSON format:
        {{
            "risk_level": "High|Medium|Low",
            "risk_score": 0-100,
            "reason": "Detailed explanation of risk assessment",
            "impact_factors": ["List of specific risk factors"],
            "recommendation": "Specific recommendation for this change",
            "mitigation_suggestions": ["List of suggested mitigations"]
        }}

        Be thorough in your analysis and consider all relevant factors.
        """
        return prompt
    
    def _parse_ai_response(self, ai_response: str, change_context: Dict[str, Any]) -> Dict[str, Any]:
        """Parse and validate the AI response."""
        try:
            # Try to extract JSON from the response
            import re
            
            # Look for JSON pattern in the response
            json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                result = json.loads(json_str)
            else:
                # If no JSON found, try to parse the whole response
                result = json.loads(ai_response)
            
            # Validate required fields
            required_fields = ['risk_level', 'risk_score', 'reason', 'recommendation']
            for field in required_fields:
                if field not in result:
                    raise ValueError(f"Missing required field: {field}")
            
            # Validate risk_level
            valid_levels = ['High', 'Medium', 'Low']
            if result['risk_level'] not in valid_levels:
                raise ValueError(f"Invalid risk level: {result['risk_level']}")
            
            # Validate risk_score
            if not isinstance(result['risk_score'], (int, float)) or not (0 <= result['risk_score'] <= 100):
                raise ValueError(f"Invalid risk score: {result['risk_score']}")
            
            # Add additional context
            result['change_title'] = change_context.get('title', 'Unknown')
            result['analysis_method'] = 'AI-powered'
            result['confidence'] = 'High'  # AI model provides high confidence
            
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse AI response as JSON: {e}")
            return self._fallback_risk_analysis(change_context)
        except Exception as e:
            logger.error(f"Error validating AI response: {e}")
            return self._fallback_risk_analysis(change_context)
    
    def _fallback_risk_analysis(self, change_context: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback to rule-based risk analysis if AI fails."""
        logger.warning("Using fallback rule-based risk analysis")
        
        # Use the existing rule-based logic as fallback
        base_score = 0
        reason_parts = []
        risk_level = "Low"
        
        # Rule 1: High Risk - Critical CI + business hours + multiple systems + no rollback plan
        if (change_context.get('critical_ci', False) and 
            change_context.get('change_window') == 'business_hours' and 
            len(change_context.get('impacted_services', [])) > 2 and 
            not change_context.get('rollback_plan', False)):
            base_score = 85
            risk_level = "High"
            reason_parts.append("HIGH RISK: Critical CI + business hours + multiple systems + no rollback plan")
        
        # Rule 2: Medium Risk - Non-critical CI + limited blast radius + rollback available
        elif (not change_context.get('critical_ci', False) and 
              len(change_context.get('impacted_services', [])) <= 2 and 
              change_context.get('rollback_plan', False)):
            base_score = 45
            risk_level = "Medium"
            reason_parts.append("MEDIUM RISK: Non-critical CI + limited blast radius + rollback available")
        
        # Rule 3: Low Risk - Standard change + approved window + single system
        elif (change_context.get('change_type') == 'standard' and 
              change_context.get('change_window') == 'maintenance_window' and 
              len(change_context.get('impacted_services', [])) == 1):
            base_score = 25
            risk_level = "Low"
            reason_parts.append("LOW RISK: Standard change + approved window + single system")
        
        # Additional risk factors
        else:
            if change_context.get('critical_ci', False):
                base_score += 30
                reason_parts.append("Critical CI involved")
            
            if change_context.get('change_window') == 'business_hours':
                base_score += 20
                reason_parts.append("Business hours window")
            
            if len(change_context.get('impacted_services', [])) > 2:
                base_score += 25
                reason_parts.append("Multiple impacted services")
            
            if not change_context.get('rollback_plan', False):
                base_score += 35
                reason_parts.append("No rollback plan")
            
            if change_context.get('change_type') == 'emergency':
                base_score += 25
                reason_parts.append("Emergency change type")
        
        # Add some randomness for realism
        import random
        risk_score = min(100, base_score + random.randint(-5, 5))
        
        # Determine risk level if not already set
        if risk_level == "Low":  # Only determine if not set by specific rules
            if risk_score >= 70:
                risk_level = 'High'
            elif risk_score >= 40:
                risk_level = 'Medium'
            else:
                risk_level = 'Low'
        
        return {
            "risk_level": risk_level,
            "risk_score": risk_score,
            "reason": f"Risk Score: {risk_score}/100. {'; '.join(reason_parts)}",
            "impact_factors": reason_parts,
            "recommendation": self._get_recommendation(risk_level, risk_score),
            "mitigation_suggestions": self._get_mitigation_suggestions(change_context),
            "change_title": change_context.get('title', 'Unknown'),
            "analysis_method": "Rule-based fallback",
            "confidence": "Medium"
        }
    
    def _get_recommendation(self, risk_level: str, risk_score: int) -> str:
        """Get recommendation based on risk level and score."""
        if risk_level == 'High':
            if risk_score >= 80:
                return "REJECT: High risk change requires additional mitigation strategies"
            else:
                return "CONDITIONAL APPROVAL: Proceed with additional monitoring and stakeholder notification"
        elif risk_level == 'Medium':
            return "APPROVE WITH MONITORING: Standard change with routine oversight"
        else:
            return "APPROVE: Low risk change suitable for standard approval process"
    
    def _get_mitigation_suggestions(self, change_context: Dict[str, Any]) -> List[str]:
        """Get mitigation suggestions based on change context."""
        suggestions = []
        
        if change_context.get('critical_ci', False) and not change_context.get('rollback_plan', False):
            suggestions.append("Implement rollback procedures before execution")
        
        if change_context.get('change_window') == 'business_hours':
            suggestions.append("Consider user communication and support coverage")
        
        if len(change_context.get('impacted_services', [])) > 2:
            suggestions.append("Coordinate with all service owners for monitoring")
        
        if change_context.get('change_type') == 'emergency':
            suggestions.append("Ensure emergency response team is available")
        
        if not suggestions:
            suggestions.append("Standard change procedures apply")
        
        return suggestions
    
    def batch_analyze_risks(self, changes_context: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Analyze multiple changes in batch for efficiency.
        
        Args:
            changes_context: List of change request contexts
            
        Returns:
            List of AI analysis results
        """
        results = []
        for change_context in changes_context:
            result = self.analyze_risk_with_ai(change_context)
            results.append(result)
        return results
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the configured AI model."""
        if self.llm:
            return {
                "model_name": self.llm.model,
                "base_url": self.llm.base_url,
                "temperature": self.llm.temperature,
                "status": "Active"
            }
        else:
            return {
                "status": "Inactive - Model not initialized"
            }