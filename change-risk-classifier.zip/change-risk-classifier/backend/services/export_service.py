"""
Export service for generating reports and exporting data in various formats.
Supports CSV, PDF, and Excel export functionality.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
import pandas as pd
from io import BytesIO
import base64

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

from models import ChangeRequest, RiskScore, User, AuditLog
from config import settings

logger = logging.getLogger(__name__)


class ExportService:
    """Export service for generating reports and exporting data."""
    
    @staticmethod
    def export_changes_to_csv(
        changes: List[ChangeRequest],
        include_risk_details: bool = True,
        include_audit_trail: bool = False
    ) -> str:
        """
        Export change requests to CSV format.
        
        Args:
            changes: List of change requests to export
            include_risk_details: Include detailed risk information
            include_audit_trail: Include audit trail information
            
        Returns:
            CSV string content
        """
        try:
            # Prepare data
            data = []
            
            for change in changes:
                row = {
                    'ID': change.id,
                    'Title': change.title,
                    'Description': change.description,
                    'Change Type': change.change_type.value,
                    'Status': change.status.value,
                    'Risk Level': change.risk_level,
                    'Risk Score': change.risk_score,
                    'Change Window': change.change_window.value,
                    'Start Time': change.start_time.isoformat() if change.start_time else '',
                    'End Time': change.end_time.isoformat() if change.end_time else '',
                    'Duration (Hours)': change.calculate_duration_hours(),
                    'Critical CI': change.critical_ci,
                    'Rollback Plan': change.rollback_plan,
                    'Test Evidence': change.test_evidence,
                    'Business Owner': change.business_owner,
                    'Technical Owner': change.technical_owner,
                    'Submitted By': change.submitted_by.username if change.submitted_by else '',
                    'Approved By': change.approved_by.username if change.approved_by else '',
                    'Submitted At': change.submitted_at.isoformat() if change.submitted_at else '',
                    'Approved At': change.approved_at.isoformat() if change.approved_at else '',
                    'Created At': change.created_at.isoformat(),
                    'Updated At': change.updated_at.isoformat()
                }
                
                # Add risk details if requested
                if include_risk_details:
                    risk_scores = RiskScore.query.filter_by(change_request_id=change.id).first()
                    if risk_scores:
                        row.update({
                            'Base Score': risk_scores.base_score,
                            'CI Impact Score': risk_scores.ci_impact_score,
                            'Timing Score': risk_scores.timing_score,
                            'Scope Score': risk_scores.scope_score,
                            'Rollback Score': risk_scores.rollback_score,
                            'CI Criticality': risk_scores.ci_criticality,
                            'Impacted Systems Count': risk_scores.impacted_systems_count,
                            'Dependencies Count': risk_scores.dependencies_count,
                            'Rollback Available': risk_scores.rollback_available,
                            'Risk Reasoning': risk_scores.risk_reasoning,
                            'Assessment Method': risk_scores.assessment_method
                        })
                
                # Add audit trail if requested
                if include_audit_trail:
                    audit_logs = AuditLog.query.filter_by(
                        resource_type='change_request',
                        resource_id=str(change.id)
                    ).order_by(AuditLog.created_at).all()
                    
                    if audit_logs:
                        row['Audit Trail'] = '; '.join([
                            f"{log.created_at.isoformat()} - {log.action} by {log.user_email or 'System'}"
                            for log in audit_logs
                        ])
                
                data.append(row)
            
            # Create DataFrame and convert to CSV
            df = pd.DataFrame(data)
            csv_content = df.to_csv(index=False)
            
            logger.info(f"Exported {len(changes)} changes to CSV")
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting changes to CSV: {e}")
            return ""
    
    @staticmethod
    def export_changes_to_excel(
        changes: List[ChangeRequest],
        include_risk_details: bool = True,
        include_audit_trail: bool = False
    ) -> bytes:
        """
        Export change requests to Excel format.
        
        Args:
            changes: List of change requests to export
            include_risk_details: Include detailed risk information
            include_audit_trail: Include audit trail information
            
        Returns:
            Excel file content as bytes
        """
        try:
            # Prepare data
            data = []
            
            for change in changes:
                row = {
                    'ID': change.id,
                    'Title': change.title,
                    'Description': change.description,
                    'Change Type': change.change_type.value,
                    'Status': change.status.value,
                    'Risk Level': change.risk_level,
                    'Risk Score': change.risk_score,
                    'Change Window': change.change_window.value,
                    'Start Time': change.start_time,
                    'End Time': change.end_time,
                    'Duration (Hours)': change.calculate_duration_hours(),
                    'Critical CI': change.critical_ci,
                    'Rollback Plan': change.rollback_plan,
                    'Test Evidence': change.test_evidence,
                    'Business Owner': change.business_owner,
                    'Technical Owner': change.technical_owner,
                    'Submitted By': change.submitted_by.username if change.submitted_by else '',
                    'Approved By': change.approved_by.username if change.approved_by else '',
                    'Submitted At': change.submitted_at,
                    'Approved At': change.approved_at,
                    'Created At': change.created_at,
                    'Updated At': change.updated_at
                }
                
                # Add risk details if requested
                if include_risk_details:
                    risk_scores = RiskScore.query.filter_by(change_request_id=change.id).first()
                    if risk_scores:
                        row.update({
                            'Base Score': risk_scores.base_score,
                            'CI Impact Score': risk_scores.ci_impact_score,
                            'Timing Score': risk_scores.timing_score,
                            'Scope Score': risk_scores.scope_score,
                            'Rollback Score': risk_scores.rollback_score,
                            'CI Criticality': risk_scores.ci_criticality,
                            'Impacted Systems Count': risk_scores.impacted_systems_count,
                            'Dependencies Count': risk_scores.dependencies_count,
                            'Rollback Available': risk_scores.rollback_available,
                            'Risk Reasoning': risk_scores.risk_reasoning,
                            'Assessment Method': risk_scores.assessment_method
                        })
                
                data.append(row)
            
            # Create Excel file
            output = BytesIO()
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                df = pd.DataFrame(data)
                df.to_excel(writer, sheet_name='Changes', index=False)
                
                # Get workbook and worksheet
                workbook = writer.book
                worksheet = writer.sheets['Changes']
                
                # Add formatting
                header_format = workbook.add_format({
                    'bold': True,
                    'text_wrap': True,
                    'valign': 'top',
                    'fg_color': '#D7E4BC',
                    'border': 1
                })
                
                # Apply header formatting
                for col_num, value in enumerate(df.columns.values):
                    worksheet.write(0, col_num, value, header_format)
                
                # Auto-adjust column widths
                for i, col in enumerate(df.columns):
                    max_len = max(
                        df[col].astype(str).map(len).max(),
                        len(str(col))
                    ) + 1
                    worksheet.set_column(i, i, max_len)
            
            excel_content = output.getvalue()
            logger.info(f"Exported {len(changes)} changes to Excel")
            return excel_content
            
        except Exception as e:
            logger.error(f"Error exporting changes to Excel: {e}")
            return b""
    
    @staticmethod
    def export_changes_to_pdf(
        changes: List[ChangeRequest],
        title: str = "Change Request Report",
        include_risk_details: bool = True
    ) -> bytes:
        """
        Export change requests to PDF format.
        
        Args:
            changes: List of change requests to export
            title: Report title
            include_risk_details: Include detailed risk information
            
        Returns:
            PDF file content as bytes
        """
        try:
            # Create PDF in memory
            buffer = BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4)
            styles = getSampleStyleSheet()
            story = []
            
            # Title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                spaceAfter=30,
                alignment=TA_CENTER
            )
            story.append(Paragraph(title, title_style))
            story.append(Spacer(1, 12))
            
            # Summary
            summary_data = [
                ['Total Changes', str(len(changes))],
                ['High Risk', str(sum(1 for c in changes if c.risk_level == 'High'))],
                ['Medium Risk', str(sum(1 for c in changes if c.risk_level == 'Medium'))],
                ['Low Risk', str(sum(1 for c in changes if c.risk_level == 'Low'))],
                ['Approved', str(sum(1 for c in changes if c.status == 'approved'))],
                ['Pending', str(sum(1 for c in changes if c.status in ['submitted', 'review']))]
            ]
            
            summary_table = Table(summary_data, colWidths=[3*inch, 3*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(Paragraph("Summary", styles['Heading2']))
            story.append(summary_table)
            story.append(Spacer(1, 12))
            
            # Changes table
            story.append(Paragraph("Change Details", styles['Heading2']))
            story.append(Spacer(1, 12))
            
            # Table headers
            headers = [
                'ID', 'Title', 'Type', 'Status', 'Risk', 'Window', 
                'Start Time', 'End Time', 'Duration', 'Owner', 'Submitted'
            ]
            
            if include_risk_details:
                headers.extend(['CI Impact', 'Timing', 'Scope', 'Rollback'])
            
            # Table data
            table_data = [headers]
            
            for change in changes:
                row = [
                    str(change.id),
                    change.title[:50] + '...' if len(change.title) > 50 else change.title,
                    change.change_type.value,
                    change.status.value,
                    change.risk_level,
                    change.change_window.value,
                    change.start_time.strftime('%Y-%m-%d %H:%M') if change.start_time else '',
                    change.end_time.strftime('%Y-%m-%d %H:%M') if change.end_time else '',
                    f"{change.calculate_duration_hours():.1f}",
                    change.business_owner,
                    change.submitted_at.strftime('%Y-%m-%d %H:%M') if change.submitted_at else ''
                ]
                
                if include_risk_details:
                    risk_scores = RiskScore.query.filter_by(change_request_id=change.id).first()
                    if risk_scores:
                        row.extend([
                            str(risk_scores.ci_impact_score),
                            str(risk_scores.timing_score),
                            str(risk_scores.scope_score),
                            str(risk_scores.rollback_score)
                        ])
                    else:
                        row.extend(['-', '-', '-', '-'])
                
                table_data.append(row)
            
            # Create table
            table = Table(table_data, repeatRows=1)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')
            ]))
            
            story.append(table)
            
            # Build PDF
            doc.build(story)
            pdf_content = buffer.getvalue()
            buffer.close()
            
            logger.info(f"Exported {len(changes)} changes to PDF")
            return pdf_content
            
        except Exception as e:
            logger.error(f"Error exporting changes to PDF: {e}")
            return b""
    
    @staticmethod
    def export_dashboard_summary_to_csv(
        dashboard_data: Dict[str, Any],
        time_period: str = "30d"
    ) -> str:
        """
        Export dashboard summary to CSV format.
        
        Args:
            dashboard_data: Dashboard data to export
            time_period: Time period for the report
            
        Returns:
            CSV string content
        """
        try:
            data = []
            
            # Summary section
            summary = dashboard_data.get('summary', {})
            data.append(['Summary', ''])
            data.append(['Total Changes', summary.get('total_changes', 0)])
            data.append(['Pending Changes', summary.get('pending_changes', 0)])
            data.append(['Approved Changes', summary.get('approved_changes', 0)])
            data.append(['High Risk Changes', summary.get('high_risk_changes', 0)])
            data.append(['Medium Risk Changes', summary.get('medium_risk_changes', 0)])
            data.append(['Low Risk Changes', summary.get('low_risk_changes', 0)])
            data.append(['', ''])
            
            # Status distribution
            status_dist = dashboard_data.get('status_distribution', {})
            data.append(['Status Distribution', ''])
            for status, count in status_dist.items():
                data.append([status, count])
            data.append(['', ''])
            
            # Risk distribution
            risk_dist = dashboard_data.get('risk_distribution', {})
            data.append(['Risk Distribution', ''])
            for risk, count in risk_dist.items():
                data.append([risk, count])
            data.append(['', ''])
            
            # Performance metrics
            perf_metrics = dashboard_data.get('performance_metrics', {})
            data.append(['Performance Metrics', ''])
            data.append(['Average Approval Time (Hours)', perf_metrics.get('average_approval_time_hours', 0)])
            data.append(['Success Rate (%)', perf_metrics.get('success_rate_percentage', 0)])
            data.append(['Total Submitted', perf_metrics.get('total_submitted', 0)])
            data.append(['Approved Count', perf_metrics.get('approved_count', 0)])
            data.append(['Rejected Count', perf_metrics.get('rejected_count', 0)])
            
            # Create DataFrame and convert to CSV
            df = pd.DataFrame(data, columns=['Metric', 'Value'])
            csv_content = df.to_csv(index=False)
            
            logger.info(f"Exported dashboard summary to CSV for period {time_period}")
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting dashboard summary to CSV: {e}")
            return ""
    
    @staticmethod
    def export_audit_trail_to_csv(
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        user_id: Optional[int] = None,
        resource_type: Optional[str] = None
    ) -> str:
        """
        Export audit trail to CSV format.
        
        Args:
            start_date: Start date for filtering
            end_date: End date for filtering
            user_id: User ID to filter by
            resource_type: Resource type to filter by
            
        Returns:
            CSV string content
        """
        try:
            # Build query
            query = AuditLog.query
            
            if start_date:
                query = query.filter(AuditLog.created_at >= start_date)
            if end_date:
                query = query.filter(AuditLog.created_at <= end_date)
            if user_id:
                query = query.filter(AuditLog.user_id == user_id)
            if resource_type:
                query = query.filter(AuditLog.resource_type == resource_type)
            
            audit_logs = query.order_by(AuditLog.created_at.desc()).all()
            
            # Prepare data
            data = []
            for log in audit_logs:
                row = {
                    'Timestamp': log.created_at.isoformat(),
                    'User': log.user_email or 'System',
                    'Action': log.action,
                    'Resource Type': log.resource_type,
                    'Resource ID': log.resource_id,
                    'Description': log.description,
                    'IP Address': log.ip_address,
                    'Status Code': log.status_code,
                    'Is Suspicious': log.is_suspicious,
                    'Suspicious Reason': log.suspicious_reason
                }
                data.append(row)
            
            # Create DataFrame and convert to CSV
            df = pd.DataFrame(data)
            csv_content = df.to_csv(index=False)
            
            logger.info(f"Exported {len(audit_logs)} audit logs to CSV")
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting audit trail to CSV: {e}")
            return ""
    
    @staticmethod
    def generate_cab_review_pack(
        changes: List[ChangeRequest],
        cab_date: str,
        cab_time: str
    ) -> Dict[str, bytes]:
        """
        Generate a complete CAB review pack with multiple formats.
        
        Args:
            changes: List of changes for CAB review
            cab_date: CAB meeting date
            cab_time: CAB meeting time
            
        Returns:
            Dict containing different format files
        """
        try:
            pack = {}
            
            # Generate title
            title = f"CAB Review Pack - {cab_date} at {cab_time}"
            
            # Generate CSV
            csv_content = ExportService.export_changes_to_csv(changes, include_risk_details=True)
            pack['csv'] = csv_content.encode('utf-8')
            
            # Generate Excel
            excel_content = ExportService.export_changes_to_excel(changes, include_risk_details=True)
            pack['excel'] = excel_content
            
            # Generate PDF
            pdf_content = ExportService.export_changes_to_pdf(changes, title, include_risk_details=True)
            pack['pdf'] = pdf_content
            
            # Generate summary CSV
            summary_data = {
                'summary': {
                    'total_changes': len(changes),
                    'high_risk_changes': sum(1 for c in changes if c.risk_level == 'High'),
                    'medium_risk_changes': sum(1 for c in changes if c.risk_level == 'Medium'),
                    'low_risk_changes': sum(1 for c in changes if c.risk_level == 'Low'),
                    'pending_changes': sum(1 for c in changes if c.status in ['submitted', 'review']),
                    'approved_changes': sum(1 for c in changes if c.status == 'approved')
                }
            }
            summary_csv = ExportService.export_dashboard_summary_to_csv(summary_data)
            pack['summary_csv'] = summary_csv.encode('utf-8')
            
            logger.info(f"Generated CAB review pack for {len(changes)} changes")
            return pack
            
        except Exception as e:
            logger.error(f"Error generating CAB review pack: {e}")
            return {}