"""
Audit service for comprehensive system monitoring and compliance tracking.
Provides audit trail management, security monitoring, and compliance reporting.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from sqlalchemy import and_, or_, func
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import AuditLog, User, ChangeRequest, RiskScore, AuditAction
from config import settings

logger = logging.getLogger(__name__)


class AuditService:
    """Audit service for comprehensive system monitoring and compliance tracking."""
    
    @staticmethod
    def log_user_action(
        user_id: Optional[int],
        user_email: Optional[str],
        action: AuditAction,
        resource_type: str,
        description: str,
        resource_id: Optional[str] = None,
        request_data: Optional[Dict] = None,
        response_data: Optional[Dict] = None,
        status_code: Optional[int] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None
    ) -> Optional[AuditLog]:
        """
        Log a user action to the audit trail.
        
        Args:
            user_id: User ID
            user_email: User email
            action: Type of action performed
            resource_type: Type of resource affected
            description: Description of the action
            resource_id: ID of the resource (optional)
            request_data: Request data (optional)
            response_data: Response data (optional)
            status_code: HTTP status code (optional)
            ip_address: User's IP address (optional)
            user_agent: User agent string (optional)
            session_id: Session identifier (optional)
            correlation_id: Correlation identifier (optional)
            
        Returns:
            Created AuditLog object or None if creation fails
        """
        try:
            audit_log = AuditLog(
                user_id=user_id,
                user_email=user_email,
                action=action.value,
                resource_type=resource_type,
                resource_id=resource_id,
                description=description,
                ip_address=ip_address,
                user_agent=user_agent,
                status_code=status_code,
                session_id=session_id,
                correlation_id=correlation_id
            )
            
            # Convert dictionaries to JSON strings
            if request_data:
                audit_log.request_data = str(request_data)
            if response_data:
                audit_log.response_data = str(response_data)
            
            audit_log.save()
            
            # Check for suspicious activity
            AuditService._check_suspicious_activity(audit_log)
            
            return audit_log
            
        except SQLAlchemyError as e:
            logger.error(f"Database error logging user action: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error logging user action: {e}")
            return None
    
    @staticmethod
    def _check_suspicious_activity(audit_log: AuditLog) -> None:
        """Check if the audit log indicates suspicious activity."""
        try:
            # Check for failed login attempts
            if audit_log.action == AuditAction.LOGIN.value and audit_log.status_code != 200:
                recent_failures = AuditLog.query.filter(
                    and_(
                        AuditLog.user_email == audit_log.user_email,
                        AuditLog.action == AuditAction.LOGIN.value,
                        AuditLog.status_code != 200,
                        AuditLog.created_at >= datetime.utcnow() - timedelta(minutes=15)
                    )
                ).count()
                
                if recent_failures >= 5:
                    audit_log.mark_suspicious("Multiple failed login attempts")
                    audit_log.save()
            
            # Check for unusual access patterns
            if audit_log.action in [AuditAction.READ.value, AuditAction.UPDATE.value]:
                recent_access = AuditLog.query.filter(
                    and_(
                        AuditLog.user_email == audit_log.user_email,
                        AuditLog.created_at >= datetime.utcnow() - timedelta(hours=1)
                    )
                ).count()
                
                if recent_access > 100:  # More than 100 actions in 1 hour
                    audit_log.mark_suspicious("Unusual number of actions in short time")
                    audit_log.save()
            
            # Check for access outside business hours (8 AM - 6 PM)
            hour = audit_log.created_at.hour
            if hour < 8 or hour > 18:
                audit_log.mark_suspicious("Access outside business hours")
                audit_log.save()
                
        except Exception as e:
            logger.error(f"Error checking suspicious activity: {e}")
    
    @staticmethod
    def get_audit_trail(
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        user_id: Optional[int] = None,
        user_email: Optional[str] = None,
        action: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        is_suspicious: Optional[bool] = None,
        page: int = 1,
        per_page: int = 50
    ) -> Dict[str, Any]:
        """
        Get audit trail with filtering and pagination.
        
        Args:
            start_date: Start date for filtering
            end_date: End date for filtering
            user_id: User ID to filter by
            user_email: User email to filter by
            action: Action type to filter by
            resource_type: Resource type to filter by
            resource_id: Resource ID to filter by
            is_suspicious: Filter by suspicious activity
            page: Page number
            per_page: Number of items per page
            
        Returns:
            Dict containing audit logs and pagination info
        """
        try:
            query = AuditLog.query
            
            # Apply filters
            if start_date:
                query = query.filter(AuditLog.created_at >= start_date)
            if end_date:
                query = query.filter(AuditLog.created_at <= end_date)
            if user_id:
                query = query.filter(AuditLog.user_id == user_id)
            if user_email:
                query = query.filter(AuditLog.user_email == user_email)
            if action:
                query = query.filter(AuditLog.action == action)
            if resource_type:
                query = query.filter(AuditLog.resource_type == resource_type)
            if resource_id:
                query = query.filter(AuditLog.resource_id == resource_id)
            if is_suspicious is not None:
                query = query.filter(AuditLog.is_suspicious == is_suspicious)
            
            # Order by creation date (newest first)
            query = query.order_by(AuditLog.created_at.desc())
            
            # Paginate
            total = query.count()
            logs = query.offset((page - 1) * per_page).limit(per_page).all()
            
            return {
                "audit_logs": [log.to_dict() for log in logs],
                "pagination": {
                    "page": page,
                    "per_page": per_page,
                    "total": total,
                    "pages": (total + per_page - 1) // per_page
                },
                "filters": {
                    "start_date": start_date.isoformat() if start_date else None,
                    "end_date": end_date.isoformat() if end_date else None,
                    "user_id": user_id,
                    "user_email": user_email,
                    "action": action,
                    "resource_type": resource_type,
                    "resource_id": resource_id,
                    "is_suspicious": is_suspicious
                }
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting audit trail: {e}")
            return {"audit_logs": [], "pagination": {}, "filters": {}}
    
    @staticmethod
    def get_security_report(time_period: str = "24h") -> Dict[str, Any]:
        """
        Get security report for the specified time period.
        
        Args:
            time_period: Time period (e.g., "1h", "24h", "7d", "30d")
            
        Returns:
            Dict containing security metrics and findings
        """
        try:
            # Parse time period
            hours = 24  # Default
            if time_period == "1h":
                hours = 1
            elif time_period == "7d":
                hours = 7 * 24
            elif time_period == "30d":
                hours = 30 * 24
            
            cutoff_date = datetime.utcnow() - timedelta(hours=hours)
            
            # Get total actions
            total_actions = AuditLog.query.filter(
                AuditLog.created_at >= cutoff_date
            ).count()
            
            # Get suspicious actions
            suspicious_actions = AuditLog.query.filter(
                and_(
                    AuditLog.created_at >= cutoff_date,
                    AuditLog.is_suspicious == True
                )
            ).count()
            
            # Get failed login attempts
            failed_logins = AuditLog.query.filter(
                and_(
                    AuditLog.created_at >= cutoff_date,
                    AuditLog.action == AuditAction.LOGIN.value,
                    AuditLog.status_code != 200
                )
            ).count()
            
            # Get unique users
            unique_users = AuditLog.query.filter(
                AuditLog.created_at >= cutoff_date
            ).distinct(AuditLog.user_email).count()
            
            # Get top actions
            top_actions = db.session.query(
                AuditLog.action,
                func.count(AuditLog.id).label('count')
            ).filter(
                AuditLog.created_at >= cutoff_date
            ).group_by(AuditLog.action).order_by(
                func.count(AuditLog.id).desc()
            ).limit(10).all()
            
            # Get suspicious activity details
            suspicious_logs = AuditLog.query.filter(
                and_(
                    AuditLog.created_at >= cutoff_date,
                    AuditLog.is_suspicious == True
                )
            ).order_by(AuditLog.created_at.desc()).limit(20).all()
            
            return {
                "time_period": time_period,
                "hours": hours,
                "total_actions": total_actions,
                "suspicious_actions": suspicious_actions,
                "failed_logins": failed_logins,
                "unique_users": unique_users,
                "suspicious_percentage": (suspicious_actions / max(total_actions, 1)) * 100,
                "security_score": max(0, 100 - (suspicious_actions * 10) - (failed_logins * 5)),
                "top_actions": [{"action": action, "count": count} for action, count in top_actions],
                "suspicious_activity": [log.to_dict() for log in suspicious_logs],
                "summary": AuditService._generate_security_summary(
                    total_actions, suspicious_actions, failed_logins, unique_users
                )
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting security report: {e}")
            return {}
    
    @staticmethod
    def _generate_security_summary(total_actions: int, suspicious_actions: int, failed_logins: int, unique_users: int) -> Dict[str, Any]:
        """Generate security summary with recommendations."""
        risk_level = "Low"
        recommendations = []
        
        if suspicious_actions > 10:
            risk_level = "High"
            recommendations.append("Investigate high number of suspicious activities")
        elif suspicious_actions > 5:
            risk_level = "Medium"
            recommendations.append("Monitor for potential security threats")
        
        if failed_logins > 20:
            risk_level = "High"
            recommendations.append("Implement account lockout policy")
        elif failed_logins > 10:
            risk_level = "Medium"
            recommendations.append("Review authentication security")
        
        if unique_users == 0:
            recommendations.append("No user activity detected")
        elif total_actions / max(unique_users, 1) > 1000:
            recommendations.append("Monitor for potential automated attacks")
        
        return {
            "risk_level": risk_level,
            "recommendations": recommendations,
            "status": "Secure" if risk_level == "Low" else "Needs Attention"
        }
    
    @staticmethod
    def get_compliance_report(start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """
        Get compliance report for the specified date range.
        
        Args:
            start_date: Start date for the report
            end_date: End date for the report
            
        Returns:
            Dict containing compliance metrics
        """
        try:
            # Get audit logs in the date range
            audit_logs = AuditLog.query.filter(
                and_(
                    AuditLog.created_at >= start_date,
                    AuditLog.created_at <= end_date
                )
            ).all()
            
            # Calculate compliance metrics
            total_actions = len(audit_logs)
            user_actions = {}
            resource_actions = {}
            action_types = {}
            
            for log in audit_logs:
                # Count by user
                user_key = log.user_email or "System"
                user_actions[user_key] = user_actions.get(user_key, 0) + 1
                
                # Count by resource type
                resource_actions[log.resource_type] = resource_actions.get(log.resource_type, 0) + 1
                
                # Count by action type
                action_types[log.action] = action_types.get(log.action, 0) + 1
            
            # Get data access patterns
            data_access = AuditLog.query.filter(
                and_(
                    AuditLog.created_at >= start_date,
                    AuditLog.created_at <= end_date,
                    AuditLog.resource_type.in_(['change_request', 'user', 'rule'])
                )
            ).count()
            
            # Check for audit trail completeness
            expected_actions = ChangeRequest.query.filter(
                and_(
                    ChangeRequest.created_at >= start_date,
                    ChangeRequest.created_at <= end_date
                )
            ).count() * 2  # Each change should have create and update logs
            
            audit_completeness = (total_actions / max(expected_actions, 1)) * 100 if expected_actions > 0 else 100
            
            return {
                "date_range": {
                    "start": start_date.isoformat(),
                    "end": end_date.isoformat()
                },
                "total_actions": total_actions,
                "unique_users": len(user_actions),
                "data_access_count": data_access,
                "audit_completeness_percentage": round(audit_completeness, 2),
                "user_activity": user_actions,
                "resource_activity": resource_actions,
                "action_distribution": action_types,
                "compliance_status": "Compliant" if audit_completeness >= 95 else "Non-Compliant",
                "recommendations": AuditService._generate_compliance_recommendations(
                    audit_completeness, total_actions, len(user_actions)
                )
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting compliance report: {e}")
            return {}
    
    @staticmethod
    def _generate_compliance_recommendations(audit_completeness: float, total_actions: int, unique_users: int) -> List[str]:
        """Generate compliance recommendations."""
        recommendations = []
        
        if audit_completeness < 95:
            recommendations.append("Improve audit trail completeness - ensure all actions are logged")
        
        if total_actions == 0:
            recommendations.append("No audit trail activity detected - verify system usage")
        
        if unique_users == 0:
            recommendations.append("No user activity detected - review user access")
        
        if audit_completeness > 100:
            recommendations.append("Review audit logging configuration - potential duplicate logging")
        
        return recommendations
    
    @staticmethod
    def get_user_activity_report(user_id: int, days: int = 30) -> Dict[str, Any]:
        """
        Get detailed activity report for a specific user.
        
        Args:
            user_id: User ID to generate report for
            days: Number of days to look back
            
        Returns:
            Dict containing user activity metrics
        """
        try:
            user = User.query.get(user_id)
            if not user:
                return {"error": "User not found"}
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Get user's audit logs
            audit_logs = AuditLog.query.filter(
                and_(
                    AuditLog.user_id == user_id,
                    AuditLog.created_at >= cutoff_date
                )
            ).order_by(AuditLog.created_at.desc()).all()
            
            # Calculate metrics
            total_actions = len(audit_logs)
            suspicious_actions = sum(1 for log in audit_logs if log.is_suspicious)
            failed_logins = sum(1 for log in audit_logs if log.action == AuditAction.LOGIN.value and log.status_code != 200)
            
            # Get action distribution
            action_distribution = {}
            resource_distribution = {}
            time_distribution = {}  # Hour of day
            
            for log in audit_logs:
                # Action distribution
                action_distribution[log.action] = action_distribution.get(log.action, 0) + 1
                
                # Resource distribution
                resource_distribution[log.resource_type] = resource_distribution.get(log.resource_type, 0) + 1
                
                # Time distribution (hour of day)
                hour = log.created_at.hour
                time_distribution[hour] = time_distribution.get(hour, 0) + 1
            
            # Get last login
            last_login = AuditLog.query.filter(
                and_(
                    AuditLog.user_id == user_id,
                    AuditLog.action == AuditAction.LOGIN.value,
                    AuditLog.status_code == 200
                )
            ).order_by(AuditLog.created_at.desc()).first()
            
            return {
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "role": user.role.value,
                    "is_active": user.is_active
                },
                "report_period": {
                    "days": days,
                    "start_date": cutoff_date.isoformat(),
                    "end_date": datetime.utcnow().isoformat()
                },
                "activity_metrics": {
                    "total_actions": total_actions,
                    "suspicious_actions": suspicious_actions,
                    "failed_logins": failed_logins,
                    "last_login": last_login.created_at.isoformat() if last_login else None,
                    "suspicious_percentage": (suspicious_actions / max(total_actions, 1)) * 100
                },
                "action_distribution": action_distribution,
                "resource_distribution": resource_distribution,
                "time_distribution": time_distribution,
                "activity_summary": AuditService._generate_user_activity_summary(
                    total_actions, suspicious_actions, failed_logins, days
                )
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting user activity report: {e}")
            return {}
    
    @staticmethod
    def _generate_user_activity_summary(total_actions: int, suspicious_actions: int, failed_logins: int, days: int) -> Dict[str, Any]:
        """Generate user activity summary."""
        activity_level = "Low"
        if total_actions > 100:
            activity_level = "High"
        elif total_actions > 20:
            activity_level = "Medium"
        
        risk_level = "Low"
        if suspicious_actions > 5 or failed_logins > 10:
            risk_level = "High"
        elif suspicious_actions > 2 or failed_logins > 5:
            risk_level = "Medium"
        
        return {
            "activity_level": activity_level,
            "risk_level": risk_level,
            "average_daily_actions": total_actions / max(days, 1),
            "status": "Normal" if risk_level == "Low" and activity_level != "Low" else "Review Required"
        }
    
    @staticmethod
    def cleanup_old_audit_logs(retention_days: int = 365) -> int:
        """
        Clean up old audit logs based on retention policy.
        
        Args:
            retention_days: Number of days to retain audit logs
            
        Returns:
            Number of records deleted
        """
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=retention_days)
            
            # Count records to be deleted
            count = AuditLog.query.filter(AuditLog.created_at < cutoff_date).count()
            
            # Delete old records
            deleted_count = AuditLog.query.filter(AuditLog.created_at < cutoff_date).delete()
            db.session.commit()
            
            logger.info(f"Cleaned up {deleted_count} audit logs older than {retention_days} days")
            return deleted_count
            
        except SQLAlchemyError as e:
            logger.error(f"Database error cleaning up audit logs: {e}")
            return 0