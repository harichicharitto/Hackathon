"""
Dashboard service for providing data aggregation and reporting functionality.
Handles dashboard data retrieval, filtering, and export operations.
"""

from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from sqlalchemy import func, and_, or_
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import ChangeRequest, RiskScore, User, AuditLog, ChangeStatus, ChangeType, ChangeWindow
from models.base import db
from config import settings

logger = logging.getLogger(__name__)


class DashboardService:
    """Dashboard service for providing data aggregation and reporting functionality."""
    
    @staticmethod
    def get_dashboard_summary(user_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Get comprehensive dashboard summary data.
        
        Args:
            user_id: Optional user ID to filter data
            
        Returns:
            Dict containing dashboard summary data
        """
        try:
            # Base query filters
            base_filters = []
            if user_id:
                base_filters.append(ChangeRequest.submitted_by_id == user_id)
            
            # Get counts by status
            status_counts = DashboardService._get_status_counts(base_filters)
            
            # Get counts by risk level
            risk_counts = DashboardService._get_risk_counts(base_filters)
            
            # Get counts by change type
            type_counts = DashboardService._get_type_counts(base_filters)
            
            # Get counts by time window
            window_counts = DashboardService._get_window_counts(base_filters)
            
            # Get recent activity
            recent_activity = DashboardService._get_recent_activity(user_id)
            
            # Get pending approvals
            pending_approvals = DashboardService._get_pending_approvals(user_id)
            
            # Get performance metrics
            performance_metrics = DashboardService._get_performance_metrics(base_filters)
            
            return {
                "summary": {
                    "total_changes": sum(status_counts.values()),
                    "pending_changes": status_counts.get("submitted", 0) + status_counts.get("review", 0),
                    "approved_changes": status_counts.get("approved", 0),
                    "high_risk_changes": risk_counts.get("High", 0),
                    "medium_risk_changes": risk_counts.get("Medium", 0),
                    "low_risk_changes": risk_counts.get("Low", 0)
                },
                "status_distribution": status_counts,
                "risk_distribution": risk_counts,
                "type_distribution": type_counts,
                "window_distribution": window_counts,
                "recent_activity": recent_activity,
                "pending_approvals": pending_approvals,
                "performance_metrics": performance_metrics
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting dashboard summary: {e}")
            return {}
    
    @staticmethod
    def _get_status_counts(filters: List) -> Dict[str, int]:
        """Get change counts by status."""
        try:
            results = db.session.query(
                ChangeRequest.status,
                func.count(ChangeRequest.id).label('count')
            ).filter(*filters).group_by(ChangeRequest.status).all()
            
            return {status: count for status, count in results}
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_risk_counts(filters: List) -> Dict[str, int]:
        """Get change counts by risk level."""
        try:
            results = db.session.query(
                RiskScore.risk_level,
                func.count(RiskScore.id).label('count')
            ).join(ChangeRequest).filter(*filters).group_by(RiskScore.risk_level).all()
            
            return {risk_level: count for risk_level, count in results}
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_type_counts(filters: List) -> Dict[str, int]:
        """Get change counts by type."""
        try:
            results = db.session.query(
                ChangeRequest.change_type,
                func.count(ChangeRequest.id).label('count')
            ).filter(*filters).group_by(ChangeRequest.change_type).all()
            
            return {change_type: count for change_type, count in results}
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_window_counts(filters: List) -> Dict[str, int]:
        """Get change counts by time window."""
        try:
            results = db.session.query(
                ChangeRequest.change_window,
                func.count(ChangeRequest.id).label('count')
            ).filter(*filters).group_by(ChangeRequest.change_window).all()
            
            return {window: count for window, count in results}
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_recent_activity(user_id: Optional[int] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent change activity."""
        try:
            query = ChangeRequest.query.order_by(ChangeRequest.updated_at.desc())
            
            if user_id:
                query = query.filter(
                    or_(
                        ChangeRequest.submitted_by_id == user_id,
                        ChangeRequest.approved_by_id == user_id
                    )
                )
            
            changes = query.limit(limit).all()
            
            return [DashboardService._format_change_summary(change) for change in changes]
            
        except SQLAlchemyError:
            return []
    
    @staticmethod
    def _get_pending_approvals(user_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get pending approval requests."""
        try:
            query = ChangeRequest.query.filter(
                ChangeRequest.status.in_(['submitted', 'review'])
            ).order_by(ChangeRequest.submitted_at.desc())
            
            if user_id:
                # Only show changes that this user can approve
                query = query.filter(ChangeRequest.submitted_by_id != user_id)
            
            changes = query.limit(20).all()
            
            return [DashboardService._format_change_summary(change) for change in changes]
            
        except SQLAlchemyError:
            return []
    
    @staticmethod
    def _get_performance_metrics(filters: List) -> Dict[str, Any]:
        """Get performance metrics."""
        try:
            # Get approval times
            approval_times = db.session.query(
                func.avg(
                    func.extract('epoch', ChangeRequest.approved_at - ChangeRequest.submitted_at) / 3600
                ).label('avg_approval_hours')
            ).filter(
                *filters,
                ChangeRequest.submitted_at.isnot(None),
                ChangeRequest.approved_at.isnot(None)
            ).scalar()
            
            # Get success rate
            total_submitted = db.session.query(func.count(ChangeRequest.id)).filter(
                *filters,
                ChangeRequest.status.in_(['approved', 'rejected'])
            ).scalar()
            
            approved_count = db.session.query(func.count(ChangeRequest.id)).filter(
                *filters,
                ChangeRequest.status == 'approved'
            ).scalar()
            
            success_rate = (approved_count / max(total_submitted, 1)) * 100 if total_submitted > 0 else 0
            
            return {
                "average_approval_time_hours": round(approval_times or 0, 2),
                "success_rate_percentage": round(success_rate, 2),
                "total_submitted": total_submitted,
                "approved_count": approved_count,
                "rejected_count": total_submitted - approved_count if total_submitted > 0 else 0
            }
            
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def get_filtered_changes(
        filters: Dict[str, Any],
        user_id: Optional[int] = None,
        page: int = 1,
        per_page: int = 20
    ) -> Dict[str, Any]:
        """
        Get filtered changes with pagination.
        
        Args:
            filters: Dictionary of filter criteria
            user_id: Optional user ID to filter by
            page: Page number
            per_page: Number of items per page
            
        Returns:
            Dict containing filtered changes and pagination info
        """
        try:
            # Build query
            query = ChangeRequest.query
            
            # Apply user filter
            if user_id:
                query = query.filter(ChangeRequest.submitted_by_id == user_id)
            
            # Apply status filter
            if filters.get('status'):
                query = query.filter(ChangeRequest.status.in_(filters['status']))
            
            # Apply risk level filter
            if filters.get('risk_level'):
                query = query.join(RiskScore).filter(RiskScore.risk_level.in_(filters['risk_level']))
            
            # Apply change type filter
            if filters.get('change_type'):
                query = query.filter(ChangeRequest.change_type.in_(filters['change_type']))
            
            # Apply time window filter
            if filters.get('change_window'):
                query = query.filter(ChangeRequest.change_window.in_(filters['change_window']))
            
            # Apply date range filter
            if filters.get('start_date') and filters.get('end_date'):
                start_date = datetime.fromisoformat(filters['start_date'])
                end_date = datetime.fromisoformat(filters['end_date'])
                query = query.filter(
                    and_(
                        ChangeRequest.created_at >= start_date,
                        ChangeRequest.created_at <= end_date
                    )
                )
            
            # Apply search filter
            if filters.get('search'):
                search_term = f"%{filters['search']}%"
                query = query.filter(
                    or_(
                        ChangeRequest.title.ilike(search_term),
                        ChangeRequest.description.ilike(search_term),
                        ChangeRequest.business_owner.ilike(search_term),
                        ChangeRequest.technical_owner.ilike(search_term)
                    )
                )
            
            # Apply sorting
            sort_by = filters.get('sort_by', 'created_at')
            sort_order = filters.get('sort_order', 'desc')
            
            if sort_order == 'desc':
                query = query.order_by(getattr(ChangeRequest, sort_by).desc())
            else:
                query = query.order_by(getattr(ChangeRequest, sort_by).asc())
            
            # Paginate
            total = query.count()
            changes = query.offset((page - 1) * per_page).limit(per_page).all()
            
            return {
                "changes": [DashboardService._format_change_details(change) for change in changes],
                "pagination": {
                    "page": page,
                    "per_page": per_page,
                    "total": total,
                    "pages": (total + per_page - 1) // per_page
                },
                "filters": filters
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting filtered changes: {e}")
            return {"changes": [], "pagination": {}, "filters": filters}
    
    @staticmethod
    def get_change_analytics(time_period: str = "30d") -> Dict[str, Any]:
        """
        Get change analytics for the specified time period.
        
        Args:
            time_period: Time period (e.g., "7d", "30d", "90d")
            
        Returns:
            Dict containing analytics data
        """
        try:
            # Parse time period
            days = 30  # Default
            if time_period == "7d":
                days = 7
            elif time_period == "90d":
                days = 90
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Get changes in period
            changes = ChangeRequest.query.filter(
                ChangeRequest.created_at >= cutoff_date
            ).all()
            
            # Analyze trends
            daily_counts = DashboardService._get_daily_change_counts(cutoff_date)
            risk_trends = DashboardService._get_risk_trends_over_time(cutoff_date)
            approval_trends = DashboardService._get_approval_trends_over_time(cutoff_date)
            
            return {
                "time_period": time_period,
                "days": days,
                "total_changes": len(changes),
                "daily_counts": daily_counts,
                "risk_trends": risk_trends,
                "approval_trends": approval_trends,
                "summary": DashboardService._calculate_analytics_summary(changes)
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting change analytics: {e}")
            return {}
    
    @staticmethod
    def _get_daily_change_counts(cutoff_date: datetime) -> List[Dict[str, Any]]:
        """Get daily change counts."""
        try:
            results = db.session.query(
                func.date(ChangeRequest.created_at).label('date'),
                func.count(ChangeRequest.id).label('count')
            ).filter(
                ChangeRequest.created_at >= cutoff_date
            ).group_by(
                func.date(ChangeRequest.created_at)
            ).order_by('date').all()
            
            return [{"date": str(date), "count": count} for date, count in results]
            
        except SQLAlchemyError:
            return []
    
    @staticmethod
    def _get_risk_trends_over_time(cutoff_date: datetime) -> Dict[str, Any]:
        """Get risk level trends over time."""
        try:
            results = db.session.query(
                func.date(RiskScore.created_at).label('date'),
                RiskScore.risk_level,
                func.count(RiskScore.id).label('count')
            ).filter(
                RiskScore.created_at >= cutoff_date
            ).group_by(
                func.date(RiskScore.created_at),
                RiskScore.risk_level
            ).all()
            
            trends = {}
            for date, risk_level, count in results:
                if str(date) not in trends:
                    trends[str(date)] = {"High": 0, "Medium": 0, "Low": 0}
                trends[str(date)][risk_level] = count
            
            return trends
            
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _get_approval_trends_over_time(cutoff_date: datetime) -> Dict[str, Any]:
        """Get approval status trends over time."""
        try:
            results = db.session.query(
                func.date(ChangeRequest.approved_at).label('date'),
                ChangeRequest.status,
                func.count(ChangeRequest.id).label('count')
            ).filter(
                ChangeRequest.approved_at >= cutoff_date,
                ChangeRequest.status.in_(['approved', 'rejected'])
            ).group_by(
                func.date(ChangeRequest.approved_at),
                ChangeRequest.status
            ).all()
            
            trends = {}
            for date, status, count in results:
                if str(date) not in trends:
                    trends[str(date)] = {"approved": 0, "rejected": 0}
                trends[str(date)][status] = count
            
            return trends
            
        except SQLAlchemyError:
            return {}
    
    @staticmethod
    def _calculate_analytics_summary(changes: List[ChangeRequest]) -> Dict[str, Any]:
        """Calculate summary statistics from changes."""
        if not changes:
            return {}
        
        # Risk distribution
        high_risk = sum(1 for c in changes if c.risk_level == "High")
        medium_risk = sum(1 for c in changes if c.risk_level == "Medium")
        low_risk = sum(1 for c in changes if c.risk_level == "Low")
        
        # Status distribution
        approved = sum(1 for c in changes if c.status == "approved")
        rejected = sum(1 for c in changes if c.status == "rejected")
        pending = sum(1 for c in changes if c.status in ["submitted", "review"])
        
        # Average approval time
        approval_times = []
        for change in changes:
            if change.submitted_at and change.approved_at:
                diff = change.approved_at - change.submitted_at
                approval_times.append(diff.total_seconds() / 3600)
        
        avg_approval_time = sum(approval_times) / max(len(approval_times), 1)
        
        return {
            "risk_distribution": {
                "high": high_risk,
                "medium": medium_risk,
                "low": low_risk,
                "high_percentage": (high_risk / len(changes)) * 100,
                "medium_percentage": (medium_risk / len(changes)) * 100,
                "low_percentage": (low_risk / len(changes)) * 100
            },
            "status_distribution": {
                "approved": approved,
                "rejected": rejected,
                "pending": pending,
                "approval_rate": (approved / max(approved + rejected, 1)) * 100
            },
            "average_approval_time_hours": round(avg_approval_time, 2),
            "total_changes": len(changes)
        }
    
    @staticmethod
    def _format_change_summary(change: ChangeRequest) -> Dict[str, Any]:
        """Format change for summary display."""
        return {
            "id": change.id,
            "title": change.title,
            "status": change.status.value,
            "risk_level": change.risk_level,
            "risk_score": change.risk_score,
            "change_type": change.change_type.value,
            "change_window": change.change_window.value,
            "submitted_at": change.submitted_at.isoformat() if change.submitted_at else None,
            "business_owner": change.business_owner,
            "technical_owner": change.technical_owner,
            "duration_hours": change.calculate_duration_hours()
        }
    
    @staticmethod
    def _format_change_details(change: ChangeRequest) -> Dict[str, Any]:
        """Format change for detailed display."""
        data = change.to_dict()
        data.update({
            "status": change.status.value,
            "change_type": change.change_type.value,
            "change_window": change.change_window.value,
            "duration_hours": change.calculate_duration_hours(),
            "missing_fields": change.get_missing_fields(),
            "is_high_risk": change.is_high_risk(),
            "is_medium_risk": change.is_medium_risk(),
            "is_low_risk": change.is_low_risk()
        })
        return data