"""
Authentication service for user management and JWT token handling.
Provides secure authentication and authorization functionality.
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from flask import current_app
from flask_jwt_extended import create_access_token, decode_token
from werkzeug.security import check_password_hash
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import User, AuditLog, AuditAction, db
from config import settings

logger = logging.getLogger(__name__)


class AuthService:
    """Authentication service for user management and JWT handling."""
    
    @staticmethod
    def authenticate_user(username: str, password: str) -> Optional[Dict[str, Any]]:
        """
        Authenticate a user and return JWT token if successful.
        
        Args:
            username: User's username
            password: User's password
            
        Returns:
            Dict containing user info and JWT token, or None if authentication fails
        """
        try:
            # Find user by username
            user = User.query.filter_by(username=username).first()
            
            if not user:
                logger.warning(f"Authentication failed for unknown user: {username}")
                return None
            
            # Check if user is active
            if not user.is_active:
                logger.warning(f"Authentication failed for inactive user: {username}")
                return None
            
            # Verify password
            if not user.check_password(password):
                logger.warning(f"Authentication failed for user: {username}")
                return None
            
            # Update last login
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            # Create JWT token
            access_token = create_access_token(
                identity=user.id,
                expires_delta=timedelta(minutes=settings.jwt_expiration_minutes)
            )
            
            # Log successful login
            AuditLog.log_action(
                action=AuditAction.LOGIN,
                resource_type="user",
                description=f"User {user.username} logged in successfully",
                user_id=user.id,
                user_email=user.email
            )
            
            logger.info(f"User {username} authenticated successfully")
            
            return {
                "user": user.to_dict(),
                "access_token": access_token,
                "token_type": "Bearer"
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error during authentication for user {username}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error during authentication for user {username}: {e}")
            return None
    
    @staticmethod
    def get_user_by_id(user_id: int) -> Optional[User]:
        """
        Get user by ID.
        
        Args:
            user_id: User's ID
            
        Returns:
            User object or None if not found
        """
        try:
            return User.query.get(user_id)
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving user {user_id}: {e}")
            return None
    
    @staticmethod
    def get_user_by_email(email: str) -> Optional[User]:
        """
        Get user by email.
        
        Args:
            email: User's email
            
        Returns:
            User object or None if not found
        """
        try:
            return User.query.filter_by(email=email).first()
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving user by email {email}: {e}")
            return None
    
    @staticmethod
    def create_user(
        username: str,
        email: str,
        password: str,
        full_name: str,
        role: str = "change_manager"
    ) -> Optional[User]:
        """
        Create a new user.
        
        Args:
            username: User's username
            email: User's email
            password: User's password
            full_name: User's full name
            role: User's role (default: change_manager)
            
        Returns:
            Created User object or None if creation fails
        """
        try:
            # Check if username already exists
            if User.query.filter_by(username=username).first():
                logger.warning(f"Username {username} already exists")
                return None
            
            # Check if email already exists
            if User.query.filter_by(email=email).first():
                logger.warning(f"Email {email} already exists")
                return None
            
            # Create user based on role
            if role == "admin":
                user = User.create_admin(username, email, password, full_name)
            else:
                user = User.create_change_manager(username, email, password, full_name)
            
            # Save to database
            user.save()
            
            # Log user creation
            AuditLog.log_action(
                action=AuditAction.CREATE,
                resource_type="user",
                description=f"User {username} created with role {role}",
                user_id=user.id,
                user_email=user.email
            )
            
            logger.info(f"User {username} created successfully")
            return user
            
        except SQLAlchemyError as e:
            logger.error(f"Database error creating user {username}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error creating user {username}: {e}")
            return None
    
    @staticmethod
    def validate_token(token: str) -> Optional[Dict[str, Any]]:
        """
        Validate a JWT token and return user information.
        
        Args:
            token: JWT token string
            
        Returns:
            Dict containing user info if valid, None if invalid
        """
        try:
            # Decode token
            decoded_token = decode_token(token)
            
            # Get user
            user_id = decoded_token.get('sub')
            user = AuthService.get_user_by_id(user_id)
            
            if not user or not user.is_active:
                return None
            
            return {
                "user_id": user.id,
                "username": user.username,
                "email": user.email,
                "role": user.role.value,
                "is_admin": user.is_admin(),
                "is_change_manager": user.is_change_manager()
            }
            
        except Exception as e:
            logger.error(f"Token validation error: {e}")
            return None
    
    @staticmethod
    def logout_user(user_id: int, token_jti: str) -> bool:
        """
        Log out a user (for future implementation with token blacklisting).
        
        Args:
            user_id: User's ID
            token_jti: Token JTI (JWT ID)
            
        Returns:
            True if logout successful, False otherwise
        """
        try:
            user = AuthService.get_user_by_id(user_id)
            if user:
                # Log logout action
                AuditLog.log_action(
                    action=AuditAction.LOGOUT,
                    resource_type="user",
                    description=f"User {user.username} logged out",
                    user_id=user.id,
                    user_email=user.email
                )
                logger.info(f"User {user.username} logged out successfully")
            
            return True
            
        except Exception as e:
            logger.error(f"Error during logout for user {user_id}: {e}")
            return False
    
    @staticmethod
    def change_password(user_id: int, current_password: str, new_password: str) -> bool:
        """
        Change user password.
        
        Args:
            user_id: User's ID
            current_password: Current password
            new_password: New password
            
        Returns:
            True if password changed successfully, False otherwise
        """
        try:
            user = AuthService.get_user_by_id(user_id)
            if not user:
                return False
            
            # Verify current password
            if not user.check_password(current_password):
                logger.warning(f"Password change failed for user {user.username}: incorrect current password")
                return False
            
            # Set new password
            user.set_password(new_password)
            user.save()
            
            # Log password change
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="user",
                description=f"Password changed for user {user.username}",
                user_id=user.id,
                user_email=user.email
            )
            
            logger.info(f"Password changed successfully for user {user.username}")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"Database error changing password for user {user_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error changing password for user {user_id}: {e}")
            return False
    
    @staticmethod
    def is_token_expired(token: str) -> bool:
        """
        Check if a token is expired.
        
        Args:
            token: JWT token string
            
        Returns:
            True if token is expired, False otherwise
        """
        try:
            decoded_token = decode_token(token)
            exp_timestamp = decoded_token.get('exp')
            current_timestamp = datetime.utcnow().timestamp()
            
            return current_timestamp > exp_timestamp
            
        except Exception as e:
            logger.error(f"Error checking token expiration: {e}")
            return True  # Treat as expired if we can't validate
    
    @staticmethod
    def get_token_expiration(token: str) -> Optional[datetime]:
        """
        Get token expiration time.
        
        Args:
            token: JWT token string
            
        Returns:
            Expiration datetime or None if invalid
        """
        try:
            decoded_token = decode_token(token)
            exp_timestamp = decoded_token.get('exp')
            return datetime.fromtimestamp(exp_timestamp)
            
        except Exception as e:
            logger.error(f"Error getting token expiration: {e}")
            return None