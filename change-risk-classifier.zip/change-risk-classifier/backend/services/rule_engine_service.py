"""
Rule Engine service for managing and executing business rules.
Provides dynamic rule evaluation and management functionality.
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import Rule, AuditLog, AuditAction
from config import settings

logger = logging.getLogger(__name__)


class RuleEngineService:
    """Rule Engine service for managing and executing business rules."""
    
    @staticmethod
    def get_active_rules(rule_type: Optional[str] = None) -> List[Rule]:
        """
        Get all active rules, optionally filtered by type.
        
        Args:
            rule_type: Optional rule type to filter by
            
        Returns:
            List of active rules, sorted by priority
        """
        try:
            query = Rule.query.filter_by(status="active")
            
            if rule_type:
                query = query.filter_by(rule_type=rule_type)
            
            rules = query.order_by(Rule.priority.asc()).all()
            return rules
            
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving active rules: {e}")
            return []
    
    @staticmethod
    def evaluate_rules(context: Dict[str, Any], rule_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Evaluate rules against a context and return results.
        
        Args:
            context: Dictionary containing context data for rule evaluation
            rule_type: Optional rule type to filter by
            
        Returns:
            List of rule evaluation results
        """
        results = []
        rules = RuleEngineService.get_active_rules(rule_type)
        
        for rule in rules:
            try:
                # Evaluate rule condition
                condition_result = rule.evaluate_condition(context)
                
                if condition_result:
                    # Execute rule action
                    action_result = rule.execute_action(context)
                    
                    result = {
                        "rule_name": rule.name,
                        "rule_type": rule.rule_type,
                        "condition_met": True,
                        "action_result": action_result,
                        "priority": rule.priority,
                        "description": rule.description
                    }
                    
                    results.append(result)
                    
                    # Log rule execution
                    AuditLog.log_action(
                        action=AuditAction.READ,
                        resource_type="rule",
                        description=f"Rule {rule.name} evaluated and executed",
                        resource_id=rule.name,
                        request_data={"context": context},
                        response_data={"result": action_result}
                    )
                    
            except Exception as e:
                logger.error(f"Error evaluating rule {rule.name}: {e}")
                
                # Log rule evaluation error
                AuditLog.log_action(
                    action=AuditAction.UPDATE,
                    resource_type="rule",
                    description=f"Error evaluating rule {rule.name}: {str(e)}",
                    resource_id=rule.name,
                    request_data={"context": context}
                )
        
        # Sort results by priority (lower number = higher priority)
        results.sort(key=lambda x: x["priority"])
        
        return results
    
    @staticmethod
    def create_rule(
        name: str,
        description: str,
        rule_type: str,
        condition: str,
        action: str,
        priority: int = 100,
        parameters: Optional[Dict[str, Any]] = None,
        created_by: Optional[str] = None
    ) -> Optional[Rule]:
        """
        Create a new rule.
        
        Args:
            name: Rule name
            description: Rule description
            rule_type: Rule type
            condition: Rule condition (Python expression)
            action: Rule action (Python expression)
            priority: Rule priority (lower = higher priority)
            parameters: Optional rule parameters
            created_by: User who created the rule
            
        Returns:
            Created Rule object or None if creation fails
        """
        try:
            # Check if rule name already exists
            if Rule.query.filter_by(name=name).first():
                logger.warning(f"Rule name {name} already exists")
                return None
            
            # Create rule
            rule = Rule(
                name=name,
                description=description,
                rule_type=rule_type,
                condition=condition,
                action=action,
                priority=priority,
                created_by=created_by,
                last_modified_by=created_by
            )
            
            # Set parameters if provided
            if parameters:
                rule.parameters = str(parameters)
            
            # Validate rule
            rule.validate_rule()
            
            # Save to database
            rule.save()
            
            # Log rule creation
            AuditLog.log_action(
                action=AuditAction.CREATE,
                resource_type="rule",
                description=f"Rule {name} created",
                resource_id=name,
                user_email=created_by,
                request_data={
                    "name": name,
                    "description": description,
                    "rule_type": rule_type,
                    "priority": priority
                }
            )
            
            logger.info(f"Rule {name} created successfully")
            return rule
            
        except SQLAlchemyError as e:
            logger.error(f"Database error creating rule {name}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error creating rule {name}: {e}")
            return None
    
    @staticmethod
    def update_rule(
        rule_id: int,
        name: Optional[str] = None,
        description: Optional[str] = None,
        rule_type: Optional[str] = None,
        condition: Optional[str] = None,
        action: Optional[str] = None,
        priority: Optional[int] = None,
        parameters: Optional[Dict[str, Any]] = None,
        status: Optional[str] = None,
        modified_by: Optional[str] = None
    ) -> Optional[Rule]:
        """
        Update an existing rule.
        
        Args:
            rule_id: Rule ID to update
            name: Optional new name
            description: Optional new description
            rule_type: Optional new rule type
            condition: Optional new condition
            action: Optional new action
            priority: Optional new priority
            parameters: Optional new parameters
            status: Optional new status
            modified_by: User who modified the rule
            
        Returns:
            Updated Rule object or None if update fails
        """
        try:
            rule = Rule.query.get(rule_id)
            if not rule:
                logger.warning(f"Rule {rule_id} not found")
                return None
            
            # Update rule fields
            if name is not None:
                rule.name = name
            if description is not None:
                rule.description = description
            if rule_type is not None:
                rule.rule_type = rule_type
            if condition is not None:
                rule.condition = condition
            if action is not None:
                rule.action = action
            if priority is not None:
                rule.priority = priority
            if status is not None:
                rule.status = status
            
            # Update parameters if provided
            if parameters is not None:
                rule.parameters = str(parameters)
            
            # Update last modified info
            if modified_by:
                rule.last_modified_by = modified_by
            
            # Re-validate rule
            rule.validate_rule()
            
            # Save to database
            rule.save()
            
            # Log rule update
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="rule",
                description=f"Rule {rule.name} updated",
                resource_id=rule.name,
                user_email=modified_by,
                request_data={
                    "rule_id": rule_id,
                    "name": name,
                    "description": description,
                    "rule_type": rule_type,
                    "priority": priority,
                    "status": status
                }
            )
            
            logger.info(f"Rule {rule.name} updated successfully")
            return rule
            
        except SQLAlchemyError as e:
            logger.error(f"Database error updating rule {rule_id}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error updating rule {rule_id}: {e}")
            return None
    
    @staticmethod
    def delete_rule(rule_id: int, deleted_by: Optional[str] = None) -> bool:
        """
        Delete a rule.
        
        Args:
            rule_id: Rule ID to delete
            deleted_by: User who deleted the rule
            
        Returns:
            True if deletion successful, False otherwise
        """
        try:
            rule = Rule.query.get(rule_id)
            if not rule:
                logger.warning(f"Rule {rule_id} not found")
                return False
            
            rule_name = rule.name
            
            # Delete rule from database
            rule.delete()
            
            # Log rule deletion
            AuditLog.log_action(
                action=AuditAction.DELETE,
                resource_type="rule",
                description=f"Rule {rule_name} deleted",
                resource_id=rule_name,
                user_email=deleted_by
            )
            
            logger.info(f"Rule {rule_name} deleted successfully")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"Database error deleting rule {rule_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error deleting rule {rule_id}: {e}")
            return False
    
    @staticmethod
    def get_rule_by_name(name: str) -> Optional[Rule]:
        """
        Get a rule by name.
        
        Args:
            name: Rule name
            
        Returns:
            Rule object or None if not found
        """
        try:
            return Rule.query.filter_by(name=name).first()
        except SQLAlchemyError as e:
            logger.error(f"Database error retrieving rule {name}: {e}")
            return None
    
    @staticmethod
    def validate_rule_syntax(condition: str, action: str) -> Dict[str, Any]:
        """
        Validate rule syntax without creating a rule.
        
        Args:
            condition: Rule condition (Python expression)
            action: Rule action (Python expression)
            
        Returns:
            Dict containing validation results
        """
        errors = []
        
        # Check if condition is valid Python
        try:
            compile(condition, "<rule_condition>", 'eval')
        except SyntaxError as e:
            errors.append(f"Invalid condition syntax: {e}")
        
        # Check if action is valid Python
        try:
            compile(action, "<rule_action>", 'exec')
        except SyntaxError as e:
            errors.append(f"Invalid action syntax: {e}")
        
        return {
            "is_valid": len(errors) == 0,
            "errors": errors
        }
    
    @staticmethod
    def get_rules_summary() -> Dict[str, Any]:
        """
        Get a summary of all rules.
        
        Returns:
            Dict containing rule statistics
        """
        try:
            total_rules = Rule.query.count()
            active_rules = Rule.query.filter_by(status="active").count()
            inactive_rules = Rule.query.filter_by(status="inactive").count()
            draft_rules = Rule.query.filter_by(status="draft").count()
            
            # Group by type
            rule_types = {}
            for rule_type in ["risk_classification", "validation", "approval", "notification"]:
                count = Rule.query.filter_by(rule_type=rule_type).count()
                rule_types[rule_type] = count
            
            return {
                "total_rules": total_rules,
                "active_rules": active_rules,
                "inactive_rules": inactive_rules,
                "draft_rules": draft_rules,
                "by_type": rule_types
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting rules summary: {e}")
            return {}
    
    @staticmethod
    def reset_to_default_rules() -> bool:
        """
        Reset rules to default configuration.
        
        Returns:
            True if reset successful, False otherwise
        """
        try:
            # Delete all existing rules
            Rule.query.delete()
            
            # Create default rules
            default_rules = Rule.create_risk_classification_rules()
            
            for rule in default_rules:
                rule.save()
            
            # Log rule reset
            AuditLog.log_action(
                action=AuditAction.RULE_UPDATE,
                resource_type="rule",
                description="Rules reset to default configuration",
                user_email="system"
            )
            
            logger.info("Rules reset to default configuration successfully")
            return True
            
        except SQLAlchemyError as e:
            logger.error(f"Database error resetting rules: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error resetting rules: {e}")
            return False