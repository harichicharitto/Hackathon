"""
Risk Classifier service for automated risk assessment and scoring.
Implements the core risk classification logic using rule engine and AI models.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError
import logging

from models import ChangeRequest, RiskScore, Rule, AuditLog, AuditAction
from services.rule_engine_service import RuleEngineService
from config import settings

logger = logging.getLogger(__name__)


class RiskClassifierService:
    """Risk Classifier service for automated risk assessment and scoring."""
    
    @staticmethod
    def classify_change_risk(change_request: ChangeRequest) -> Dict[str, Any]:
        """
        Classify change request risk using rule engine and business logic.
        
        Args:
            change_request: ChangeRequest object to classify
            
        Returns:
            Dict containing risk classification results
        """
        try:
            # Build context for rule evaluation
            context = {
                'change_type': change_request.change_type.value,
                'change_window': change_request.change_window.value,
                'critical_ci': change_request.critical_ci,
                'impacted_services': RiskClassifierService._parse_services(change_request.impacted_services),
                'dependencies': RiskClassifierService._parse_dependencies(change_request.dependencies),
                'blast_radius': change_request.blast_radius,
                'rollback_plan': change_request.rollback_plan,
                'test_evidence': change_request.test_evidence,
                'business_owner': change_request.business_owner,
                'technical_owner': change_request.technical_owner
            }
            
            # Evaluate rules
            rule_results = RuleEngineService.evaluate_rules(context, "risk_classification")
            
            # Determine risk level from rules
            risk_level = "Low"  # Default
            risk_score = 20     # Default
            reasoning = "Default classification"
            
            if rule_results:
                # Use the highest priority rule result
                best_result = rule_results[0]
                if isinstance(best_result.get('action_result'), dict):
                    risk_data = best_result['action_result']
                    risk_level = risk_data.get('risk_level', risk_level)
                    risk_score = risk_data.get('risk_score', risk_score)
                    reasoning = risk_data.get('reason', reasoning)
            
            # Calculate detailed risk scores
            detailed_scores = RiskClassifierService._calculate_detailed_scores(change_request)
            
            # Create risk score record
            risk_score_record = RiskScore(
                change_request_id=change_request.id,
                risk_level=risk_level,
                risk_score=risk_score,
                base_score=risk_score,
                ci_impact_score=detailed_scores['ci_impact'],
                timing_score=detailed_scores['timing'],
                scope_score=detailed_scores['scope'],
                rollback_score=detailed_scores['rollback'],
                ci_criticality='critical' if change_request.critical_ci else 'non-critical',
                change_window=change_request.change_window.value,
                impacted_systems_count=len(context['impacted_services']),
                dependencies_count=len(context['dependencies']),
                rollback_available=change_request.rollback_plan,
                assessment_method="rule_engine",
                assessed_by="system",
                risk_reasoning=reasoning,
                risk_factors=str(detailed_scores['factors'])
            )
            
            risk_score_record.save()
            
            # Update change request with risk classification
            change_request.risk_level = risk_level
            change_request.risk_score = risk_score
            change_request.save()
            
            # Log risk classification
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="change_request",
                description=f"Risk classified for change {change_request.title}",
                resource_id=str(change_request.id),
                request_data={"change_id": change_request.id},
                response_data={
                    "risk_level": risk_level,
                    "risk_score": risk_score,
                    "reasoning": reasoning
                }
            )
            
            return {
                "risk_level": risk_level,
                "risk_score": risk_score,
                "reasoning": reasoning,
                "detailed_scores": detailed_scores,
                "factors": detailed_scores['factors'],
                "is_acceptable": risk_level in ["Low", "Medium"]
            }
            
        except Exception as e:
            logger.error(f"Error classifying risk for change {change_request.id}: {e}")
            return {
                "risk_level": "Unknown",
                "risk_score": 0,
                "reasoning": f"Error during classification: {str(e)}",
                "detailed_scores": {},
                "factors": [],
                "is_acceptable": False
            }
    
    @staticmethod
    def _parse_services(services_str: Optional[str]) -> List[str]:
        """Parse impacted services string to list."""
        if not services_str:
            return []
        try:
            return eval(services_str)  # Convert JSON string to list
        except:
            return []
    
    @staticmethod
    def _parse_dependencies(dependencies_str: Optional[str]) -> List[str]:
        """Parse dependencies string to list."""
        if not dependencies_str:
            return []
        try:
            return eval(dependencies_str)  # Convert JSON string to list
        except:
            return []
    
    @staticmethod
    def _calculate_detailed_scores(change_request: ChangeRequest) -> Dict[str, Any]:
        """Calculate detailed risk scores for different factors."""
        scores = {
            'ci_impact': 0,
            'timing': 0,
            'scope': 0,
            'rollback': 0,
            'factors': []
        }
        
        # Critical Infrastructure Impact
        if change_request.critical_ci:
            scores['ci_impact'] = 40
            scores['factors'].append("Critical Infrastructure")
        else:
            scores['ci_impact'] = 10
            scores['factors'].append("Non-critical Infrastructure")
        
        # Timing Impact
        if change_request.change_window == "business_hours":
            scores['timing'] = 30
            scores['factors'].append("Business Hours")
        elif change_request.change_window == "maintenance_window":
            scores['timing'] = 5
            scores['factors'].append("Maintenance Window")
        else:
            scores['timing'] = 15
            scores['factors'].append("Off-hours")
        
        # Scope Impact
        impacted_services = RiskClassifierService._parse_services(change_request.impacted_services)
        if len(impacted_services) > 3:
            scores['scope'] = 30
            scores['factors'].append("Large Scope (>3 systems)")
        elif len(impacted_services) > 1:
            scores['scope'] = 20
            scores['factors'].append("Medium Scope (2-3 systems)")
        else:
            scores['scope'] = 5
            scores['factors'].append("Small Scope (1 system)")
        
        # Rollback Capability
        if change_request.rollback_plan:
            scores['rollback'] = 5
            scores['factors'].append("Rollback Available")
        else:
            scores['rollback'] = 25
            scores['factors'].append("No Rollback Plan")
        
        return scores
    
    @staticmethod
    def get_risk_trends(days: int = 30) -> Dict[str, Any]:
        """
        Get risk trends over the specified number of days.
        
        Args:
            days: Number of days to look back
            
        Returns:
            Dict containing risk trend data
        """
        try:
            from datetime import timedelta
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            # Get risk scores in the time period
            risk_scores = RiskScore.query.filter(
                RiskScore.created_at >= cutoff_date
            ).all()
            
            # Calculate trends
            total_changes = len(risk_scores)
            high_risk_count = sum(1 for rs in risk_scores if rs.risk_level == "High")
            medium_risk_count = sum(1 for rs in risk_scores if rs.risk_level == "Medium")
            low_risk_count = sum(1 for rs in risk_scores if rs.risk_level == "Low")
            
            # Calculate average risk score
            avg_risk_score = sum(rs.risk_score for rs in risk_scores) / max(total_changes, 1)
            
            return {
                "period_days": days,
                "total_changes": total_changes,
                "high_risk_count": high_risk_count,
                "medium_risk_count": medium_risk_count,
                "low_risk_count": low_risk_count,
                "high_risk_percentage": (high_risk_count / max(total_changes, 1)) * 100,
                "medium_risk_percentage": (medium_risk_count / max(total_changes, 1)) * 100,
                "low_risk_percentage": (low_risk_count / max(total_changes, 1)) * 100,
                "average_risk_score": round(avg_risk_score, 2),
                "trend_direction": "stable"  # Could be calculated based on historical data
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting risk trends: {e}")
            return {}
    
    @staticmethod
    def get_risk_by_change_type() -> Dict[str, Any]:
        """
        Get risk distribution by change type.
        
        Returns:
            Dict containing risk distribution by change type
        """
        try:
            from sqlalchemy import func
            
            # Group by change type and risk level
            results = db.session.query(
                ChangeRequest.change_type,
                RiskScore.risk_level,
                func.count(RiskScore.id).label('count')
            ).join(RiskScore).group_by(
                ChangeRequest.change_type,
                RiskScore.risk_level
            ).all()
            
            # Organize results
            distribution = {}
            for change_type, risk_level, count in results:
                if change_type not in distribution:
                    distribution[change_type] = {}
                distribution[change_type][risk_level] = count
            
            return distribution
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting risk by change type: {e}")
            return {}
    
    @staticmethod
    def validate_risk_classification(change_request: ChangeRequest) -> Dict[str, Any]:
        """
        Validate risk classification against business rules.
        
        Args:
            change_request: ChangeRequest object to validate
            
        Returns:
            Dict containing validation results
        """
        validation_results = {
            "is_valid": True,
            "warnings": [],
            "errors": [],
            "suggestions": []
        }
        
        # Check mandatory fields
        missing_fields = change_request.get_missing_fields()
        if missing_fields:
            validation_results["errors"].append(f"Missing mandatory fields: {', '.join(missing_fields)}")
            validation_results["is_valid"] = False
        
        # Validate risk level consistency
        expected_risk = change_request.get_risk_classification()
        if change_request.risk_level and change_request.risk_level != expected_risk:
            validation_results["warnings"].append(
                f"Risk level '{change_request.risk_level}' may not match business rules. Expected: {expected_risk}"
            )
        
        # Check for high-risk indicators
        if (change_request.critical_ci and 
            change_request.change_window == "business_hours" and 
            not change_request.rollback_plan):
            if change_request.risk_level != "High":
                validation_results["errors"].append(
                    "Change appears to be high-risk based on business rules but is not classified as such"
                )
                validation_results["is_valid"] = False
        
        # Provide suggestions
        if not change_request.rollback_plan:
            validation_results["suggestions"].append("Consider adding a rollback plan to reduce risk")
        
        if change_request.change_window == "business_hours":
            validation_results["suggestions"].append("Consider scheduling during maintenance window to reduce risk")
        
        return validation_results
    
    @staticmethod
    def reclassify_all_changes() -> Dict[str, Any]:
        """
        Reclassify all existing change requests.
        
        Returns:
            Dict containing reclassification results
        """
        try:
            change_requests = ChangeRequest.query.all()
            results = {
                "total_processed": 0,
                "reclassified": 0,
                "errors": 0
            }
            
            for change_request in change_requests:
                try:
                    RiskClassifierService.classify_change_risk(change_request)
                    results["reclassified"] += 1
                except Exception as e:
                    logger.error(f"Error reclassifying change {change_request.id}: {e}")
                    results["errors"] += 1
                
                results["total_processed"] += 1
            
            # Log bulk reclassification
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="change_request",
                description=f"Bulk risk reclassification completed: {results['reclassified']} reclassified, {results['errors']} errors",
                user_email="system"
            )
            
            return results
            
        except SQLAlchemyError as e:
            logger.error(f"Database error during bulk reclassification: {e}")
            return {"error": str(e)}
    
    @staticmethod
    def get_risk_summary_for_dashboard() -> Dict[str, Any]:
        """
        Get risk summary data for dashboard display.
        
        Returns:
            Dict containing dashboard-ready risk data
        """
        try:
            # Get counts by risk level
            high_risk = RiskScore.query.filter_by(risk_level="High").count()
            medium_risk = RiskScore.query.filter_by(risk_level="Medium").count()
            low_risk = RiskScore.query.filter_by(risk_level="Low").count()
            total_changes = ChangeRequest.query.count()
            
            # Get recent changes
            recent_changes = ChangeRequest.query.order_by(
                ChangeRequest.created_at.desc()
            ).limit(10).all()
            
            # Get trends
            trends = RiskClassifierService.get_risk_trends(30)
            
            return {
                "total_changes": total_changes,
                "risk_distribution": {
                    "high": high_risk,
                    "medium": medium_risk,
                    "low": low_risk
                },
                "recent_changes": [cr.to_dict() for cr in recent_changes],
                "trends": trends,
                "summary": {
                    "high_risk_percentage": (high_risk / max(total_changes, 1)) * 100,
                    "average_risk_score": trends.get("average_risk_score", 0),
                    "acceptable_risk_percentage": ((medium_risk + low_risk) / max(total_changes, 1)) * 100
                }
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting risk summary: {e}")
            return {}