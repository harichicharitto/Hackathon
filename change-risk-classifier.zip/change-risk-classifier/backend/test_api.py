#!/usr/bin/env python3
"""
Test script to verify the API is working correctly.
"""

from app import create_app

def test_api():
    """Test the API endpoints."""
    app = create_app()
    
    with app.test_client() as client:
        # Test health endpoint
        response = client.get('/api/health')
        print("Health check:", response.get_json())
        
        # Test root endpoint
        response = client.get('/')
        print("Root endpoint:", response.get_json())
        
        # Test auth endpoints
        response = client.post('/api/auth/login', json={'username': 'admin', 'password': 'admin123'})
        print("Auth login:", response.get_json())

if __name__ == '__main__':
    test_api()