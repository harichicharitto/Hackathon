"""
Main Flask application for the Change Risk Classifier.
Sets up the application, database, and API endpoints.
"""

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
import logging
import os
import subprocess
import threading
import time
import json
import csv
import random
from datetime import datetime

from config import settings, validate_config
from models import db
from services.auth_service import AuthService
from services.rule_engine_service import RuleEngineService
from services.ai_risk_service import AIRiskService

# Import blueprints
from api.auth import auth_bp
from api.users import users_bp
from api.change_requests import change_requests_bp
from api.rules import rules_bp
from api.dashboard import dashboard_bp
from api.export import export_bp

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper()),
    format=settings.log_format
)
logger = logging.getLogger(__name__)


def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    
    # Configure app
    app.config['SECRET_KEY'] = settings.secret_key
    app.config['SQLALCHEMY_DATABASE_URI'] = settings.database_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ECHO'] = settings.database_echo
    app.config['JWT_SECRET_KEY'] = settings.secret_key
    app.config['JWT_ALGORITHM'] = settings.jwt_algorithm
    app.config['JWT_ACCESS_TOKEN_EXPIRES'] = settings.jwt_expiration_minutes * 60
    
    # Enable CORS
    CORS(app, origins=["http://localhost:3000", "http://127.0.0.1:3000"])
    
    # Initialize extensions
    db.init_app(app)
    migrate = Migrate(app, db)
    jwt = JWTManager(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(users_bp, url_prefix='/api/users')
    app.register_blueprint(change_requests_bp, url_prefix='/api/changes')
    app.register_blueprint(rules_bp, url_prefix='/api/rules')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    app.register_blueprint(export_bp, url_prefix='/api/export')
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Not found"}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return jsonify({"error": "Internal server error"}), 500
    
    @app.errorhandler(Exception)
    def handle_exception(e):
        logger.error(f"Unhandled exception: {e}")
        return jsonify({"error": "An unexpected error occurred"}), 500
    
    # Health check endpoint
    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Health check endpoint."""
        return jsonify({
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "1.0.0",
            "environment": settings.environment
        })
    
    # API root endpoint (for API documentation)
    @app.route('/api/', methods=['GET'])
    def api_root():
        """API root endpoint with API information."""
        return jsonify({
            "name": settings.app_name,
            "version": "1.0.0",
            "description": "Change Request Risk Classification & Approval Assistant",
            "endpoints": {
                "health": "/api/health",
                "auth": "/api/auth/*",
                "users": "/api/users/*",
                "changes": "/api/changes/*",
                "rules": "/api/rules/*",
                "dashboard": "/api/dashboard/*",
                "export": "/api/export/*"
            },
            "documentation": "API documentation available at /api/docs (when implemented)"
        })
    
    # Serve frontend files
    @app.route('/<path:filename>')
    def serve_frontend(filename):
        """Serve frontend files from the frontend directory."""
        frontend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend')
        return send_from_directory(frontend_dir, filename)
    
    @app.route('/')
    def serve_index():
        """Serve the main index.html file."""
        frontend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend')
        return send_from_directory(frontend_dir, 'index.html')
    
    # Initialize database and default data
    @app.before_request
    def initialize_app():
        """Initialize the application with default data.""" 
        try:
            # Create all tables
            db.create_all()
            
            # Create default admin user if none exists
            if not User.query.filter_by(role="admin").first():
                admin_user = User.create_admin(
                    username="admin",
                    email="admin@company.com",
                    password="admin123",
                    full_name="System Administrator"
                )
                try:
                    db.session.add(admin_user)
                    db.session.commit()
                    logger.info("Created default admin user: admin/admin123")
                except Exception as e:
                    db.session.rollback()
                    logger.warning(f"Admin user already exists: {e}")
            
            # Create default rules if none exist
            if not Rule.query.first():
                default_rules = Rule.create_risk_classification_rules()
                for rule in default_rules:
                    db.session.add(rule)
                db.session.commit()
                logger.info("Created default risk classification rules")
            
            # Create sample data if no changes exist
            if not ChangeRequest.query.first():
                create_sample_data()
                logger.info("Created sample change requests")
            
            # Create sample risk scores for existing changes
            if ChangeRequest.query.first() and not RiskScore.query.first():
                create_risk_scores_from_ai_analysis()
                logger.info("Created sample risk scores using AI analysis")
            
            logger.info("Application initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing application: {e}")
    
    return app


# Import models after app creation to avoid circular imports
from models import User, Rule, ChangeRequest, RiskScore, AuditLog


def create_sample_data():
    """Create sample change requests from CSV file with AI-driven risk assessment."""
    import random
    from datetime import datetime, timedelta
    
    # Try multiple possible paths for the CSV file
    possible_paths = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sample_data.csv'),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sample_data.csv'),
        'sample_data.csv'
    ]
    
    csv_file_path = None
    for path in possible_paths:
        if os.path.exists(path):
            csv_file_path = path
            break
    
    if not csv_file_path:
        logger.error("Sample data CSV file not found in any of the expected locations")
        # Fallback to hardcoded data if CSV is not available
        create_fallback_sample_data()
        return
    
    logger.info(f"Found sample data CSV at: {csv_file_path}")
    
    try:
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            csv_reader = csv.DictReader(file)
            changes_created = 0
            
            for row in csv_reader:
                # Generate random dates within the last 30 days
                days_ago = random.randint(1, 30)
                created_at = datetime.utcnow() - timedelta(days=days_ago)
                
                # Generate random start and end times within the created_at date
                start_time = created_at.replace(hour=2, minute=0, second=0, microsecond=0)  # 2 AM
                end_time = start_time.replace(hour=6, minute=0, second=0, microsecond=0)   # 6 AM
                
                # Parse impacted services from CSV (semicolon-separated)
                impacted_services = [service.strip() for service in row['impacted_services'].split(';')]
                
                # Create change request without risk level (will be determined by AI)
                change = ChangeRequest(
                    title=row['title'],
                    description=row['description'],
                    change_type=row['change_type'],
                    change_window=row['change_window'],
                    critical_ci=row['critical_ci'].lower() == 'true',
                    impacted_services=json.dumps(impacted_services),
                    rollback_plan=row['rollback_plan'].lower() == 'true',
                    business_owner=row['business_owner'],
                    technical_owner=row['technical_owner'],
                    status='pending',  # Default status
                    start_time=start_time,
                    end_time=end_time,
                    created_at=created_at,
                    updated_at=created_at
                )
                
                db.session.add(change)
                changes_created += 1
            
            db.session.commit()
            logger.info(f"Created {changes_created} change requests from CSV file")
            
            # Create risk scores for all changes using AI analysis
            create_risk_scores_from_ai_analysis()
            
    except Exception as e:
        logger.error(f"Error reading sample data from CSV: {e}")
        logger.error(f"CSV file path: {csv_file_path}")
        # Fallback to hardcoded data if CSV reading fails
        create_fallback_sample_data()


def create_fallback_sample_data():
    """Fallback function to create sample data if CSV reading fails."""
    import random
    from datetime import datetime, timedelta
    
    logger.info("Using fallback sample data creation")
    
    sample_changes = [
        {
            'title': 'Database Server Maintenance',
            'description': 'Routine maintenance on primary database server including patch updates and performance tuning',
            'change_type': 'standard',
            'change_window': 'maintenance_window',
            'critical_ci': False,
            'impacted_services': ['Database Service', 'Application Backend', 'Reporting System'],
            'rollback_plan': True,
            'business_owner': 'John Smith',
            'technical_owner': 'Sarah Johnson',
            'status': 'pending'
        }
    ]
    
    for change_data in sample_changes:
        # Generate random dates within the last 30 days
        days_ago = random.randint(1, 30)
        created_at = datetime.utcnow() - timedelta(days=days_ago)
        
        # Generate random start and end times within the created_at date
        start_time = created_at.replace(hour=2, minute=0, second=0, microsecond=0)
        end_time = start_time.replace(hour=6, minute=0, second=0, microsecond=0)
        
        change = ChangeRequest(
            title=change_data['title'],
            description=change_data['description'],
            change_type=change_data['change_type'],
            change_window=change_data['change_window'],
            critical_ci=change_data['critical_ci'],
            impacted_services=json.dumps(change_data['impacted_services']),
            rollback_plan=change_data['rollback_plan'],
            business_owner=change_data['business_owner'],
            technical_owner=change_data['technical_owner'],
            status=change_data['status'],
            start_time=start_time,
            end_time=end_time,
            created_at=created_at,
            updated_at=created_at
        )
        
        db.session.add(change)
    
    db.session.commit()
    
    # Create risk scores for all changes using AI analysis
    create_risk_scores_from_ai_analysis()


def create_risk_scores_from_ai_analysis():
    """Create risk scores for existing changes using AI-driven analysis."""
    import random
    from datetime import datetime, timedelta
    
    changes = ChangeRequest.query.all()
    
    for change in changes:
        # AI-driven risk assessment based on business rules
        risk_score, risk_level, reason_parts = analyze_risk_with_ai(change)
        
        # Create AI impact analysis
        impact_analysis = generate_ai_impact_analysis(change, risk_score, risk_level)
        
        # Parse impacted services for count
        try:
            impacted_services = json.loads(change.impacted_services) if change.impacted_services else []
        except:
            impacted_services = []
        
        risk_score_record = RiskScore(
            change_request_id=change.id,
            risk_level=risk_level,
            risk_score=risk_score,
            base_score=risk_score,  # Use base_score instead of reason
            risk_reasoning=f"Risk Score: {risk_score}/100. {'; '.join(reason_parts)}",
            assessment_method="AI-powered",
            ci_criticality="critical" if change.critical_ci else "non-critical",
            change_window=change.change_window,
            impacted_systems_count=len(impacted_services),
            rollback_available=change.rollback_plan,
            created_at=change.created_at
        )
        
        # Update the change request with the AI-determined risk level
        change.risk_level = risk_level
        change.status = 'approved' if risk_level == 'Low' else 'pending'
        
        db.session.add(risk_score_record)
    
    db.session.commit()
    logger.info("Created risk scores using AI analysis")


def analyze_risk_with_ai(change):
    """AI-driven risk analysis using the AI Risk Service."""
    # Create AI Risk Service instance
    ai_service = AIRiskService()
    
    # Prepare change context for AI analysis
    try:
        impacted_services = json.loads(change.impacted_services) if change.impacted_services else []
    except:
        impacted_services = []
    
    change_context = {
        'title': change.title,
        'description': change.description,
        'change_type': change.change_type,
        'change_window': change.change_window,
        'critical_ci': change.critical_ci,
        'impacted_services': impacted_services,
        'rollback_plan': change.rollback_plan,
        'business_owner': change.business_owner,
        'technical_owner': change.technical_owner
    }
    
    # Get AI analysis result
    ai_result = ai_service.analyze_risk_with_ai(change_context)
    
    # Extract required values from AI result
    risk_score = ai_result.get('risk_score', 50)
    risk_level = ai_result.get('risk_level', 'Medium')
    reason = ai_result.get('reason', 'AI analysis completed')
    
    # Convert reason to list format for compatibility
    reason_parts = [reason] if isinstance(reason, str) else reason
    
    return risk_score, risk_level, reason_parts




def generate_ai_impact_analysis(change, risk_score, risk_level):
    """Generate AI-powered impact analysis for a change request."""
    
    # Analyze impact based on change characteristics
    impact_factors = []
    
    if change.critical_ci:
        impact_factors.append("CRITICAL: Change affects critical infrastructure components")
    
    # Parse impacted_services from JSON string for impact analysis
    try:
        impacted_services = json.loads(change.impacted_services) if change.impacted_services else []
    except:
        impacted_services = []
    
    if len(impacted_services) > 3:
        impact_factors.append(f"HIGH: {len(impacted_services)} services will be affected")
    elif len(impacted_services) > 1:
        impact_factors.append(f"MEDIUM: {len(impacted_services)} services will be affected")
    else:
        impact_factors.append("LOW: Single service impact")
    
    if change.change_window == 'business_hours':
        impact_factors.append("CRITICAL: Change during business hours increases user impact")
    elif change.change_window == 'emergency':
        impact_factors.append("HIGH: Emergency change indicates urgent business need")
    
    if not change.rollback_plan:
        impact_factors.append("CRITICAL: No rollback plan increases recovery risk")
    
    # Generate AI recommendation
    if risk_score >= 80:
        recommendation = "REJECT: High risk change requires additional mitigation strategies"
        confidence = "High"
    elif risk_score >= 60:
        recommendation = "CONDITIONAL APPROVAL: Proceed with additional monitoring and stakeholder notification"
        confidence = "Medium"
    elif risk_score >= 40:
        recommendation = "APPROVE WITH MONITORING: Standard change with routine oversight"
        confidence = "Medium"
    else:
        recommendation = "APPROVE: Low risk change suitable for standard approval process"
        confidence = "High"
    
    # Generate specific mitigation suggestions
    mitigation_suggestions = []
    if change.critical_ci and not change.rollback_plan:
        mitigation_suggestions.append("Implement rollback procedures before execution")
    if change.change_window == 'business_hours':
        mitigation_suggestions.append("Consider user communication and support coverage")
    if len(change.impacted_services) > 2:
        mitigation_suggestions.append("Coordinate with all service owners for monitoring")
    
    analysis = {
        "risk_score": risk_score,
        "risk_level": risk_level,
        "impact_factors": impact_factors,
        "ai_recommendation": recommendation,
        "confidence_level": confidence,
        "mitigation_suggestions": mitigation_suggestions,
        "business_impact": "Medium" if change.critical_ci else "Low",
        "technical_complexity": "High" if len(change.impacted_services) > 2 else "Medium" if change.critical_ci else "Low"
    }
    
    return analysis


def main():
    """Main entry point for running the application."""
    try:
        # Validate configuration
        validate_config()
        
        # Create app
        app = create_app()
        
        # Run app
        if settings.environment == "development":
            app.run(
                host='0.0.0.0',
                port=5000,
                debug=True
            )
        else:
            # In production, this would be served by a WSGI server
            app.run(
                host='0.0.0.0',
                port=5000,
                debug=False
            )
            
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        raise


if __name__ == '__main__':
    main()