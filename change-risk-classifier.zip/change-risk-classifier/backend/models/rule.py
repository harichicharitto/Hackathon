"""
Rule model for storing and managing risk classification rules.
Provides dynamic rule configuration for the rule engine.
"""

from enum import Enum as PyEnum
from typing import Optional, Dict, Any, List
from sqlalchemy import String, Text, Integer, Boolean, JSON
from sqlalchemy.orm import Mapped, mapped_column
from .base import BaseModel, db


class RuleType(PyEnum):
    """Types of rules."""
    RISK_CLASSIFICATION = "risk_classification"
    VALIDATION = "validation"
    APPROVAL = "approval"
    NOTIFICATION = "notification"


class RuleStatus(PyEnum):
    """Status of rules."""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DRAFT = "draft"


class Rule(BaseModel):
    """Rule model for storing and managing business rules."""
    
    __tablename__ = "rules"
    
    # Rule identification
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    description: Mapped[str] = mapped_column(Text, nullable=True)
    rule_type: Mapped[str] = mapped_column(String(30), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default=RuleStatus.ACTIVE.value, nullable=False)
    
    # Rule configuration
    condition: Mapped[str] = mapped_column(Text, nullable=False)  # Python expression string
    action: Mapped[str] = mapped_column(Text, nullable=False)     # Python expression string
    priority: Mapped[int] = mapped_column(Integer, default=100, nullable=False)  # Lower number = higher priority
    
    # Rule metadata
    version: Mapped[str] = mapped_column(String(20), default="1.0", nullable=False)
    created_by: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    last_modified_by: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # Rule parameters (for dynamic configuration)
    parameters: Mapped[Optional[str]] = mapped_column(JSON, nullable=True)  # JSON object
    
    # Rule validation
    is_valid: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    validation_errors: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert rule to dictionary."""
        data = super().to_dict()
        
        # Parse JSON parameters if they exist
        if self.parameters:
            try:
                data['parameters'] = eval(self.parameters)  # Convert JSON string to dict
            except:
                data['parameters'] = {}
        
        return data
    
    def evaluate_condition(self, context: Dict[str, Any]) -> bool:
        """Evaluate the rule condition against the provided context."""
        try:
            # Create a safe evaluation context
            safe_dict = {
                'context': context,
                'True': True,
                'False': False,
                'None': None,
                # Add any safe functions that might be needed
                'len': len,
                'str': str,
                'int': int,
                'float': float,
                'bool': bool,
            }
            
            # Evaluate the condition
            result = eval(self.condition, {"__builtins__": {}}, safe_dict)
            return bool(result)
            
        except Exception as e:
            # Log the error and return False
            print(f"Error evaluating rule '{self.name}': {e}")
            return False
    
    def execute_action(self, context: Dict[str, Any]) -> Any:
        """Execute the rule action against the provided context."""
        try:
            # Create a safe evaluation context
            safe_dict = {
                'context': context,
                'result': None,
                'True': True,
                'False': False,
                'None': None,
                # Add any safe functions that might be needed
                'len': len,
                'str': str,
                'int': int,
                'float': float,
                'bool': bool,
            }
            
            # Execute the action
            exec(self.action, {"__builtins__": {}}, safe_dict)
            
            return safe_dict.get('result')
            
        except Exception as e:
            # Log the error and return None
            print(f"Error executing action for rule '{self.name}': {e}")
            return None
    
    def validate_rule(self) -> bool:
        """Validate the rule syntax and logic."""
        errors = []
        
        # Check if condition is valid Python
        try:
            compile(self.condition, f"<rule_{self.name}_condition>", 'eval')
        except SyntaxError as e:
            errors.append(f"Invalid condition syntax: {e}")
        
        # Check if action is valid Python
        try:
            compile(self.action, f"<rule_{self.name}_action>", 'exec')
        except SyntaxError as e:
            errors.append(f"Invalid action syntax: {e}")
        
        # Check if parameters are valid JSON
        if self.parameters:
            try:
                eval(self.parameters)  # This should be a JSON string
            except:
                errors.append("Invalid parameters JSON format")
        
        # Update validation status
        self.is_valid = len(errors) == 0
        self.validation_errors = "; ".join(errors) if errors else None
        
        return self.is_valid
    
    @classmethod
    def create_risk_classification_rules(cls) -> List['Rule']:
        """Create default risk classification rules."""
        rules = []
        
        # High Risk Rule
        high_risk_rule = cls(
            name="high_risk_classification",
            description="Classify change as High Risk",
            rule_type=RuleType.RISK_CLASSIFICATION.value,
            condition="context.get('critical_ci', False) and context.get('change_window') == 'business_hours' and len(context.get('impacted_services', [])) > 1 and not context.get('rollback_plan', False)",
            action="result = {'risk_level': 'High', 'risk_score': 90, 'reason': 'Critical CI during business hours with multiple systems and no rollback plan'}",
            priority=10,
            created_by="system",
            last_modified_by="system"
        )
        rules.append(high_risk_rule)
        
        # Medium Risk Rule
        medium_risk_rule = cls(
            name="medium_risk_classification",
            description="Classify change as Medium Risk",
            rule_type=RuleType.RISK_CLASSIFICATION.value,
            condition="not context.get('critical_ci', False) and context.get('blast_radius') in ['small', 'medium'] and context.get('rollback_plan', False)",
            action="result = {'risk_level': 'Medium', 'risk_score': 50, 'reason': 'Non-critical CI with limited blast radius and rollback available'}",
            priority=20,
            created_by="system",
            last_modified_by="system"
        )
        rules.append(medium_risk_rule)
        
        # Low Risk Rule
        low_risk_rule = cls(
            name="low_risk_classification",
            description="Classify change as Low Risk",
            rule_type=RuleType.RISK_CLASSIFICATION.value,
            condition="context.get('change_type') == 'standard' and context.get('change_window') == 'maintenance_window' and len(context.get('impacted_services', [])) <= 1",
            action="result = {'risk_level': 'Low', 'risk_score': 20, 'reason': 'Standard change during maintenance window with single system impact'}",
            priority=30,
            created_by="system",
            last_modified_by="system"
        )
        rules.append(low_risk_rule)
        
        # Missing Fields Validation Rule
        validation_rule = cls(
            name="mandatory_fields_validation",
            description="Validate mandatory fields are present",
            rule_type=RuleType.VALIDATION.value,
            condition="not context.get('rollback_plan', False) or not context.get('test_evidence', False) or not context.get('impacted_services') or not context.get('business_owner') or not context.get('technical_owner')",
            action="result = {'missing_fields': [], 'valid': False}; if not context.get('rollback_plan'): result['missing_fields'].append('rollback_plan'); if not context.get('test_evidence'): result['missing_fields'].append('test_evidence'); if not context.get('impacted_services'): result['missing_fields'].append('impacted_services'); if not context.get('business_owner'): result['missing_fields'].append('business_owner'); if not context.get('technical_owner'): result['missing_fields'].append('technical_owner')",
            priority=5,
            created_by="system",
            last_modified_by="system"
        )
        rules.append(validation_rule)
        
        # Validate all rules
        for rule in rules:
            rule.validate_rule()
        
        return rules
    
    def __repr__(self) -> str:
        """String representation of the rule."""
        return f"<Rule(name='{self.name}', type='{self.rule_type.value}', status='{self.status.value}')>"