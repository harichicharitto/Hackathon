"""
Risk Score model for storing detailed risk assessment results.
Tracks risk calculations and provides audit trail for risk decisions.
"""

from typing import Optional, Dict, Any
from sqlalchemy import String, Integer, Float, Text, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .base import BaseModel, db


class RiskScore(BaseModel):
    """Risk Score model for detailed risk assessment tracking."""
    
    __tablename__ = "risk_scores"
    
    # Risk identification
    change_request_id: Mapped[int] = mapped_column(Integer, ForeignKey('change_requests.id'), nullable=False)
    risk_level: Mapped[str] = mapped_column(String(10), nullable=False)  # Low, Medium, High
    risk_score: Mapped[int] = mapped_column(Integer, nullable=False)     # 1-100
    
    # Risk calculation details
    base_score: Mapped[int] = mapped_column(Integer, nullable=False)     # Base score before adjustments
    ci_impact_score: Mapped[int] = mapped_column(Integer, default=0, nullable=False)    # Critical Infrastructure impact
    timing_score: Mapped[int] = mapped_column(Integer, default=0, nullable=False)       # Timing impact score
    scope_score: Mapped[int] = mapped_column(Integer, default=0, nullable=False)        # Scope impact score
    rollback_score: Mapped[int] = mapped_column(Integer, default=0, nullable=False)     # Rollback capability score
    
    # Risk factors
    ci_criticality: Mapped[str] = mapped_column(String(20), nullable=True)    # critical, non-critical
    change_window: Mapped[str] = mapped_column(String(30), nullable=True)     # maintenance_window, business_hours, etc.
    impacted_systems_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    dependencies_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    rollback_available: Mapped[bool] = mapped_column(default=False, nullable=False)
    
    # Risk assessment metadata
    assessment_method: Mapped[str] = mapped_column(String(50), default="rule_engine", nullable=False)
    assessed_by: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    assessment_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Risk justification and reasoning
    risk_reasoning: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # Detailed explanation
    risk_factors: Mapped[Optional[str]] = mapped_column(JSON, nullable=True)    # JSON array of contributing factors
    
    # Risk validation
    is_validated: Mapped[bool] = mapped_column(default=False, nullable=False)
    validated_by: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    validation_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert risk score to dictionary."""
        data = super().to_dict()
        
        # Parse JSON risk factors if they exist
        if self.risk_factors:
            try:
                data['risk_factors'] = eval(self.risk_factors)  # Convert JSON string to list
            except:
                data['risk_factors'] = []
        
        return data
    
    def calculate_total_impact_score(self) -> int:
        """Calculate total impact score from all factors."""
        return (
            self.ci_impact_score +
            self.timing_score +
            self.scope_score +
            self.rollback_score
        )
    
    def get_risk_category(self) -> str:
        """Get risk category based on score."""
        if self.risk_score >= 75:
            return "High"
        elif self.risk_score >= 40:
            return "Medium"
        else:
            return "Low"
    
    def is_acceptable_risk(self) -> bool:
        """Determine if risk level is acceptable for approval."""
        return self.risk_level in ["Low", "Medium"]
    
    def get_risk_factors_list(self) -> list:
        """Get list of risk factors."""
        if self.risk_factors:
            try:
                return eval(self.risk_factors)
            except:
                return []
        return []
    
    def add_risk_factor(self, factor: str) -> None:
        """Add a risk factor to the list."""
        factors = self.get_risk_factors_list()
        if factor not in factors:
            factors.append(factor)
            self.risk_factors = str(factors)
    
    def remove_risk_factor(self, factor: str) -> None:
        """Remove a risk factor from the list."""
        factors = self.get_risk_factors_list()
        if factor in factors:
            factors.remove(factor)
            self.risk_factors = str(factors)
    
    def validate_score_consistency(self) -> bool:
        """Validate that the risk score is consistent with the level and factors."""
        expected_level = self.get_risk_category()
        
        # Check if calculated level matches stored level
        if expected_level != self.risk_level:
            return False
        
        # Check if score is within expected range for the level
        if self.risk_level == "High" and self.risk_score < 75:
            return False
        elif self.risk_level == "Medium" and (self.risk_score < 40 or self.risk_score >= 75):
            return False
        elif self.risk_level == "Low" and self.risk_score >= 40:
            return False
        
        return True
    
    def get_risk_summary(self) -> Dict[str, Any]:
        """Get a summary of the risk assessment."""
        return {
            "risk_level": self.risk_level,
            "risk_score": self.risk_score,
            "risk_category": self.get_risk_category(),
            "is_acceptable": self.is_acceptable_risk(),
            "factors": self.get_risk_factors_list(),
            "reasoning": self.risk_reasoning,
            "total_impact": self.calculate_total_impact_score(),
            "validation_status": "validated" if self.is_validated else "pending"
        }
    
    def __repr__(self) -> str:
        """String representation of the risk score."""
        return f"<RiskScore(change_id={self.change_request_id}, level='{self.risk_level}', score={self.risk_score})>"