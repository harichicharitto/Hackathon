"""
Change Request model for tracking IT change requests.
Implements the core business logic for change management.
"""

from enum import Enum as PyEnum
from typing import Optional, List, Dict, Any
from sqlalchemy import String, Text, Integer, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from datetime import datetime
from .base import BaseModel, db


class ChangeType(PyEnum):
    """Types of changes."""
    STANDARD = "standard"
    NORMAL = "normal"
    EMERGENCY = "emergency"


class ChangeStatus(PyEnum):
    """Status of change requests."""
    DRAFT = "draft"
    SUBMITTED = "submitted"
    REVIEW = "review"
    APPROVED = "approved"
    REJECTED = "rejected"
    IMPLEMENTED = "implemented"
    CANCELLED = "cancelled"


class ChangeWindow(PyEnum):
    """Approved change windows."""
    MAINTENANCE_WINDOW = "maintenance_window"
    BUSINESS_HOURS = "business_hours"
    AFTER_HOURS = "after_hours"
    WEEKEND = "weekend"


class ChangeRequest(BaseModel):
    """Change Request model for tracking IT changes."""
    
    __tablename__ = "change_requests"
    
    # Basic Information
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    change_type: Mapped[ChangeType] = mapped_column(String(20), nullable=False)
    status: Mapped[ChangeStatus] = mapped_column(String(20), default=ChangeStatus.DRAFT, nullable=False)
    
    # Change Details
    change_window: Mapped[ChangeWindow] = mapped_column(String(20), nullable=False)
    start_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    end_time: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    
    # Infrastructure Impact
    critical_ci: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    impacted_services: Mapped[str] = mapped_column(Text, nullable=True)  # JSON array of services
    dependencies: Mapped[str] = mapped_column(Text, nullable=True)  # JSON array of dependencies
    blast_radius: Mapped[str] = mapped_column(String(50), nullable=True)  # small, medium, large
    
    # Risk Assessment
    risk_level: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)  # Low, Medium, High
    risk_score: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # 1-100
    rollback_plan: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    test_evidence: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Business Information
    business_owner: Mapped[str] = mapped_column(String(100), nullable=False)
    technical_owner: Mapped[str] = mapped_column(String(100), nullable=False)
    justification: Mapped[str] = mapped_column(Text, nullable=True)
    
    # Approval Workflow
    submitted_by_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey('users.id'), nullable=True)
    approved_by_id: Mapped[Optional[int]] = mapped_column(Integer, ForeignKey('users.id'), nullable=True)
    submitted_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    
    # Metadata
    priority: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)  # Low, Medium, High, Critical
    estimated_effort: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # hours/days
    implementation_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    submitted_by = relationship("User", foreign_keys=[submitted_by_id])
    approved_by = relationship("User", foreign_keys=[approved_by_id])
    risk_scores = relationship("RiskScore", backref="change_request", lazy=True, cascade="all, delete-orphan")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert change request to dictionary."""
        data = super().to_dict()
        
        # Convert datetime fields to ISO format
        if isinstance(data.get('start_time'), datetime):
            data['start_time'] = data['start_time'].isoformat()
        if isinstance(data.get('end_time'), datetime):
            data['end_time'] = data['end_time'].isoformat()
        if isinstance(data.get('submitted_at'), datetime):
            data['submitted_at'] = data['submitted_at'].isoformat() if data['submitted_at'] else None
        if isinstance(data.get('approved_at'), datetime):
            data['approved_at'] = data['approved_at'].isoformat() if data['approved_at'] else None
        
        # Parse JSON fields back to arrays
        if data.get('impacted_services'):
            try:
                data['impacted_services'] = eval(data['impacted_services'])
            except:
                data['impacted_services'] = []
        
        if data.get('dependencies'):
            try:
                data['dependencies'] = eval(data['dependencies'])
            except:
                data['dependencies'] = []
        
        return data
    
    def calculate_duration_hours(self) -> float:
        """Calculate change duration in hours."""
        if self.start_time and self.end_time:
            duration = self.end_time - self.start_time
            return duration.total_seconds() / 3600
        return 0.0
    
    def is_within_maintenance_window(self) -> bool:
        """Check if change is within maintenance window."""
        return self.change_window == ChangeWindow.MAINTENANCE_WINDOW
    
    def has_multiple_systems(self) -> bool:
        """Check if change impacts multiple systems."""
        if self.impacted_services:
            try:
                services = eval(self.impacted_services)  # Convert JSON string to list
                return len(services) > 1
            except:
                return False
        return False
    
    def get_missing_fields(self) -> List[str]:
        """Get list of missing mandatory fields."""
        missing = []
        
        # Check mandatory fields based on change type
        if not self.rollback_plan:
            missing.append("rollback_plan")
        if not self.test_evidence:
            missing.append("test_evidence")
        if not self.impacted_services:
            missing.append("impacted_services")
        if not self.business_owner:
            missing.append("business_owner")
        if not self.technical_owner:
            missing.append("technical_owner")
        
        return missing
    
    def is_high_risk(self) -> bool:
        """Determine if change is high risk based on business rules."""
        return (
            self.critical_ci and
            self.change_window == ChangeWindow.BUSINESS_HOURS and
            self.has_multiple_systems() and
            not self.rollback_plan
        )
    
    def is_medium_risk(self) -> bool:
        """Determine if change is medium risk based on business rules."""
        return (
            not self.critical_ci and
            (self.blast_radius in ['small', 'medium']) and
            self.rollback_plan
        )
    
    def is_low_risk(self) -> bool:
        """Determine if change is low risk based on business rules."""
        return (
            self.change_type == ChangeType.STANDARD and
            self.is_within_maintenance_window() and
            not self.has_multiple_systems()
        )
    
    def get_risk_classification(self) -> str:
        """Get risk classification based on business rules."""
        if self.is_high_risk():
            return "High"
        elif self.is_medium_risk():
            return "Medium"
        elif self.is_low_risk():
            return "Low"
        else:
            # Default classification based on change type and other factors
            if self.change_type == ChangeType.EMERGENCY:
                return "High"
            elif self.change_type == ChangeType.NORMAL:
                return "Medium"
            else:
                return "Low"
    
    def submit(self, user_id: int) -> None:
        """Submit change request for review."""
        self.status = ChangeStatus.SUBMITTED
        self.submitted_by_id = user_id
        self.submitted_at = datetime.utcnow()
    
    def approve(self, user_id: int) -> None:
        """Approve change request."""
        self.status = ChangeStatus.APPROVED
        self.approved_by_id = user_id
        self.approved_at = datetime.utcnow()
    
    def reject(self) -> None:
        """Reject change request."""
        self.status = ChangeStatus.REJECTED
    
    def cancel(self) -> None:
        """Cancel change request."""
        self.status = ChangeStatus.CANCELLED
    
    def implement(self) -> None:
        """Mark change as implemented."""
        self.status = ChangeStatus.IMPLEMENTED
    
    def __repr__(self) -> str:
        """String representation of the change request."""
        return f"<ChangeRequest(title='{self.title}', status='{self.status.value}', risk='{self.risk_level}')>"