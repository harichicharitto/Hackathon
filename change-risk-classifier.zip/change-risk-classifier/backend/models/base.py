"""
Base model and database configuration for SQLAlchemy.
Provides common functionality for all database models.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.types import DateTime
from typing import Any


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy models."""
    pass


# Initialize SQLAlchemy with custom base
db = SQLAlchemy(model_class=Base)


class BaseModel(db.Model):
    """Base model with common fields and methods."""
    
    __abstract__ = True
    
    # Common fields
    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )
    
    def to_dict(self) -> dict[str, Any]:
        """Convert model instance to dictionary."""
        result = {}
        for column in self.__table__.columns:
            value = getattr(self, column.name)
            if isinstance(value, datetime):
                value = value.isoformat()
            result[column.name] = value
        return result
    
    def update(self, **kwargs) -> None:
        """Update model instance with provided keyword arguments."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
    
    def __repr__(self) -> str:
        """String representation of the model instance."""
        class_name = self.__class__.__name__
        return f"<{class_name}(id={self.id})>"


@event.listens_for(BaseModel, 'before_update', propagate=True)
def timestamp_updates(mapper, connection, target):
    """Automatically update the updated_at timestamp before any update."""
    target.updated_at = datetime.utcnow()