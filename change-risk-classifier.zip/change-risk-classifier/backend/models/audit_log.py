"""
Audit Log model for tracking system activities and changes.
Provides comprehensive audit trail for compliance and security.
"""

from enum import Enum as PyEnum
from typing import Optional, Dict, Any
from sqlalchemy import String, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column
from .base import BaseModel, db


class AuditAction(PyEnum):
    """Types of audit actions."""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    LOGIN = "login"
    LOGOUT = "logout"
    APPROVE = "approve"
    REJECT = "reject"
    SUBMIT = "submit"
    CANCEL = "cancel"
    EXPORT = "export"
    RULE_UPDATE = "rule_update"


class AuditLog(BaseModel):
    """Audit Log model for tracking system activities."""
    
    __tablename__ = "audit_logs"
    
    # Audit identification
    user_id: Mapped[Optional[int]] = mapped_column(nullable=True)  # Could be system action
    user_email: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    action: Mapped[AuditAction] = mapped_column(String(30), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
    resource_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # Audit details
    description: Mapped[str] = mapped_column(Text, nullable=False)
    ip_address: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Request/response details
    request_data: Mapped[Optional[str]] = mapped_column(JSON, nullable=True)  # JSON object
    response_data: Mapped[Optional[str]] = mapped_column(JSON, nullable=True)  # JSON object
    status_code: Mapped[Optional[int]] = mapped_column(nullable=True)
    
    # Additional metadata
    session_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    correlation_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    
    # Audit validation
    is_suspicious: Mapped[bool] = mapped_column(default=False, nullable=False)
    suspicious_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert audit log to dictionary."""
        data = super().to_dict()
        
        # Parse JSON fields if they exist
        if self.request_data:
            try:
                data['request_data'] = eval(self.request_data)  # Convert JSON string to dict
            except:
                data['request_data'] = {}
        
        if self.response_data:
            try:
                data['response_data'] = eval(self.response_data)  # Convert JSON string to dict
            except:
                data['response_data'] = {}
        
        return data
    
    @classmethod
    def log_action(
        cls,
        action: AuditAction,
        resource_type: str,
        description: str,
        user_id: Optional[int] = None,
        user_email: Optional[str] = None,
        resource_id: Optional[str] = None,
        request_data: Optional[Dict] = None,
        response_data: Optional[Dict] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        status_code: Optional[int] = None,
        session_id: Optional[str] = None,
        correlation_id: Optional[str] = None
    ) -> 'AuditLog':
        """Create and save an audit log entry."""
        audit_log = cls(
            user_id=user_id,
            user_email=user_email,
            action=action.value,
            resource_type=resource_type,
            resource_id=resource_id,
            description=description,
            ip_address=ip_address,
            user_agent=user_agent,
            status_code=status_code,
            session_id=session_id,
            correlation_id=correlation_id
        )
        
        # Convert dictionaries to JSON strings
        if request_data:
            audit_log.request_data = str(request_data)
        if response_data:
            audit_log.response_data = str(response_data)
        
        return audit_log
    
    def mark_suspicious(self, reason: str) -> None:
        """Mark this audit log as suspicious."""
        self.is_suspicious = True
        self.suspicious_reason = reason
    
    def get_action_display(self) -> str:
        """Get human-readable action description."""
        action_descriptions = {
            AuditAction.CREATE: "Created",
            AuditAction.READ: "Viewed",
            AuditAction.UPDATE: "Updated",
            AuditAction.DELETE: "Deleted",
            AuditAction.LOGIN: "Logged in",
            AuditAction.LOGOUT: "Logged out",
            AuditAction.APPROVE: "Approved",
            AuditAction.REJECT: "Rejected",
            AuditAction.SUBMIT: "Submitted",
            AuditAction.CANCEL: "Cancelled",
            AuditAction.EXPORT: "Exported",
            AuditAction.RULE_UPDATE: "Updated rule"
        }
        return action_descriptions.get(self.action, self.action)
    
    def is_security_relevant(self) -> bool:
        """Check if this audit log is security relevant."""
        security_actions = [
            AuditAction.LOGIN,
            AuditAction.LOGOUT,
            AuditAction.DELETE,
            AuditAction.UPDATE,
            AuditAction.APPROVE,
            AuditAction.REJECT
        ]
        return self.action in security_actions
    
    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the audit log."""
        return {
            "timestamp": self.created_at.isoformat(),
            "user": self.user_email or "System",
            "action": self.get_action_display(),
            "resource": f"{self.resource_type} {self.resource_id}" if self.resource_id else self.resource_type,
            "description": self.description,
            "ip_address": self.ip_address,
            "status": "suspicious" if self.is_suspicious else "normal",
            "security_relevant": self.is_security_relevant()
        }
    
    def __repr__(self) -> str:
        """String representation of the audit log."""
        return f"<AuditLog(user='{self.user_email}', action='{self.action}', resource='{self.resource_type}')>"