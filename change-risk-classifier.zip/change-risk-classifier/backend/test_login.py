#!/usr/bin/env python3
"""
Simple test script to verify login functionality.
"""

from app import create_app

def test_login():
    """Test the login functionality."""
    app = create_app()
    
    with app.test_client() as client:
        # Test login with admin credentials
        response = client.post('/api/auth/login', json={'username': 'admin', 'password': 'admin123'})
        print("Login response:", response.get_json())
        print("Status code:", response.status_code)
        
        if response.status_code == 200:
            print("✅ Login successful!")
            data = response.get_json()
            print("Token:", data.get('access_token', 'No token'))
        else:
            print("❌ Login failed!")

if __name__ == '__main__':
    test_login()