"""
Users API endpoints.
Handles user management operations for administrators.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging

from services.auth_service import AuthService
from models import User, AuditLog, AuditAction, UserRole
from config import settings

logger = logging.getLogger(__name__)

users_bp = Blueprint('users', __name__)


@users_bp.route('/', methods=['GET'])
@jwt_required()
def get_users():
    """Get all users (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get all users
        users = User.query.all()
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="user",
            description=f"User {current_user.username} accessed user list",
            user_id=current_user.id,
            request_data={"action": "list_users"}
        )
        
        return jsonify({
            "users": [user.to_dict() for user in users],
            "total": len(users)
        }), 200
        
    except Exception as e:
        logger.error(f"Get users error: {e}")
        return jsonify({"error": "An error occurred while retrieving users"}), 500


@users_bp.route('/<int:user_id>', methods=['GET'])
@jwt_required()
def get_user(user_id):
    """Get specific user by ID (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        user = AuthService.get_user_by_id(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="user",
            description=f"User {current_user.username} accessed user {user.username}",
            user_id=current_user.id,
            resource_id=str(user_id)
        )
        
        return jsonify(user.to_dict()), 200
        
    except Exception as e:
        logger.error(f"Get user error: {e}")
        return jsonify({"error": "An error occurred while retrieving user"}), 500


@users_bp.route('/', methods=['POST'])
@jwt_required()
def create_user():
    """Create new user (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        data = request.get_json()
        
        if not data or not all(key in data for key in ['username', 'email', 'password', 'full_name']):
            return jsonify({"error": "Username, email, password, and full name are required"}), 400
        
        username = data['username']
        email = data['email']
        password = data['password']
        full_name = data['full_name']
        role = data.get('role', 'change_manager')
        
        # Validate role
        if role not in [r.value for r in UserRole]:
            return jsonify({"error": "Invalid role"}), 400
        
        # Create user
        user = AuthService.create_user(username, email, password, full_name, role)
        
        if user:
            # Log user creation
            AuditLog.log_action(
                action=AuditAction.CREATE,
                resource_type="user",
                description=f"User {username} created by {current_user.username}",
                user_id=current_user.id,
                resource_id=str(user.id),
                request_data={
                    "username": username,
                    "email": email,
                    "role": role,
                    "full_name": full_name
                }
            )
            
            return jsonify({
                "message": "User created successfully",
                "user": user.to_dict()
            }), 201
        else:
            return jsonify({"error": "Username or email already exists"}), 409
            
    except Exception as e:
        logger.error(f"Create user error: {e}")
        return jsonify({"error": "An error occurred while creating user"}), 500


@users_bp.route('/<int:user_id>', methods=['PUT'])
@jwt_required()
def update_user(user_id):
    """Update user (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        user = AuthService.get_user_by_id(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        data = request.get_json()
        
        # Update user fields
        if 'username' in data:
            user.username = data['username']
        if 'email' in data:
            user.email = data['email']
        if 'full_name' in data:
            user.full_name = data['full_name']
        if 'role' in data:
            if data['role'] not in [r.value for r in UserRole]:
                return jsonify({"error": "Invalid role"}), 400
            user.role = data['role']
        if 'is_active' in data:
            user.is_active = data['is_active']
        
        user.save()
        
        # Log user update
        AuditLog.log_action(
            action=AuditAction.UPDATE,
            resource_type="user",
            description=f"User {user.username} updated by {current_user.username}",
            user_id=current_user.id,
            resource_id=str(user_id),
            request_data=data
        )
        
        return jsonify({
            "message": "User updated successfully",
            "user": user.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Update user error: {e}")
        return jsonify({"error": "An error occurred while updating user"}), 500


@users_bp.route('/<int:user_id>', methods=['DELETE'])
@jwt_required()
def delete_user(user_id):
    """Delete user (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        user = AuthService.get_user_by_id(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        if user.id == current_user.id:
            return jsonify({"error": "Cannot delete yourself"}), 400
        
        username = user.username
        user.delete()
        
        # Log user deletion
        AuditLog.log_action(
            action=AuditAction.DELETE,
            resource_type="user",
            description=f"User {username} deleted by {current_user.username}",
            user_id=current_user.id,
            resource_id=str(user_id)
        )
        
        return jsonify({"message": f"User {username} deleted successfully"}), 200
        
    except Exception as e:
        logger.error(f"Delete user error: {e}")
        return jsonify({"error": "An error occurred while deleting user"}), 500


@users_bp.route('/<int:user_id>/activate', methods=['PUT'])
@jwt_required()
def activate_user(user_id):
    """Activate user (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        user = AuthService.get_user_by_id(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        user.is_active = True
        user.save()
        
        # Log user activation
        AuditLog.log_action(
            action=AuditAction.UPDATE,
            resource_type="user",
            description=f"User {user.username} activated by {current_user.username}",
            user_id=current_user.id,
            resource_id=str(user_id)
        )
        
        return jsonify({
            "message": f"User {user.username} activated successfully",
            "user": user.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Activate user error: {e}")
        return jsonify({"error": "An error occurred while activating user"}), 500


@users_bp.route('/<int:user_id>/deactivate', methods=['PUT'])
@jwt_required()
def deactivate_user(user_id):
    """Deactivate user (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        user = AuthService.get_user_by_id(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        if user.id == current_user.id:
            return jsonify({"error": "Cannot deactivate yourself"}), 400
        
        user.is_active = False
        user.save()
        
        # Log user deactivation
        AuditLog.log_action(
            action=AuditAction.UPDATE,
            resource_type="user",
            description=f"User {user.username} deactivated by {current_user.username}",
            user_id=current_user.id,
            resource_id=str(user_id)
        )
        
        return jsonify({
            "message": f"User {user.username} deactivated successfully",
            "user": user.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Deactivate user error: {e}")
        return jsonify({"error": "An error occurred while deactivating user"}), 500


@users_bp.route('/me/permissions', methods=['GET'])
@jwt_required()
def get_user_permissions():
    """Get current user's permissions."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        permissions = {
            "is_admin": current_user.is_admin(),
            "is_change_manager": current_user.is_change_manager(),
            "can_create_changes": True,  # All users can create changes
            "can_approve_changes": current_user.is_change_manager() or current_user.is_admin(),
            "can_manage_users": current_user.is_admin(),
            "can_manage_rules": current_user.is_admin(),
            "can_export_data": current_user.is_change_manager() or current_user.is_admin(),
            "can_view_audit_logs": current_user.is_admin()
        }
        
        # Log permission check
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="user",
            description=f"User {current_user.username} checked permissions",
            user_id=current_user.id
        )
        
        return jsonify({
            "user_id": current_user.id,
            "username": current_user.username,
            "role": current_user.role.value,
            "permissions": permissions
        }), 200
        
    except Exception as e:
        logger.error(f"Get user permissions error: {e}")
        return jsonify({"error": "An error occurred while retrieving permissions"}), 500


@users_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_user_stats():
    """Get user statistics (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get user statistics
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        inactive_users = User.query.filter_by(is_active=False).count()
        
        # Get role distribution
        role_stats = {}
        for role in UserRole:
            count = User.query.filter_by(role=role).count()
            role_stats[role.value] = count
        
        # Get recent activity (last 30 days)
        from datetime import datetime, timedelta
        cutoff_date = datetime.utcnow() - timedelta(days=30)
        
        active_users_30d = db.session.query(User.id).join(AuditLog).filter(
            AuditLog.created_at >= cutoff_date
        ).distinct().count()
        
        stats = {
            "total_users": total_users,
            "active_users": active_users,
            "inactive_users": inactive_users,
            "role_distribution": role_stats,
            "active_users_last_30_days": active_users_30d,
            "user_activity": {
                "total_logins": AuditLog.query.filter_by(action="login").count(),
                "failed_logins": AuditLog.query.filter(
                    and_(
                        AuditLog.action == "login",
                        AuditLog.status_code != 200
                    )
                ).count(),
                "suspicious_activities": AuditLog.query.filter_by(is_suspicious=True).count()
            }
        }
        
        # Log stats access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="user",
            description=f"User {current_user.username} accessed user statistics",
            user_id=current_user.id,
            request_data={"action": "user_stats"}
        )
        
        return jsonify(stats), 200
        
    except Exception as e:
        logger.error(f"Get user stats error: {e}")
        return jsonify({"error": "An error occurred while retrieving user statistics"}), 500