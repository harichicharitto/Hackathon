"""
Change Requests API endpoints.
Handles change request lifecycle management including creation, approval, and tracking.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging
from datetime import datetime

from services.auth_service import AuthService
from services.risk_classifier_service import RiskClassifierService
from services.audit_service import AuditService
from models import ChangeRequest, RiskScore, User, AuditLog, AuditAction, ChangeStatus, ChangeType, ChangeWindow
from config import settings

logger = logging.getLogger(__name__)

change_requests_bp = Blueprint('change_requests', __name__)


@change_requests_bp.route('/', methods=['GET'])
@jwt_required()
def get_change_requests():
    """Get all change requests with filtering and pagination."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build filters
        filters = {}
        
        # Status filter
        status = request.args.get('status')
        if status:
            filters['status'] = status.split(',')
        
        # Risk level filter
        risk_level = request.args.get('risk_level')
        if risk_level:
            filters['risk_level'] = risk_level.split(',')
        
        # Change type filter
        change_type = request.args.get('change_type')
        if change_type:
            filters['change_type'] = change_type.split(',')
        
        # Change window filter
        change_window = request.args.get('change_window')
        if change_window:
            filters['change_window'] = change_window.split(',')
        
        # Date range filter
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        if start_date and end_date:
            filters['start_date'] = start_date
            filters['end_date'] = end_date
        
        # Search filter
        search = request.args.get('search')
        if search:
            filters['search'] = search
        
        # Sort parameters
        filters['sort_by'] = request.args.get('sort_by', 'created_at')
        filters['sort_order'] = request.args.get('sort_order', 'desc')
        
        # Get filtered changes
        from services.dashboard_service import DashboardService
        result = DashboardService.get_filtered_changes(
            filters=filters,
            user_id=current_user.id if not current_user.is_admin() else None,
            page=page,
            per_page=per_page
        )
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="change_request",
            description=f"User {current_user.username} accessed change requests list",
            user_id=current_user.id,
            request_data={
                "filters": filters,
                "page": page,
                "per_page": per_page
            }
        )
        
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Get change requests error: {e}")
        return jsonify({"error": "An error occurred while retrieving change requests"}), 500


@change_requests_bp.route('/<int:change_id>', methods=['GET'])
@jwt_required()
def get_change_request(change_id):
    """Get specific change request by ID."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check permissions - users can only view their own changes unless they're admin
        if not current_user.is_admin() and change_request.submitted_by_id != current_user.id:
            return jsonify({"error": "Access denied"}), 403
        
        # Get risk scores for this change
        risk_scores = RiskScore.query.filter_by(change_request_id=change_id).all()
        
        # Format response
        response = change_request.to_dict()
        response['risk_scores'] = [score.to_dict() for score in risk_scores]
        response['missing_fields'] = change_request.get_missing_fields()
        response['validation'] = RiskClassifierService.validate_risk_classification(change_request)
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="change_request",
            description=f"User {current_user.username} accessed change request {change_id}",
            user_id=current_user.id,
            resource_id=str(change_id)
        )
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Get change request error: {e}")
        return jsonify({"error": "An error occurred while retrieving change request"}), 500


@change_requests_bp.route('/', methods=['POST'])
@jwt_required()
def create_change_request():
    """Create new change request."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = [
            'title', 'description', 'change_type', 'change_window',
            'start_time', 'end_time', 'business_owner', 'technical_owner'
        ]
        
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        # Validate change type
        if data['change_type'] not in [ct.value for ct in ChangeType]:
            return jsonify({"error": "Invalid change type"}), 400
        
        # Validate change window
        if data['change_window'] not in [cw.value for cw in ChangeWindow]:
            return jsonify({"error": "Invalid change window"}), 400
        
        # Parse dates
        try:
            start_time = datetime.fromisoformat(data['start_time'])
            end_time = datetime.fromisoformat(data['end_time'])
        except ValueError:
            return jsonify({"error": "Invalid date format. Use ISO format (YYYY-MM-DDTHH:MM:SS)"}), 400
        
        # Validate time range
        if start_time >= end_time:
            return jsonify({"error": "End time must be after start time"}), 400
        
        # Create change request
        change_request = ChangeRequest(
            title=data['title'],
            description=data['description'],
            change_type=data['change_type'],
            change_window=data['change_window'],
            start_time=start_time,
            end_time=end_time,
            critical_ci=data.get('critical_ci', False),
            impacted_services=str(data.get('impacted_services', [])),
            dependencies=str(data.get('dependencies', [])),
            blast_radius=data.get('blast_radius'),
            rollback_plan=data.get('rollback_plan', False),
            test_evidence=data.get('test_evidence', False),
            business_owner=data['business_owner'],
            technical_owner=data['technical_owner'],
            justification=data.get('justification'),
            priority=data.get('priority'),
            estimated_effort=data.get('estimated_effort'),
            implementation_notes=data.get('implementation_notes'),
            submitted_by_id=current_user.id
        )
        
        change_request.save()
        
        # Classify risk
        classification_result = RiskClassifierService.classify_change_risk(change_request)
        
        # Log creation
        AuditLog.log_action(
            action=AuditAction.CREATE,
            resource_type="change_request",
            description=f"User {current_user.username} created change request {change_request.title}",
            user_id=current_user.id,
            resource_id=str(change_request.id),
            request_data=data
        )
        
        # Return detailed response
        response = change_request.to_dict()
        response['risk_classification'] = classification_result
        response['missing_fields'] = change_request.get_missing_fields()
        
        return jsonify({
            "message": "Change request created successfully",
            "change_request": response
        }), 201
        
    except Exception as e:
        logger.error(f"Create change request error: {e}")
        return jsonify({"error": "An error occurred while creating change request"}), 500


@change_requests_bp.route('/<int:change_id>', methods=['PUT'])
@jwt_required()
def update_change_request(change_id):
    """Update change request (only for draft status or admin)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check permissions
        if not current_user.is_admin():
            if change_request.submitted_by_id != current_user.id:
                return jsonify({"error": "Access denied"}), 403
            
            if change_request.status != ChangeStatus.DRAFT:
                return jsonify({"error": "Cannot modify submitted change request"}), 400
        
        data = request.get_json()
        
        # Update fields (excluding status and approval fields)
        updatable_fields = [
            'title', 'description', 'change_type', 'change_window',
            'start_time', 'end_time', 'critical_ci', 'impacted_services',
            'dependencies', 'blast_radius', 'rollback_plan', 'test_evidence',
            'business_owner', 'technical_owner', 'justification',
            'priority', 'estimated_effort', 'implementation_notes'
        ]
        
        for field in updatable_fields:
            if field in data:
                if field in ['start_time', 'end_time']:
                    try:
                        setattr(change_request, field, datetime.fromisoformat(data[field]))
                    except ValueError:
                        return jsonify({"error": f"Invalid date format for {field}"}), 400
                elif field in ['impacted_services', 'dependencies']:
                    setattr(change_request, field, str(data[field]))
                else:
                    setattr(change_request, field, data[field])
        
        change_request.save()
        
        # Re-classify risk if relevant fields changed
        relevant_fields = ['critical_ci', 'change_window', 'impacted_services', 'rollback_plan']
        if any(field in data for field in relevant_fields):
            RiskClassifierService.classify_change_risk(change_request)
        
        # Log update
        AuditLog.log_action(
            action=AuditAction.UPDATE,
            resource_type="change_request",
            description=f"User {current_user.username} updated change request {change_id}",
            user_id=current_user.id,
            resource_id=str(change_id),
            request_data=data
        )
        
        return jsonify({
            "message": "Change request updated successfully",
            "change_request": change_request.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Update change request error: {e}")
        return jsonify({"error": "An error occurred while updating change request"}), 500


@change_requests_bp.route('/<int:change_id>/submit', methods=['POST'])
@jwt_required()
def submit_change_request(change_id):
    """Submit change request for review."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check permissions
        if change_request.submitted_by_id != current_user.id:
            return jsonify({"error": "Access denied"}), 403
        
        # Check status
        if change_request.status != ChangeStatus.DRAFT:
            return jsonify({"error": "Change request is not in draft status"}), 400
        
        # Validate mandatory fields
        missing_fields = change_request.get_missing_fields()
        if missing_fields:
            return jsonify({
                "error": "Cannot submit change request with missing mandatory fields",
                "missing_fields": missing_fields
            }), 400
        
        # Submit change request
        change_request.submit(current_user.id)
        change_request.save()
        
        # Log submission
        AuditLog.log_action(
            action=AuditAction.SUBMIT,
            resource_type="change_request",
            description=f"User {current_user.username} submitted change request {change_id}",
            user_id=current_user.id,
            resource_id=str(change_id)
        )
        
        return jsonify({
            "message": "Change request submitted successfully",
            "change_request": change_request.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Submit change request error: {e}")
        return jsonify({"error": "An error occurred while submitting change request"}), 500


@change_requests_bp.route('/<int:change_id>/approve', methods=['POST'])
@jwt_required()
def approve_change_request(change_id):
    """Approve change request (admin and change managers only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check status
        if change_request.status not in [ChangeStatus.SUBMITTED, ChangeStatus.REVIEW]:
            return jsonify({"error": "Change request is not ready for approval"}), 400
        
        # Approve change request
        change_request.approve(current_user.id)
        change_request.save()
        
        # Log approval
        AuditLog.log_action(
            action=AuditAction.APPROVE,
            resource_type="change_request",
            description=f"User {current_user.username} approved change request {change_id}",
            user_id=current_user.id,
            resource_id=str(change_id)
        )
        
        return jsonify({
            "message": "Change request approved successfully",
            "change_request": change_request.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Approve change request error: {e}")
        return jsonify({"error": "An error occurred while approving change request"}), 500




@change_requests_bp.route('/<int:change_id>/ai-analysis', methods=['GET'])
@jwt_required()
def get_ai_analysis(change_id):
    """Get AI-powered impact analysis for a change request."""
    try:
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Get risk scores for this change
        risk_score = RiskScore.query.filter_by(change_request_id=change_id).first()
        
        if not risk_score or not risk_score.impact_analysis:
            return jsonify({"error": "No AI analysis available"}), 404
        
        return jsonify({
            "change_id": change_id,
            "ai_analysis": risk_score.impact_analysis,
            "risk_score": risk_score.risk_score,
            "risk_level": risk_score.risk_level,
            "recommendation": risk_score.impact_analysis.get('ai_recommendation', 'No recommendation available'),
            "confidence": risk_score.impact_analysis.get('confidence_level', 'Unknown')
        })
        
    except Exception as e:
        logger.error(f"Error getting AI analysis: {e}")
        return jsonify({"error": "Failed to get AI analysis"}), 500


@change_requests_bp.route('/<int:change_id>/reject', methods=['POST'])
@jwt_required()
def reject_change_request(change_id):
    """Reject change request (admin and change managers only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check status
        if change_request.status not in [ChangeStatus.SUBMITTED, ChangeStatus.REVIEW]:
            return jsonify({"error": "Change request is not ready for rejection"}), 400
        
        data = request.get_json()
        reason = data.get('reason', 'No reason provided')
        
        # Reject change request
        change_request.reject()
        change_request.save()
        
        # Log rejection
        AuditLog.log_action(
            action=AuditAction.REJECT,
            resource_type="change_request",
            description=f"User {current_user.username} rejected change request {change_id}: {reason}",
            user_id=current_user.id,
            resource_id=str(change_id),
            request_data={"reason": reason}
        )
        
        return jsonify({
            "message": "Change request rejected successfully",
            "change_request": change_request.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Reject change request error: {e}")
        return jsonify({"error": "An error occurred while rejecting change request"}), 500


@change_requests_bp.route('/<int:change_id>/cancel', methods=['POST'])
@jwt_required()
def cancel_change_request(change_id):
    """Cancel change request (only for draft or submitted status)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check permissions
        if not current_user.is_admin():
            if change_request.submitted_by_id != current_user.id:
                return jsonify({"error": "Access denied"}), 403
        
        # Check status
        if change_request.status not in [ChangeStatus.DRAFT, ChangeStatus.SUBMITTED]:
            return jsonify({"error": "Change request cannot be cancelled"}), 400
        
        # Cancel change request
        change_request.cancel()
        change_request.save()
        
        # Log cancellation
        AuditLog.log_action(
            action=AuditAction.CANCEL,
            resource_type="change_request",
            description=f"User {current_user.username} cancelled change request {change_id}",
            user_id=current_user.id,
            resource_id=str(change_id)
        )
        
        return jsonify({
            "message": "Change request cancelled successfully",
            "change_request": change_request.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Cancel change request error: {e}")
        return jsonify({"error": "An error occurred while cancelling change request"}), 500


@change_requests_bp.route('/<int:change_id>/implement', methods=['POST'])
@jwt_required()
def implement_change_request(change_id):
    """Mark change request as implemented (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Check status
        if change_request.status != ChangeStatus.APPROVED:
            return jsonify({"error": "Change request is not approved"}), 400
        
        # Mark as implemented
        change_request.implement()
        change_request.save()
        
        # Log implementation
        AuditLog.log_action(
            action=AuditAction.UPDATE,
            resource_type="change_request",
            description=f"User {current_user.username} marked change request {change_id} as implemented",
            user_id=current_user.id,
            resource_id=str(change_id)
        )
        
        return jsonify({
            "message": "Change request marked as implemented successfully",
            "change_request": change_request.to_dict()
        }), 200
        
    except Exception as e:
        logger.error(f"Implement change request error: {e}")
        return jsonify({"error": "An error occurred while marking change request as implemented"}), 500


@change_requests_bp.route('/<int:change_id>/reclassify', methods=['POST'])
@jwt_required()
def reclassify_change_request(change_id):
    """Reclassify risk for change request (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        change_request = ChangeRequest.query.get(change_id)
        if not change_request:
            return jsonify({"error": "Change request not found"}), 404
        
        # Reclassify risk
        classification_result = RiskClassifierService.classify_change_risk(change_request)
        
        # Log reclassification
        AuditLog.log_action(
            action=AuditAction.UPDATE,
            resource_type="change_request",
            description=f"User {current_user.username} reclassified risk for change request {change_id}",
            user_id=current_user.id,
            resource_id=str(change_id),
            request_data={"action": "reclassify_risk"}
        )
        
        return jsonify({
            "message": "Change request risk reclassified successfully",
            "change_request": change_request.to_dict(),
            "classification_result": classification_result
        }), 200
        
    except Exception as e:
        logger.error(f"Reclassify change request error: {e}")
        return jsonify({"error": "An error occurred while reclassifying change request"}), 500


@change_requests_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_change_stats():
    """Get change request statistics."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get statistics
        total_changes = ChangeRequest.query.count()
        draft_changes = ChangeRequest.query.filter_by(status="draft").count()
        submitted_changes = ChangeRequest.query.filter_by(status="submitted").count()
        approved_changes = ChangeRequest.query.filter_by(status="approved").count()
        rejected_changes = ChangeRequest.query.filter_by(status="rejected").count()
        implemented_changes = ChangeRequest.query.filter_by(status="implemented").count()
        
        # Get risk distribution
        high_risk = RiskScore.query.filter_by(risk_level="High").count()
        medium_risk = RiskScore.query.filter_by(risk_level="Medium").count()
        low_risk = RiskScore.query.filter_by(risk_level="Low").count()
        
        # Get user-specific stats if not admin
        user_stats = None
        if not current_user.is_admin():
            user_changes = ChangeRequest.query.filter_by(submitted_by_id=current_user.id).count()
            user_draft = ChangeRequest.query.filter_by(
                submitted_by_id=current_user.id,
                status="draft"
            ).count()
            user_submitted = ChangeRequest.query.filter_by(
                submitted_by_id=current_user.id,
                status="submitted"
            ).count()
            user_approved = ChangeRequest.query.filter_by(
                submitted_by_id=current_user.id,
                status="approved"
            ).count()
            
            user_stats = {
                "total": user_changes,
                "draft": user_draft,
                "submitted": user_submitted,
                "approved": user_approved
            }
        
        stats = {
            "total_changes": total_changes,
            "by_status": {
                "draft": draft_changes,
                "submitted": submitted_changes,
                "approved": approved_changes,
                "rejected": rejected_changes,
                "implemented": implemented_changes
            },
            "by_risk": {
                "high": high_risk,
                "medium": medium_risk,
                "low": low_risk
            },
            "user_stats": user_stats
        }
        
        # Log stats access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="change_request",
            description=f"User {current_user.username} accessed change statistics",
            user_id=current_user.id,
            request_data={"action": "change_stats"}
        )
        
        return jsonify(stats), 200
        
    except Exception as e:
        logger.error(f"Get change stats error: {e}")
        return jsonify({"error": "An error occurred while retrieving change statistics"}), 500