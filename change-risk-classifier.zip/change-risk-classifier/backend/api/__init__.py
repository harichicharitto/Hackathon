"""
API package for the Change Risk Classifier application.
Contains all API endpoints and route handlers.
"""

from flask import Blueprint

# Create API blueprint
api_bp = Blueprint('api', __name__, url_prefix='/api')

# Import all blueprints to register them
from . import auth, users, change_requests, rules, dashboard, export

__all__ = ['api_bp']