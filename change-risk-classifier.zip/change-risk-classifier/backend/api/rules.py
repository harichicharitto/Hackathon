"""
Rules API endpoints.
Handles rule management for the rule engine including creation, updates, and execution.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging

from services.rule_engine_service import RuleEngineService
from services.audit_service import AuditService
from models import Rule, AuditLog, AuditAction, RuleType, RuleStatus
from config import settings

logger = logging.getLogger(__name__)

rules_bp = Blueprint('rules', __name__)


@rules_bp.route('/', methods=['GET'])
@jwt_required()
def get_rules():
    """Get all rules with filtering."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        # Get query parameters
        rule_type = request.args.get('rule_type')
        status = request.args.get('status', 'active')
        
        # Get rules
        rules = RuleEngineService.get_active_rules(rule_type if status == 'active' else None)
        
        # Filter by status if not active
        if status != 'active':
            rules = [rule for rule in rules if rule.status == status]
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="rule",
            description=f"User {current_user.username} accessed rules list",
            user_id=current_user.id,
            request_data={
                "rule_type": rule_type,
                "status": status
            }
        )
        
        return jsonify({
            "rules": [rule.to_dict() for rule in rules],
            "total": len(rules),
            "summary": RuleEngineService.get_rules_summary()
        }), 200
        
    except Exception as e:
        logger.error(f"Get rules error: {e}")
        return jsonify({"error": "An error occurred while retrieving rules"}), 500


@rules_bp.route('/<int:rule_id>', methods=['GET'])
@jwt_required()
def get_rule(rule_id):
    """Get specific rule by ID."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        rule = Rule.query.get(rule_id)
        if not rule:
            return jsonify({"error": "Rule not found"}), 404
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="rule",
            description=f"User {current_user.username} accessed rule {rule.name}",
            user_id=current_user.id,
            resource_id=rule.name
        )
        
        return jsonify(rule.to_dict()), 200
        
    except Exception as e:
        logger.error(f"Get rule error: {e}")
        return jsonify({"error": "An error occurred while retrieving rule"}), 500


@rules_bp.route('/', methods=['POST'])
@jwt_required()
def create_rule():
    """Create new rule (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'description', 'rule_type', 'condition', 'action']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        # Validate rule type
        if data['rule_type'] not in [rt.value for rt in RuleType]:
            return jsonify({"error": "Invalid rule type"}), 400
        
        # Validate rule syntax
        validation_result = RuleEngineService.validate_rule_syntax(
            data['condition'], data['action']
        )
        
        if not validation_result['is_valid']:
            return jsonify({
                "error": "Rule syntax validation failed",
                "errors": validation_result['errors']
            }), 400
        
        # Create rule
        rule = RuleEngineService.create_rule(
            name=data['name'],
            description=data['description'],
            rule_type=data['rule_type'],
            condition=data['condition'],
            action=data['action'],
            priority=data.get('priority', 100),
            parameters=data.get('parameters'),
            created_by=current_user.email
        )
        
        if rule:
            # Log rule creation
            AuditLog.log_action(
                action=AuditAction.CREATE,
                resource_type="rule",
                description=f"User {current_user.username} created rule {rule.name}",
                user_id=current_user.id,
                resource_id=rule.name,
                request_data=data
            )
            
            return jsonify({
                "message": "Rule created successfully",
                "rule": rule.to_dict()
            }), 201
        else:
            return jsonify({"error": "Rule name already exists"}), 409
        
    except Exception as e:
        logger.error(f"Create rule error: {e}")
        return jsonify({"error": "An error occurred while creating rule"}), 500


@rules_bp.route('/<int:rule_id>', methods=['PUT'])
@jwt_required()
def update_rule(rule_id):
    """Update existing rule (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        rule = Rule.query.get(rule_id)
        if not rule:
            return jsonify({"error": "Rule not found"}), 404
        
        data = request.get_json()
        
        # Validate rule syntax if condition or action is being updated
        if 'condition' in data or 'action' in data:
            condition = data.get('condition', rule.condition)
            action = data.get('action', rule.action)
            
            validation_result = RuleEngineService.validate_rule_syntax(condition, action)
            
            if not validation_result['is_valid']:
                return jsonify({
                    "error": "Rule syntax validation failed",
                    "errors": validation_result['errors']
                }), 400
        
        # Update rule
        updated_rule = RuleEngineService.update_rule(
            rule_id=rule_id,
            name=data.get('name'),
            description=data.get('description'),
            rule_type=data.get('rule_type'),
            condition=data.get('condition'),
            action=data.get('action'),
            priority=data.get('priority'),
            parameters=data.get('parameters'),
            status=data.get('status'),
            modified_by=current_user.email
        )
        
        if updated_rule:
            # Log rule update
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="rule",
                description=f"User {current_user.username} updated rule {updated_rule.name}",
                user_id=current_user.id,
                resource_id=updated_rule.name,
                request_data=data
            )
            
            return jsonify({
                "message": "Rule updated successfully",
                "rule": updated_rule.to_dict()
            }), 200
        else:
            return jsonify({"error": "Failed to update rule"}), 500
        
    except Exception as e:
        logger.error(f"Update rule error: {e}")
        return jsonify({"error": "An error occurred while updating rule"}), 500


@rules_bp.route('/<int:rule_id>', methods=['DELETE'])
@jwt_required()
def delete_rule(rule_id):
    """Delete rule (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        success = RuleEngineService.delete_rule(rule_id, current_user.email)
        
        if success:
            # Log rule deletion
            AuditLog.log_action(
                action=AuditAction.DELETE,
                resource_type="rule",
                description=f"User {current_user.username} deleted rule {rule_id}",
                user_id=current_user.id,
                resource_id=str(rule_id)
            )
            
            return jsonify({"message": "Rule deleted successfully"}), 200
        else:
            return jsonify({"error": "Rule not found or could not be deleted"}), 404
        
    except Exception as e:
        logger.error(f"Delete rule error: {e}")
        return jsonify({"error": "An error occurred while deleting rule"}), 500


@rules_bp.route('/<int:rule_id>/activate', methods=['PUT'])
@jwt_required()
def activate_rule(rule_id):
    """Activate rule (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        success = RuleEngineService.update_rule(
            rule_id=rule_id,
            status="active",
            modified_by=current_user.email
        )
        
        if success:
            # Log rule activation
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="rule",
                description=f"User {current_user.username} activated rule {rule_id}",
                user_id=current_user.id,
                resource_id=str(rule_id)
            )
            
            return jsonify({"message": "Rule activated successfully"}), 200
        else:
            return jsonify({"error": "Rule not found or could not be activated"}), 404
        
    except Exception as e:
        logger.error(f"Activate rule error: {e}")
        return jsonify({"error": "An error occurred while activating rule"}), 500


@rules_bp.route('/<int:rule_id>/deactivate', methods=['PUT'])
@jwt_required()
def deactivate_rule(rule_id):
    """Deactivate rule (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        success = RuleEngineService.update_rule(
            rule_id=rule_id,
            status="inactive",
            modified_by=current_user.email
        )
        
        if success:
            # Log rule deactivation
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="rule",
                description=f"User {current_user.username} deactivated rule {rule_id}",
                user_id=current_user.id,
                resource_id=str(rule_id)
            )
            
            return jsonify({"message": "Rule deactivated successfully"}), 200
        else:
            return jsonify({"error": "Rule not found or could not be deactivated"}), 404
        
    except Exception as e:
        logger.error(f"Deactivate rule error: {e}")
        return jsonify({"error": "An error occurred while deactivating rule"}), 500


@rules_bp.route('/test', methods=['POST'])
@jwt_required()
def test_rule():
    """Test rule execution with provided context."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        data = request.get_json()
        
        if not data or 'condition' not in data or 'action' not in data or 'context' not in data:
            return jsonify({"error": "Missing required fields: condition, action, context"}), 400
        
        condition = data['condition']
        action = data['action']
        context = data['context']
        
        # Validate rule syntax
        validation_result = RuleEngineService.validate_rule_syntax(condition, action)
        
        if not validation_result['is_valid']:
            return jsonify({
                "valid": False,
                "errors": validation_result['errors']
            }), 400
        
        # Test rule execution
        try:
            # Create a temporary rule object for testing
            test_rule = Rule(
                name="test_rule",
                description="Test rule",
                rule_type="validation",
                condition=condition,
                action=action
            )
            
            # Evaluate condition
            condition_result = test_rule.evaluate_condition(context)
            
            # Execute action if condition is met
            action_result = None
            if condition_result:
                action_result = test_rule.execute_action(context)
            
            # Log rule test
            AuditLog.log_action(
                action=AuditAction.READ,
                resource_type="rule",
                description=f"User {current_user.username} tested rule",
                user_id=current_user.id,
                request_data={
                    "condition": condition,
                    "action": action,
                    "context": context
                },
                response_data={
                    "condition_result": condition_result,
                    "action_result": action_result
                }
            )
            
            return jsonify({
                "valid": True,
                "condition_result": condition_result,
                "action_result": action_result,
                "message": "Rule test completed successfully"
            }), 200
            
        except Exception as e:
            logger.error(f"Rule test execution error: {e}")
            return jsonify({
                "valid": False,
                "error": f"Rule execution failed: {str(e)}"
            }), 400
        
    except Exception as e:
        logger.error(f"Test rule error: {e}")
        return jsonify({"error": "An error occurred while testing rule"}), 500


@rules_bp.route('/evaluate', methods=['POST'])
@jwt_required()
def evaluate_rules():
    """Evaluate rules against provided context."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        data = request.get_json()
        
        if not data or 'context' not in data:
            return jsonify({"error": "Missing required field: context"}), 400
        
        context = data['context']
        rule_type = data.get('rule_type')
        
        # Evaluate rules
        results = RuleEngineService.evaluate_rules(context, rule_type)
        
        # Log rule evaluation
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="rule",
            description=f"User {current_user.username} evaluated rules",
            user_id=current_user.id,
            request_data={
                "context": context,
                "rule_type": rule_type,
                "result_count": len(results)
            }
        )
        
        return jsonify({
            "context": context,
            "rule_type": rule_type,
            "results": results,
            "total_results": len(results)
        }), 200
        
    except Exception as e:
        logger.error(f"Evaluate rules error: {e}")
        return jsonify({"error": "An error occurred while evaluating rules"}), 500


@rules_bp.route('/reset-defaults', methods=['POST'])
@jwt_required()
def reset_default_rules():
    """Reset rules to default configuration (admin only)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        success = RuleEngineService.reset_to_default_rules()
        
        if success:
            # Log rule reset
            AuditLog.log_action(
                action=AuditAction.RULE_UPDATE,
                resource_type="rule",
                description=f"User {current_user.username} reset rules to defaults",
                user_id=current_user.id
            )
            
            return jsonify({"message": "Rules reset to default configuration successfully"}), 200
        else:
            return jsonify({"error": "Failed to reset rules"}), 500
        
    except Exception as e:
        logger.error(f"Reset default rules error: {e}")
        return jsonify({"error": "An error occurred while resetting rules"}), 500


@rules_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_rule_stats():
    """Get rule statistics."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        stats = RuleEngineService.get_rules_summary()
        
        # Log stats access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="rule",
            description=f"User {current_user.username} accessed rule statistics",
            user_id=current_user.id,
            request_data={"action": "rule_stats"}
        )
        
        return jsonify(stats), 200
        
    except Exception as e:
        logger.error(f"Get rule stats error: {e}")
        return jsonify({"error": "An error occurred while retrieving rule statistics"}), 500


@rules_bp.route('/validate-syntax', methods=['POST'])
@jwt_required()
def validate_rule_syntax():
    """Validate rule syntax without creating a rule."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or not current_user.is_admin():
            return jsonify({"error": "Admin privileges required"}), 403
        
        data = request.get_json()
        
        if not data or 'condition' not in data or 'action' not in data:
            return jsonify({"error": "Missing required fields: condition, action"}), 400
        
        condition = data['condition']
        action = data['action']
        
        validation_result = RuleEngineService.validate_rule_syntax(condition, action)
        
        # Log syntax validation
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="rule",
            description=f"User {current_user.username} validated rule syntax",
            user_id=current_user.id,
            request_data={
                "condition": condition,
                "action": action
            },
            response_data=validation_result
        )
        
        return jsonify(validation_result), 200
        
    except Exception as e:
        logger.error(f"Validate rule syntax error: {e}")
        return jsonify({"error": "An error occurred while validating rule syntax"}), 500