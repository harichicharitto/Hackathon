"""
Dashboard API endpoints.
Provides aggregated data and analytics for the dashboard interface.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging
from datetime import datetime, timedelta

from services.dashboard_service import DashboardService
from services.audit_service import AuditService
from services.auth_service import AuthService
from models import AuditLog, AuditAction
from config import settings

logger = logging.getLogger(__name__)

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/summary', methods=['GET'])
@jwt_required()
def get_dashboard_summary():
    """Get comprehensive dashboard summary."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get dashboard summary
        summary = DashboardService.get_dashboard_summary(
            user_id=None if current_user.is_admin() else current_user.id
        )
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed dashboard summary",
            user_id=current_user.id,
            request_data={"view": "summary"}
        )
        
        return jsonify(summary), 200
        
    except Exception as e:
        logger.error(f"Get dashboard summary error: {e}")
        return jsonify({"error": "An error occurred while retrieving dashboard summary"}), 500


@dashboard_bp.route('/changes', methods=['GET'])
@jwt_required()
def get_dashboard_changes():
    """Get filtered changes for dashboard."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build filters
        filters = {}
        
        # Status filter
        status = request.args.get('status')
        if status:
            filters['status'] = status.split(',')
        
        # Risk level filter
        risk_level = request.args.get('risk_level')
        if risk_level:
            filters['risk_level'] = risk_level.split(',')
        
        # Change type filter
        change_type = request.args.get('change_type')
        if change_type:
            filters['change_type'] = change_type.split(',')
        
        # Change window filter
        change_window = request.args.get('change_window')
        if change_window:
            filters['change_window'] = change_window.split(',')
        
        # Date range filter
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        if start_date and end_date:
            filters['start_date'] = start_date
            filters['end_date'] = end_date
        
        # Search filter
        search = request.args.get('search')
        if search:
            filters['search'] = search
        
        # Sort parameters
        filters['sort_by'] = request.args.get('sort_by', 'created_at')
        filters['sort_order'] = request.args.get('sort_order', 'desc')
        
        # Get filtered changes
        result = DashboardService.get_filtered_changes(
            filters=filters,
            user_id=None if current_user.is_admin() else current_user.id,
            page=page,
            per_page=per_page
        )
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed dashboard changes",
            user_id=current_user.id,
            request_data={
                "filters": filters,
                "page": page,
                "per_page": per_page
            }
        )
        
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Get dashboard changes error: {e}")
        return jsonify({"error": "An error occurred while retrieving dashboard changes"}), 500


@dashboard_bp.route('/analytics', methods=['GET'])
@jwt_required()
def get_dashboard_analytics():
    """Get dashboard analytics and trends."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get time period parameter
        time_period = request.args.get('time_period', '30d')
        
        # Get analytics
        analytics = DashboardService.get_change_analytics(time_period)
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed dashboard analytics",
            user_id=current_user.id,
            request_data={
                "time_period": time_period,
                "view": "analytics"
            }
        )
        
        return jsonify(analytics), 200
        
    except Exception as e:
        logger.error(f"Get dashboard analytics error: {e}")
        return jsonify({"error": "An error occurred while retrieving dashboard analytics"}), 500


@dashboard_bp.route('/pending-approvals', methods=['GET'])
@jwt_required()
def get_pending_approvals():
    """Get pending approval requests."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        # Get pending approvals
        from ..services.dashboard_service import DashboardService
        pending_approvals = DashboardService._get_pending_approvals(
            user_id=None if current_user.is_admin() else current_user.id
        )
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed pending approvals",
            user_id=current_user.id,
            request_data={"view": "pending_approvals"}
        )
        
        return jsonify({
            "pending_approvals": pending_approvals,
            "total_pending": len(pending_approvals)
        }), 200
        
    except Exception as e:
        logger.error(f"Get pending approvals error: {e}")
        return jsonify({"error": "An error occurred while retrieving pending approvals"}), 500


@dashboard_bp.route('/recent-activity', methods=['GET'])
@jwt_required()
def get_recent_activity():
    """Get recent activity feed."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get limit parameter
        limit = request.args.get('limit', 20, type=int)
        limit = min(limit, 100)  # Cap at 100
        
        # Get recent activity
        from ..services.dashboard_service import DashboardService
        recent_activity = DashboardService._get_recent_activity(
            user_id=None if current_user.is_admin() else current_user.id,
            limit=limit
        )
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed recent activity",
            user_id=current_user.id,
            request_data={
                "limit": limit,
                "view": "recent_activity"
            }
        )
        
        return jsonify({
            "recent_activity": recent_activity,
            "total": len(recent_activity)
        }), 200
        
    except Exception as e:
        logger.error(f"Get recent activity error: {e}")
        return jsonify({"error": "An error occurred while retrieving recent activity"}), 500


@dashboard_bp.route('/performance-metrics', methods=['GET'])
@jwt_required()
def get_performance_metrics():
    """Get performance metrics."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Build filters
        filters = []
        if not current_user.is_admin():
            filters.append(ChangeRequest.submitted_by_id == current_user.id)
        
        # Get performance metrics
        from ..services.dashboard_service import DashboardService
        metrics = DashboardService._get_performance_metrics(filters)
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed performance metrics",
            user_id=current_user.id,
            request_data={"view": "performance_metrics"}
        )
        
        return jsonify(metrics), 200
        
    except Exception as e:
        logger.error(f"Get performance metrics error: {e}")
        return jsonify({"error": "An error occurred while retrieving performance metrics"}), 500


@dashboard_bp.route('/risk-trends', methods=['GET'])
@jwt_required()
def get_risk_trends():
    """Get risk trends over time."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get days parameter
        days = request.args.get('days', 30, type=int)
        
        # Get risk trends
        from ..services.risk_classifier_service import RiskClassifierService
        trends = RiskClassifierService.get_risk_trends(days)
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed risk trends",
            user_id=current_user.id,
            request_data={
                "days": days,
                "view": "risk_trends"
            }
        )
        
        return jsonify(trends), 200
        
    except Exception as e:
        logger.error(f"Get risk trends error: {e}")
        return jsonify({"error": "An error occurred while retrieving risk trends"}), 500


@dashboard_bp.route('/export-ready', methods=['GET'])
@jwt_required()
def get_export_ready_changes():
    """Get changes ready for export (approved and implemented)."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user or (not current_user.is_admin() and not current_user.is_change_manager()):
            return jsonify({"error": "Insufficient privileges"}), 403
        
        # Get export-ready changes
        export_ready = ChangeRequest.query.filter(
            ChangeRequest.status.in_(['approved', 'implemented'])
        ).order_by(ChangeRequest.updated_at.desc()).limit(100).all()
        
        # Format response
        changes_data = []
        for change in export_ready:
            change_data = change.to_dict()
            change_data['risk_summary'] = {
                "level": change.risk_level,
                "score": change.risk_score,
                "acceptable": change.risk_level in ["Low", "Medium"]
            }
            changes_data.append(change_data)
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed export-ready changes",
            user_id=current_user.id,
            request_data={"view": "export_ready"}
        )
        
        return jsonify({
            "export_ready_changes": changes_data,
            "total": len(changes_data),
            "note": "These changes are ready for CAB review pack export"
        }), 200
        
    except Exception as e:
        logger.error(f"Get export-ready changes error: {e}")
        return jsonify({"error": "An error occurred while retrieving export-ready changes"}), 500


@dashboard_bp.route('/quick-stats', methods=['GET'])
@jwt_required()
def get_quick_stats():
    """Get quick statistics for dashboard widgets."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Build base query
        base_query = ChangeRequest.query
        
        if not current_user.is_admin():
            base_query = base_query.filter(ChangeRequest.submitted_by_id == current_user.id)
        
        # Get quick stats
        stats = {
            "total_changes": base_query.count(),
            "pending_changes": base_query.filter(
                ChangeRequest.status.in_(['submitted', 'review'])
            ).count(),
            "approved_changes": base_query.filter_by(status='approved').count(),
            "implemented_changes": base_query.filter_by(status='implemented').count(),
            "high_risk_changes": base_query.join(RiskScore).filter(
                RiskScore.risk_level == 'High'
            ).count(),
            "medium_risk_changes": base_query.join(RiskScore).filter(
                RiskScore.risk_level == 'Medium'
            ).count(),
            "low_risk_changes": base_query.join(RiskScore).filter(
                RiskScore.risk_level == 'Low'
            ).count()
        }
        
        # Get today's changes
        today = datetime.utcnow().date()
        today_changes = base_query.filter(
            func.date(ChangeRequest.created_at) == today
        ).count()
        
        stats["today_changes"] = today_changes
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed quick stats",
            user_id=current_user.id,
            request_data={"view": "quick_stats"}
        )
        
        return jsonify(stats), 200
        
    except Exception as e:
        logger.error(f"Get quick stats error: {e}")
        return jsonify({"error": "An error occurred while retrieving quick stats"}), 500


@dashboard_bp.route('/user-dashboard', methods=['GET'])
@jwt_required()
def get_user_dashboard():
    """Get user-specific dashboard data."""
    try:
        current_user_id = get_jwt_identity()
        current_user = AuthService.get_user_by_id(current_user_id)
        
        if not current_user:
            return jsonify({"error": "User not found"}), 404
        
        # Get user-specific data
        user_changes = ChangeRequest.query.filter_by(
            submitted_by_id=current_user.id
        ).order_by(ChangeRequest.created_at.desc()).limit(10).all()
        
        # Get user stats
        user_stats = {
            "total_changes": len(user_changes),
            "draft_changes": sum(1 for c in user_changes if c.status == 'draft'),
            "submitted_changes": sum(1 for c in user_changes if c.status == 'submitted'),
            "approved_changes": sum(1 for c in user_changes if c.status == 'approved'),
            "rejected_changes": sum(1 for c in user_changes if c.status == 'rejected'),
            "high_risk_changes": sum(1 for c in user_changes if c.risk_level == 'High'),
            "medium_risk_changes": sum(1 for c in user_changes if c.risk_level == 'Medium'),
            "low_risk_changes": sum(1 for c in user_changes if c.risk_level == 'Low')
        }
        
        # Format changes
        changes_data = [DashboardService._format_change_summary(change) for change in user_changes]
        
        # Log access
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="dashboard",
            description=f"User {current_user.username} accessed user dashboard",
            user_id=current_user.id,
            request_data={"view": "user_dashboard"}
        )
        
        return jsonify({
            "user_stats": user_stats,
            "recent_changes": changes_data,
            "user_info": {
                "id": current_user.id,
                "username": current_user.username,
                "role": current_user.role.value,
                "is_admin": current_user.is_admin(),
                "is_change_manager": current_user.is_change_manager()
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Get user dashboard error: {e}")
        return jsonify({"error": "An error occurred while retrieving user dashboard"}), 500