"""
Authentication API endpoints.
Handles user login, registration, and token management.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from datetime import datetime
import logging

from services.auth_service import AuthService
from models import AuditLog, AuditAction
from config import settings

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['POST'])
def login():
    """User login endpoint."""
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({"error": "Username and password are required"}), 400
        
        username = data['username']
        password = data['password']
        
        # Authenticate user
        auth_result = AuthService.authenticate_user(username, password)
        
        if auth_result:
            # Log successful login
            AuditLog.log_action(
                action=AuditAction.LOGIN,
                resource_type="user",
                description=f"User {username} logged in successfully",
                user_email=username,
                request_data={"username": username},
                response_data={"success": True}
            )
            
            return jsonify(auth_result), 200
        else:
            # Log failed login attempt
            AuditLog.log_action(
                action=AuditAction.LOGIN,
                resource_type="user",
                description=f"Failed login attempt for user {username}",
                user_email=username,
                request_data={"username": username},
                response_data={"success": False, "error": "Invalid credentials"},
                status_code=401
            )
            
            return jsonify({"error": "Invalid username or password"}), 401
            
    except Exception as e:
        logger.error(f"Login error: {e}")
        return jsonify({"error": "An error occurred during login"}), 500


@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    """User logout endpoint."""
    try:
        current_user_id = get_jwt_identity()
        jti = get_jwt()["jti"]
        
        # Log logout
        AuditLog.log_action(
            action=AuditAction.LOGOUT,
            resource_type="user",
            description=f"User {current_user_id} logged out",
            user_id=current_user_id,
            request_data={"jti": jti}
        )
        
        # Note: In a full implementation with token blacklisting, 
        # you would add the JTI to a blacklist here
        
        return jsonify({"message": "Successfully logged out"}), 200
        
    except Exception as e:
        logger.error(f"Logout error: {e}")
        return jsonify({"error": "An error occurred during logout"}), 500


@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    """Token refresh endpoint."""
    try:
        current_user_id = get_jwt_identity()
        
        # Create new access token
        new_access_token = AuthService.create_access_token(identity=current_user_id)
        
        # Log token refresh
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="token",
            description=f"Token refreshed for user {current_user_id}",
            user_id=current_user_id
        )
        
        return jsonify({
            "access_token": new_access_token
        }), 200
        
    except Exception as e:
        logger.error(f"Token refresh error: {e}")
        return jsonify({"error": "An error occurred during token refresh"}), 500


@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get current user information."""
    try:
        current_user_id = get_jwt_identity()
        
        user = AuthService.get_user_by_id(current_user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404
        
        # Log access to user info
        AuditLog.log_action(
            action=AuditAction.READ,
            resource_type="user",
            description=f"User {user.username} accessed their profile",
            user_id=user.id,
            resource_id=str(user.id)
        )
        
        return jsonify({
            "user": user.to_dict(),
            "permissions": {
                "is_admin": user.is_admin(),
                "is_change_manager": user.is_change_manager()
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Get current user error: {e}")
        return jsonify({"error": "An error occurred while retrieving user information"}), 500


@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    """Change user password."""
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data or not data.get('current_password') or not data.get('new_password'):
            return jsonify({"error": "Current password and new password are required"}), 400
        
        current_password = data['current_password']
        new_password = data['new_password']
        
        # Validate password strength
        if len(new_password) < 8:
            return jsonify({"error": "Password must be at least 8 characters long"}), 400
        
        # Change password
        success = AuthService.change_password(current_user_id, current_password, new_password)
        
        if success:
            # Log password change
            AuditLog.log_action(
                action=AuditAction.UPDATE,
                resource_type="user",
                description=f"Password changed for user {current_user_id}",
                user_id=current_user_id,
                request_data={"action": "password_change"}
            )
            
            return jsonify({"message": "Password changed successfully"}), 200
        else:
            return jsonify({"error": "Current password is incorrect"}), 400
            
    except Exception as e:
        logger.error(f"Change password error: {e}")
        return jsonify({"error": "An error occurred while changing password"}), 500


@auth_bp.route('/validate-token', methods=['POST'])
def validate_token():
    """Validate JWT token endpoint."""
    try:
        data = request.get_json()
        
        if not data or not data.get('token'):
            return jsonify({"error": "Token is required"}), 400
        
        token = data['token']
        
        # Validate token
        validation_result = AuthService.validate_token(token)
        
        if validation_result:
            return jsonify({
                "valid": True,
                "user": validation_result
            }), 200
        else:
            return jsonify({
                "valid": False,
                "error": "Invalid or expired token"
            }), 401
            
    except Exception as e:
        logger.error(f"Token validation error: {e}")
        return jsonify({"error": "An error occurred during token validation"}), 500


@auth_bp.route('/register', methods=['POST'])
def register():
    """User registration endpoint (for admin use)."""
    try:
        data = request.get_json()
        
        # This endpoint should typically require admin privileges
        # For now, we'll allow registration but log it for security
        
        if not data or not all(key in data for key in ['username', 'email', 'password', 'full_name']):
            return jsonify({"error": "Username, email, password, and full name are required"}), 400
        
        username = data['username']
        email = data['email']
        password = data['password']
        full_name = data['full_name']
        role = data.get('role', 'change_manager')
        
        # Validate role
        if role not in ['admin', 'change_manager', 'viewer']:
            return jsonify({"error": "Invalid role"}), 400
        
        # Create user
        user = AuthService.create_user(username, email, password, full_name, role)
        
        if user:
            # Log user creation
            AuditLog.log_action(
                action=AuditAction.CREATE,
                resource_type="user",
                description=f"User {username} registered with role {role}",
                user_email=email,
                request_data={
                    "username": username,
                    "email": email,
                    "role": role,
                    "full_name": full_name
                }
            )
            
            return jsonify({
                "message": "User registered successfully",
                "user": user.to_dict()
            }), 201
        else:
            return jsonify({"error": "Username or email already exists"}), 409
            
    except Exception as e:
        logger.error(f"Registration error: {e}")
        return jsonify({"error": "An error occurred during registration"}), 500


@auth_bp.route('/token-info', methods=['GET'])
@jwt_required()
def get_token_info():
    """Get information about the current token."""
    try:
        current_user_id = get_jwt_identity()
        jwt_data = get_jwt()
        
        token_info = {
            "user_id": current_user_id,
            "token_id": jwt_data.get("jti"),
            "issued_at": datetime.fromtimestamp(jwt_data.get("iat", 0)).isoformat(),
            "expires_at": datetime.fromtimestamp(jwt_data.get("exp", 0)).isoformat(),
            "issued_for": jwt_data.get("sub"),
            "type": jwt_data.get("type")
        }
        
        return jsonify(token_info), 200
        
    except Exception as e:
        logger.error(f"Token info error: {e}")
        return jsonify({"error": "An error occurred while retrieving token information"}), 500