#!/usr/bin/env python3
"""
Test script to verify that sample data is being loaded correctly.
"""

import os
import sys
import json
from datetime import datetime

# Add the backend directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from models import db, ChangeRequest, RiskScore, User

def test_data_loading():
    """Test if sample data is being loaded correctly."""
    app = create_app()
    
    with app.app_context():
        print("=== Testing Data Loading ===")
        
        # Check if admin user exists
        admin_user = User.query.filter_by(role="admin").first()
        print(f"Admin user exists: {admin_user is not None}")
        if admin_user:
            print(f"Admin user: {admin_user.username} ({admin_user.email})")
        
        # Check if rules exist
        rules_count = db.session.query(db.func.count(RiskScore.id)).scalar()
        print(f"Rules count: {rules_count}")
        
        # Check if changes exist
        changes_count = db.session.query(db.func.count(ChangeRequest.id)).scalar()
        print(f"Changes count: {changes_count}")
        
        if changes_count > 0:
            print("\n=== Sample Changes ===")
            changes = ChangeRequest.query.limit(5).all()
            for change in changes:
                print(f"ID: {change.id}")
                print(f"Title: {change.title}")
                print(f"Status: {change.status}")
                print(f"Risk Level: {change.risk_level}")
                print(f"Created: {change.created_at}")
                print("---")
        
        # Check if risk scores exist
        risk_scores_count = db.session.query(db.func.count(RiskScore.id)).scalar()
        print(f"\nRisk scores count: {risk_scores_count}")
        
        if risk_scores_count > 0:
            print("\n=== Sample Risk Scores ===")
            risk_scores = RiskScore.query.limit(3).all()
            for score in risk_scores:
                print(f"Change ID: {score.change_request_id}")
                print(f"Risk Level: {score.risk_level}")
                print(f"Risk Score: {score.risk_score}")
                print(f"Assessment Method: {score.assessment_method}")
                print("---")
        
        print("\n=== Test Complete ===")

if __name__ == "__main__":
    test_data_loading()